#pragma once
#include <string>
#include <vector>
#include <cmath>
#include "../graphics_kernel.hpp"

namespace Aura::Graphics::UI {

/**
 * @class TransportHUD
 * @brief Logic Pro style LCD and Transport Controls.
 */
class TransportHUD {
public:
    void render(Platform::IGraphicsKernel& kernel, float x, float y, float w, float h, uint64_t currentPos, bool isPlaying) {
        // --- 1. OUTER HUD CONTAINER ---
        kernel.drawDropShadow(x, y, w, h, 6, 0x99000000);
        kernel.drawGradientRect(x, y, w, h, 0xFF323234, 0xFF252526);
        
        // --- 2. TRANSPORT BUTTONS (Left Side) ---
        float bX = x + 10.0f;
        float bY = y + 8.0f;
        drawTransportControls(kernel, bX, bY, isPlaying);

        // --- 3. THE LCD DISPLAY ---
        float lcdW = 480.0f;
        float lcdX = x + (w - lcdW) * 0.5f;
        float lcdY = y + 5.0f;
        float lcdH = h - 10.0f;
        
        // LCD Background
        kernel.drawRoundedRect(lcdX, lcdY, lcdW, lcdH, 6.0f, 0xFF0A0A0C);

        // --- CALC POSITION (Logic Standard: Bar / Beat / Div / Tick) ---
        uint32_t samplesPerBar = 44100 * 2;
        uint32_t samplesPerBeat = samplesPerBar / 4;
        uint32_t bar = (uint32_t)(currentPos / samplesPerBar) + 1;
        uint32_t beat = (uint32_t)((currentPos % samplesPerBar) / samplesPerBeat) + 1;
        uint32_t div = (uint32_t)((currentPos % samplesPerBeat) / (samplesPerBeat / 4)) + 1;
        uint32_t tick = (uint32_t)((currentPos % (samplesPerBeat / 4)) / (samplesPerBeat / 4 / 240)) + 1;
        
        char posStr[64]; 
        snprintf(posStr, 64, "%d   %d   %d   %d", bar, beat, div, tick);
        
        uint32_t secTotal = (uint32_t)(currentPos / 44100);
        uint32_t min = secTotal / 60;
        uint32_t sec = secTotal % 60;
        char timeStr[64]; 
        snprintf(timeStr, 64, "%02d:%02d.%03d", min, sec, (int)((currentPos % 44100) / 44));
        
        // --- 4. LCD CONTENT: POSITION ---
        float colX = lcdX + 30.0f;
        kernel.drawText(posStr, colX, lcdY + 28, 20, 0xFF22D3EE); // Bigger, cleaner font
        kernel.drawText("BAR", colX + 5, lcdY + 38, 7, 0xFF555555);
        kernel.drawText("BEAT", colX + 38, lcdY + 38, 7, 0xFF555555);
        kernel.drawText("DIV", colX + 71, lcdY + 38, 7, 0xFF555555);
        kernel.drawText("TICK", colX + 104, lcdY + 38, 7, 0xFF555555);
        
        kernel.drawLine(colX + 160, lcdY + 10, colX + 160, lcdY + lcdH - 10, 1.0f, 0x22FFFFFF);
        
        // --- 5. LCD CONTENT: TIME ---
        colX += 180.0f;
        kernel.drawText(timeStr, colX, lcdY + 28, 16, 0xFF22D3EE);
        kernel.drawText("TIME", colX + 25, lcdY + 38, 8, 0xFF555555);
        
        kernel.drawLine(colX + 90, lcdY + 10, colX + 90, lcdY + lcdH - 10, 1.0f, 0x22FFFFFF);
        
        // --- 6. LCD CONTENT: TEMPO / SIG ---
        colX += 110.0f;
        kernel.drawText("BPM   120.00", colX, lcdY + 18, 9, 0xFF22D3EE);
        kernel.drawText("SIG   4 / 4", colX, lcdY + 32, 9, 0xFF22D3EE);
        
        kernel.drawLine(colX + 100, lcdY + 10, colX + 100, lcdY + lcdH - 10, 1.0f, 0x22FFFFFF);

        // --- 7. LCD CONTENT: RESOURCE & MIDI ---
        colX += 115.0f;
        kernel.drawText("MIDI", colX, lcdY + 12, 8, 0xFF555555);
        kernel.drawCircle(colX + 30, lcdY + 8, 3, 0xFF22D3EE); // Active MIDI dot
        
        kernel.drawText("CPU", colX, lcdY + 24, 8, 0xFF555555);
        drawResourceBar(kernel, colX + 25, lcdY + 18, 40, 3, 0.4f);
        
        kernel.drawText("HD", colX, lcdY + 36, 8, 0xFF555555);
        drawResourceBar(kernel, colX + 25, lcdY + 30, 40, 1, 0.15f);
    }

private:
    void drawTransportControls(Platform::IGraphicsKernel& kernel, float x, float y, bool isPlaying) {
        float bW = 40, bH = 30;
        
        // --- 1. REWIND / STOP (Logic style grey-interactive) ---
        uint32_t stopCol = isPlaying ? 0xFFBBBBBB : 0xFFFFFFFF;
        kernel.drawGradientRect(x, y, bW, bH, 0xFF4A4A4C, 0xFF252526);
        kernel.drawRoundedRect(x + 13, y + 8, 14, 14, 1.0f, stopCol); // Square Stop
        if (!isPlaying) kernel.drawDropShadow(x + 13, y + 8, 14, 14, 4, 0x88FFFFFF); // Stopped Glow
        
        // --- 2. PLAY (Neon Logic Green) ---
        x += 42;
        uint32_t playCol = isPlaying ? 0xFF22C55E : 0xFF353538;
        kernel.drawGradientRect(x, y, bW, bH, 0xFF4A4A4C, 0xFF252526);
        
        // Lucide-style Triangle with Glow
        std::vector<float> tri = { x + 15, y + 8, x + 15, y + 22, x + 28, y + 15 };
        if (isPlaying) {
            kernel.drawDropShadow(x + 12, y + 5, 20, 20, 8, 0xAA22C55E); // Neon Glow
            kernel.drawFilledPath(tri, 0xFFFFFFFF); // White Play when active
        } else {
            kernel.drawFilledPath(tri, 0xFF888888); // Dim Play
        }
        
        // --- 3. RECORD (Logic Red) ---
        x += 42;
        kernel.drawGradientRect(x, y, bW, bH, 0xFF4A4A4C, 0xFF252526);
        kernel.drawCircle(x + 20, y + 15, 7, 0xFFAF1F1F);
    }

private:
    void drawResourceBar(Platform::IGraphicsKernel& kernel, float x, float y, float w, int activeSegs, float level) {
        float segW = w / 8.0f;
        for (int i = 0; i < 8; ++i) {
            uint32_t col = (i < activeSegs) ? 0xFF22D3EE : 0xFF1A1A1C;
            kernel.drawRoundedRect(x + i * segW + 1, y, segW - 1, 8, 0, col);
        }
    }
};

} // namespace Aura::Graphics::UI
