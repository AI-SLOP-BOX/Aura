#pragma once
#include <string>
#include <vector>
#include "../graphics_kernel.hpp"

namespace Aura::Graphics::UI {

/**
 * @class InspectorPanel
 * @brief Logic Pro style Channel Strip and Inspector UI.
 */
class InspectorPanel {
public:
    void render(Platform::IGraphicsKernel& kernel, float x, float y, float w, float h, const std::string& trackName) {
        // --- 1. CHANNEL STRIP BACKGROUND ---
        kernel.drawGradientRect(x, y, w, h, 0xFF252526, 0xFF1C1C1E);
        kernel.drawLine(x + w - 1, y, x + w - 1, y + h, 1.0f, 0xFF000000); // Right Border
        
        // --- 2. SETTING & EQ DISPLAY ---
        float colX = x + 8.0f;
        float colW = w - 16.0f;
        kernel.drawRoundedRect(colX, y + 10, colW, 20, 4.0f, 0xFF1A1A1C); // Setting label
        kernel.drawText("SETTING", x + (w-50)/2, y + 24, 9, 0xFFD1D5DB);
        
        // FAKE EQ THUMB
        float eqY = y + 35.0f;
        kernel.drawRoundedRect(colX, eqY, colW, 40, 4.0f, 0xFF1A1A1C);
        kernel.drawText("EQ", colX + 5.0f, eqY + 12.0f, 8, 0xFF06B6D4);
        
        std::vector<float> eqPoints = { colX, eqY + 30.0f, colX+15, eqY+10, colX+35, eqY+35, colX+colW, eqY+30 };
        kernel.drawFilledPath(eqPoints, 0x3306B6D4); // Soft filled gradient area
        kernel.drawBezierPath(eqPoints, 0xFF06B6D4, 1.5f);
        
        // --- 3. INSERTS & SENDS ---
        float insY = eqY + 50.0f;
        drawPluginSlot(kernel, colX, insY, colW, "Compressor", 0xFF22D3EE, true);
        drawPluginSlot(kernel, colX, insY + 22, colW, "Space Dsg...", 0xFF22D3EE, false);
        drawPluginSlot(kernel, colX, insY + 44, colW, "Audio FX", 0xFF4B5563, false);
        
        kernel.drawLine(colX, insY + 70, colX + colW, insY + 70, 0.5f, 0x33FFFFFF);
        
        drawPluginSlot(kernel, colX, insY + 75, colW, "Bus 1", 0xFF22C55E, true);
        drawPluginSlot(kernel, colX, insY + 97, colW, "Sends", 0xFF4B5563, false);

        // --- 4. PAN KNOB ---
        float panY = insY + 140.0f;
        kernel.drawDropShadow(x + w/2 - 18, panY - 18, 36, 36, 18, 0x66000000);
        kernel.drawCircle(x + w/2, panY, 18.0f, 0xFF4A4A4C); // Beveled Pan Knob
        kernel.drawLine(x + w/2, panY - 15.0f, x + w/2, panY, 2.0f, 0xFFFFFFFF);
        kernel.drawText("0", x + w/2 - 4, panY + 28, 8, 0xFF9CA3AF);
        
        // --- 5. LARGE FADER & METER ---
        float faderY = panY + 45.0f;
        float meterW = 16.0f;
        kernel.drawMeter(0, 0.72f, 0.65f, x + w - meterW - 10, faderY, meterW, h - (faderY - y) - 40);
        
        // FADER SLOT
        float fxtX = x + 15.0f, fxtW = 28.0f, fxtH = h - (faderY - y) - 40;
        kernel.drawRoundedRect(fxtX, faderY, fxtW, fxtH, 4.0f, 0xFF0A0A0C);
        kernel.drawDropShadow(fxtX, faderY, fxtW, fxtH, 4, 0x99000000); // Inset look
        
        // FADER CAP
        float capY = faderY + fxtH * 0.4f;
        kernel.drawDropShadow(fxtX - 2, capY, fxtW + 4, 38, 4, 0x88000000);
        kernel.drawGradientRect(fxtX - 2, capY, fxtW + 4, 38, 0xFF6B6B6D, 0xFF252526);
        kernel.drawLine(fxtX + 4, capY + 19, fxtX + fxtW - 4, capY + 19, 1.5f, 0xFFFFFFFF);
    }

private:
    void drawPluginSlot(Platform::IGraphicsKernel& kernel, float x, float y, float w, const char* label, uint32_t color, bool pulse) {
        kernel.drawRoundedRect(x, y, w, 18, 2.0f, 0xFF1A1A1C);
        kernel.drawText(label, x + 8, y + 13, 8, color);
        if (pulse) {
            kernel.drawCircle(x + w - 10, y + 9, 3, color & 0x77FFFFFF); // Pulsing dot
        }
    }
};

} // namespace Aura::Graphics::UI
