#pragma once
#include <vector>
#include <string>
#include "../graphics_kernel.hpp"

namespace Aura::Graphics::UI {

/**
 * @class ArrangementView
 * @brief Logic Pro style Arrangement Timeline.
 */
class ArrangementView {
public:
    struct Region {
        float start, length;
        std::string name;
        std::string type; // "audio", "midi"
        bool selected = false;
        uint32_t color = 0xFF3B82F6;
    };

    void render(Platform::IGraphicsKernel& kernel, float x, float y, float w, float h, const std::vector<Region>& regions, float scrollX, float playheadX) {
        // --- 1. EBONY GRID BACKGROUND ---
        kernel.drawRoundedRect(x, y, w, h, 0, 0xFF151516);
        
        // DRAW RULER & TICKS (Major/Minor)
        float beatW = 100.0f;
        float subW = beatW / 4.0f;
        for (float gx = x; gx < x + w; gx += subW) {
             bool isMajor = ((int)(gx / beatW) * 4 == (int)(gx / subW));
             uint32_t gridCol = isMajor ? 0x33FFFFFF : 0x11FFFFFF;
             kernel.drawLine(gx, y, gx, y + h, 1.0f, gridCol);
             if (isMajor) {
                  kernel.drawText(std::to_string((int)(gx/beatW) + 1), gx + 5, y + 25, 11, 0xFFD1D5DB);
             }
        }

        // --- 2. CYCLE RANGE (Yellow Bar) ---
        kernel.drawGradientRect(x, y, w, 14, 0xFF1E1E1E, 0xFF1E1E1E);
        kernel.drawGradientRect(x + 50, y + 2, 400, 10, 0x44FBBF24, 0x22FBBF24);
        kernel.drawLine(x + 50, y + 2, x + 450, y + 2, 2.0f, 0xFFFBBF24);

        // --- 3. REGION RENDERING ---
        float trackH = 76.0f;
        for (size_t i = 0; i < regions.size(); ++i) {
            auto& reg = regions[i];
            float rx = x + (reg.start * 10.0f); // Scaling based on percent in React
            float ry = y + 44 + (i * trackH);
            float rw = reg.length * 10.0f;
            
            uint32_t baseCol = (reg.type == "audio") ? 0xFF3B82F6 : 0xFF22C55E;
            uint32_t headerCol = (reg.type == "audio") ? 0xFF2563EB : 0xFF16A34A;
            uint32_t borderCol = reg.selected ? 0xFFFFFFFF : (baseCol + 0x222222);
            
            kernel.drawDropShadow(rx, ry + 2, rw, trackH - 4, 4.0f, 0x44000000);
            kernel.drawRoundedRect(rx, ry + 2, rw, trackH - 4, 4.0f, baseCol);
            
            // Region Header
            kernel.drawRoundedRect(rx, ry + 2, rw, 16, 2.0f, headerCol);
            kernel.drawText(reg.name, rx + 6, ry + 13, 9, 0xFFFFFFFF);

            // MIRRORED WAVEFORM PREVIEW
            if (reg.type == "audio") {
                 float centerY = ry + 16 + (trackH - 16)/2;
                 std::vector<float> wave;
                 for (int j = 0; j < 20; ++j) {
                     float wx = rx + (j * rw/20.0f);
                     float mag = std::sin(j * 0.5f) * 15.0f;
                     wave.push_back(wx); wave.push_back(centerY - mag);
                 }
                 kernel.drawBezierPath(wave, 0xAAFFFFFF, 1.5f);
                 // Mirror
                 for (size_t j = 0; j < wave.size()/2; ++j) wave[j*2+1] = centerY + (centerY - wave[j*2+1]);
                 kernel.drawBezierPath(wave, 0x66FFFFFF, 1.0f);
            }
        }

        // --- 4. PLAYHEAD (High-Visibility White Line) ---
        float phX = x + playheadX;
        kernel.drawDropShadow(phX - 2, y, 4, h, 0, 0x99FFFFFF);
        kernel.drawLine(phX, y, phX, y + h, 1.5f, 0xFFFFFFFF);
    }
};

} // namespace Aura::Graphics::UI
