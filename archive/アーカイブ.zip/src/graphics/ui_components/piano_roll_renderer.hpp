#pragma once

#include <vector>
#include <string>
#include "../graphics_kernel.hpp"
#include "../../core/midi_region.hpp"

namespace Aura::Graphics::UI {

/**
 * @class PianoRollRenderer
 * @brief High-performance GPU-accelerated MIDI Editor.
 */
class PianoRollRenderer {
public:
    struct Theme {
        uint32_t noteColor = 0xFF3B9EFF;
        uint32_t gridColor = 0xFF333333;
        uint32_t darkKeyColor = 0xFF111111;
    };

    /**
     * @brief RENDER: Draws the grid and MIDI notes using GPU primitives.
     */
    void render(Platform::IGraphicsKernel& kernel, float x, float y, float w, float h, const Core::MIDIRegion& region) {
        // --- 1. PRO GRID BACKGROUND ---
        kernel.drawRoundedRect(x, y, w, h, 0.0f, 0xFF0A0A0B); // Ebony background
        
        // DRAW SUBDIVISIONS (Grid)
        float beatW = 100.0f;
        for (float gx = 60.0f; gx < w; gx += beatW) {
            uint32_t gridCol = ((int)(gx / beatW) % 4 == 0) ? 0x44FFFFFF : 0x11FFFFFF;
            kernel.drawLine(x + gx, y, x + gx, y + h, 1.0f, gridCol);
        }

        // --- 2. PIANO KEYS (Glassy Sidebar) ---
        kernel.applyBlurEffect(x, y, 60.0f, h, 10.0f);
        kernel.drawGradientRect(x, y, 60.0f, h, 0xAA222222, 0xAA111111);
        
        float keyHeight = h / 24.0f; // 2 octaves view
        for (int i = 0; i < 24; ++i) {
            bool isBlack = isBlackKey(i);
            float ky = y + (23 - i) * keyHeight;
            
            if (isBlack) {
                kernel.drawRoundedRect(x, ky, 40.0f, keyHeight * 0.8f, 2.0f, 0xFF000000);
            } else {
                kernel.drawRoundedRect(x, ky, 58.0f, keyHeight * 0.9f, 2.0f, 0xFFFFFFFF);
            }
            
            if (i % 12 == 0) { // Mark C notes
                char cBuf[4];
                snprintf(cBuf, sizeof(cBuf), "C%d", (i/12) + 1);
                kernel.drawText(cBuf, x + 5, ky + keyHeight - 5, 8, 0xFF888888);
            }
        }

        // --- 3. MIDI NOTES (Neon Glow Blocks) ---
        for (const auto& note : region.getNotes()) {
            float nx = x + 60.0f + (static_cast<float>(note.startBeat) * beatW); 
            float ny = y + (127 - note.pitch) * (keyHeight / 5.4f); 
            float nw = static_cast<float>(note.lengthBeats) * beatW;
            
            // Normalize velocity for color
            float vel = std::clamp(note.velocity / 127.0f, 0.0f, 1.0f);
            uint32_t noteBase = 0xFF000000 | (uint32_t)(vel * 255) << 16 | (uint32_t)((1.0f - vel) * 200) << 8 | 255; 
            
            // NEON GLOW: Draw multiple layers for glow
            kernel.drawRoundedRect(nx, ny, nw, keyHeight * 0.7f, 3.0f, (noteBase & 0x00FFFFFF) | 0x44000000); // Glow
            kernel.drawRoundedRect(nx + 1, ny + 1, nw - 2, (keyHeight * 0.7f) - 2, 2.0f, noteBase); // Solid Core
            
            // Highlight top edge
            kernel.drawLine(nx + 2, ny + 2, nx + nw - 2, ny + 2, 1.0f, 0xAAFFFFFF);
        }
    }

private:
    bool isBlackKey(int k) {
        int m = k % 12;
        return (m == 1 || m == 3 || m == 6 || m == 8 || m == 10);
    }
    Theme m_theme;
};

} // namespace Aura::Graphics::UI
