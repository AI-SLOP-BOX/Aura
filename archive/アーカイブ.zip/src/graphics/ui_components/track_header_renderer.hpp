#pragma once
#include <string>
#include <vector>
#include "../graphics_kernel.hpp"

namespace Aura::Graphics::UI {

/**
 * @class TrackHeaderRenderer
 * @brief Logic Pro style Track List UI.
 */
class TrackHeaderRenderer {
public:
    struct Track {
        uint32_t id;
        std::string name;
        std::string type; // "audio", "midi"
        bool mute = false, solo = false, rec = false;
        float volume = 0.75f, pan = 0.0f;
        float peakL = 0.0f, peakR = 0.0f;
        uint32_t color = 0xFF3B82F6;
    };

    void render(Platform::IGraphicsKernel& kernel, float x, float y, float w, float h, const Track& track, bool selected) {
        // --- 1. TRACK BACKGROUND & SIGNATURE COLOR STRIP ---
        uint32_t bgCol = selected ? 0xFF353538 : 0xFF28282A;
        kernel.drawGradientRect(x, y, w, h, bgCol + 0x020202, bgCol - 0x020202);
        kernel.drawRoundedRect(x, y, 4, h, 0, track.color); // Color Strip
        kernel.drawLine(x, y + h - 1.0f, x + w, y + h - 1.0f, 1.0f, 0xFF141416);
        
        // --- 2. TRACK ICON & NAME ---
        float iconX = x + 12.0f;
        float iconY = y + 8.0f;
        kernel.drawRoundedRect(iconX, iconY, 28, 28, 6.0f, 0xFF121214);
        
        uint32_t iconCol = (track.type == "audio") ? 0xFF3B82F6 : 0xFF22C55E;
        kernel.drawCircle(iconX + 14, iconY + 14, 8, iconCol & 0x44FFFFFF); // Semi-transparent glow
        kernel.drawText(track.name, iconX + 38, iconY + 16, 13, selected ? 0xFFFFFFFF : 0xFFBBBBBB);
        
        // --- 3. M/S/R/I BUTTONS (Refined Logic Style) ---
        float btnX = x + 12.0f;
        float btnY = y + 42.0f;
        float btnW = 22.0f, btnH = 20.0f;
        
        drawButton(kernel, btnX, btnY, btnW, btnH, "M", track.mute ? 0xFF22C55E : 0xFF1A1A1C); // Logic M is Green-ish active
        drawButton(kernel, btnX + 24, btnY, btnW, btnH, "S", track.solo ? 0xFFEAB308 : 0xFF1A1A1C); // Gold Solo
        drawButton(kernel, btnX + 48, btnY, btnW, btnH, "R", track.rec ? 0xFFEF4444 : 0xFF1A1A1C); // Red Rec
        
        // --- 4. PAN & VOL CONTROL (Hardware Texture) ---
        float panX = x + 145.0f;
        float panY = y + 52.0f;
        kernel.drawCircle(panX, panY, 10.0f, 0xFF353538); // Bigger Knob
        kernel.drawDropShadow(panX - 10, panY - 10, 20, 20, 8, 0x55000000);
        float angle = track.pan * 0.8f;
        kernel.drawLine(panX, panY, panX + sin(angle)*8, panY - cos(angle)*8, 1.5f, 0xFFFFFFFF); // Pointer
        
        float sliderX = panX + 18.0f;
        float sliderW = w - (sliderX - x) - 10.0f;
        kernel.drawRoundedRect(sliderX, panY - 2, sliderW, 4, 2.0f, 0xFF08080A);
        kernel.drawRoundedRect(sliderX, panY - 2, sliderW * track.volume, 4, 2.0f, 0xFF3B82F6);
        
        // Meter
        float meterY = panY + 12.0f;
        float peak = std::max(track.peakL, track.peakR);
        uint32_t meterCol = (peak > 0.95f) ? 0xFFEF4444 : (peak > 0.7f) ? 0xFF22C55E : 0xFF0F5B2F;
        kernel.drawGradientRect(sliderX, meterY, sliderW * std::clamp(peak, 0.0f, 1.0f), 3, meterCol, meterCol & 0xAAFFFFFF);
    }

private:
    void drawButton(Platform::IGraphicsKernel& kernel, float x, float y, float w, float h, const char* label, uint32_t bgColor) {
        kernel.drawRoundedRect(x, y, w, h, 2.0f, bgColor);
        kernel.drawText(label, x + (w - 10)/2, y + 13, 8, (bgColor == 0xFF1A1A1C) ? 0xFF888888 : 0xFFFFFFFF);
    }
};

} // namespace Aura::Graphics::UI
