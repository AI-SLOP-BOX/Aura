#pragma once
#include <vector>
#include <string>
#include <array>
#include <cmath>
#include "../../graphics/graphics_kernel.hpp"

namespace Aura::Graphics::UI {

struct MacroMapping {
    uint32_t parameterId;
    float rangeMin = 0.0f;
    float rangeMax = 1.0f;
    bool inverted = false;
};

struct PBRMaterial {
    float roughness = 0.3f;
    float metallic = 0.9f;
    float ambientOcclusion = 1.0f;
    float emissionEnergy = 0.0f;
    std::array<float, 4> albedo = {0.2f, 0.2f, 0.2f, 1.0f};
    std::array<float, 4> emissionColor = {0.0f, 0.8f, 1.0f, 1.0f}; 
};

struct SmartControlNode {
    uint32_t id;
    std::string label;
    float currentValue = 0.5f;
    float x = 0.0f, y = 0.0f, radius = 40.0f;
    PBRMaterial material;
    std::vector<MacroMapping> mappings;
};

class SmartControlsUI {
public:
    static constexpr size_t kMaxKnobs = 12;

    void addKnob(uint32_t id, const std::string& label) {
        if (m_knobs.size() < kMaxKnobs) {
            SmartControlNode node;
            node.id = id;
            node.label = label;
            m_knobs.push_back(node);
        }
    }

    void addMapping(uint32_t knobId, uint32_t paramId, float minVal, float maxVal) {
        for (auto& k : m_knobs) {
            if (k.id == knobId) {
                k.mappings.push_back({paramId, minVal, maxVal, false});
                break;
            }
        }
    }

    void updateKnob(uint32_t id, float value) {
        for (auto& k : m_knobs) {
            if (k.id == id) {
                k.currentValue = value;
                m_isDirty = true;
                break;
            }
        }
    }

    void render(Graphics::Platform::IGraphicsKernel& kernel, float x, float y, float w, float h) {
        // --- 1. GLASSMORPHIC BACKGROUND ---
        kernel.applyBlurEffect(x, y, w, h, 20.0f);
        kernel.drawGradientRect(x, y, w, h, 0xBB111111, 0xBB050505); 
        kernel.drawRoundedRect(x, y, w, h, 8, 0x22FFFFFF); // Substrate border

        // --- 2. PREMIUM TITLE BAR ---
        kernel.drawGradientRect(x + 10, y + 10, w - 20, 26, 0xCC2A2A2A, 0xCC181818);
        kernel.drawText("SMART CONTROLS // MASTER MACRO PANEL", x + 25, y + 26, 11, 0xFFAAAAAA);
        
        // METAL ACCELERATED BADGE
        kernel.drawRoundedRect(x + w - 120, y + 15, 100, 16, 4.0f, 0xFF00AEEF);
        kernel.drawText("METAL PRO", x + w - 100, y + 26, 8, 0xFFFFFFFF);

        // --- 3. MASTER METER HUD (Right Side) ---
        float hudW = 60.0f;
        float hudX = x + w - hudW - 20;
        float hudY = y + 50;
        float hudH = h - 80;
        
        // Use a fake level for demo, but piped to drawMeter
        static float mockL = 0.6f;
        static float mockR = 0.58f;
        mockL = 0.4f + (std::rand() % 100) / 400.0f;
        mockR = 0.4f + (std::rand() % 100) / 400.0f;
        
        kernel.drawMeter(0, mockL, mockR, hudX, hudY, hudW, hudH);
        kernel.drawText("OUTPUT", hudX, hudY + hudH + 15, 8, 0xFF888888);

        if (m_knobs.empty()) return;

        // --- 4. KNOB RENDERER (Centered Area) ---
        float controlW = w - hudW - 60;
        float spacing = controlW / (m_knobs.size() + 1);
        for (size_t i = 0; i < m_knobs.size(); ++i) {
            auto& knob = m_knobs[i];
            float kx = x + (i + 1) * spacing;
            float ky = y + h * 0.55f;
            
            // --- 2. MULTI-LAYER BEVELED KNOB ---
            // Outer bezel (Metal Ring)
            kernel.drawCircle(kx, ky, 28, 0xFF0A0A0A); // Background gap
            kernel.drawCircle(kx, ky, 26, 0xFF2A2A2A); // Bezel outer
            kernel.drawCircle(kx, ky, 24, 0xFF121212); // Bezel inner (shadow)
            
            // Inner Dial (Metallic Surface)
            // Simulating ambient occlusion and metallic highlights
            uint32_t baseCol = 0xFF333333;
            kernel.drawCircle(kx, ky, 22, baseCol);
            
            // Indicator Arc (Glow)
            float angleStart = -135.0f;
            float angleEnd = angleStart + knob.currentValue * 270.0f;
            
            // Draw multiple thin lines for the arc to simulate a "neon glow"
            for (float r = 24.5f; r < 26.5f; r += 0.5f) {
                uint32_t glowColor = 0x6600AEEF; // Semi-transparent Neon Blue
                // Simple arc simulation using lines (if drawArc isn't available)
                for (float a = angleStart; a <= angleEnd; a += 5.0f) {
                    float rad1 = a * M_PI / 180.0f;
                    float rad2 = (a + 5.0f) * M_PI / 180.0f;
                    kernel.drawLine(kx + std::cos(rad1) * r, ky + std::sin(rad1) * r,
                                    kx + std::cos(rad2) * r, ky + std::sin(rad2) * r, 
                                    2.0f, glowColor);
                }
            }

            // Knob Pointer (Indicator Light)
            float rad = angleEnd * M_PI / 180.0f;
            float px = kx + std::cos(rad) * 16;
            float py = ky + std::sin(rad) * 16;
            
            // Neon Dot with Glow
            kernel.drawCircle(px, py, 4, 0xAA00AEEF); // Outer glow
            kernel.drawCircle(px, py, 2, 0xFFFFFFFF); // Inner bright spot
            
            // Labels (Technical Pro Look)
            kernel.drawText(knob.label, kx - 20, ky + 45, 9, 0xFFCCCCCC);
            
            char valBuf[16];
            snprintf(valBuf, sizeof(valBuf), "%.1f %%", knob.currentValue * 100.0f);
            kernel.drawText(valBuf, kx - 15, ky + 58, 7, 0xFF555555);
        }
    }

private:
    std::vector<SmartControlNode> m_knobs;
    bool m_isDirty = true;
};

} // namespace Aura::Graphics::UI
