#pragma once
#include <string>
#include <vector>
#include <cmath>
#include "../graphics_kernel.hpp"
#include "transport_hud.hpp"
#include "track_header_renderer.hpp"
#include "inspector_panel.hpp"
#include "arrangement_view.hpp"

#include "../../AuraUltimate.hpp"

namespace Aura::Graphics::UI {

/**
 * @class AuraProUI
 * @brief THE MASTER LAYOUT - 2026 LOGIC PRO ULTIMATE REPLICATION
 */
class AuraProUI {
public:
    void render(Platform::IGraphicsKernel& kernel, float w, float h, Aura::AuraEngine& engine) {
        auto& timeline = engine.getTimeline();
        auto& tracks = timeline.getTracks();
        
        // --- 1. TOP CONTROL BAR (Logic Pro Control Center) ---
        kernel.applyBlurEffect(0, 0, w, 46, 1.2f);
        kernel.drawGradientRect(0, 0, w, 46, 0xFF323234, 0xFF252526);
        kernel.drawLine(0, 45, w, 45, 1.0f, 0xFF141416);

        // Sidebar Icons (Top Left)
        drawToolbarIcon(kernel, 10, 8, "LIB", 0xFFBBBBBB);
        drawToolbarIcon(kernel, 48, 8, "INS", 0xFF3B82F6); // Blue Active
        drawToolbarIcon(kernel, 86, 8, "HLP", 0xFFBBBBBB);
        
        // The LCD & Transport (Centered)
        float hudW = 680.0f;
        m_transport.render(kernel, (w - hudW) * 0.5f, 0, hudW, 46, timeline.getCurrentPos(), timeline.isPlaying());

        // --- 2. TIME RULER (The Arrangement Bar) ---
        float rulerH = 32.0f;
        float arrY = 46.0f;
        kernel.drawGradientRect(0, arrY, w, rulerH, 0xFF3E3E40, 0xFF2B2B2D);
        kernel.drawLine(0, arrY + rulerH, w, arrY + rulerH, 1.0f, 0xFF000000);
        
        float trackHeaderW = 260.0f;
        float inspectorW = 240.0f;
        float arrangementX = inspectorW + trackHeaderW;

        for (int i = 0; i < 32; ++i) {
            float x = arrangementX + i * 200.0f;
            if (x > w) break;
            kernel.drawText(std::to_string(i + 1), x + 5, arrY + 20, 10, 0xFF888888);
            kernel.drawLine(x, arrY + 24, x, arrY + rulerH, 1.0f, 0x33FFFFFF);
        }

        // --- 3. LEFT INSPECTOR (Focused Strip) ---
        if (!tracks.empty()) {
            m_inspector.render(kernel, 0, arrY, inspectorW, h - arrY - 24, tracks[0]->getName());
        }
        
        // --- 4. TRACK LIST (Headers) ---
        float trackH = 82.0f;
        float listY = arrY + rulerH;
        for (size_t i = 0; i < tracks.size(); ++i) {
             auto& t = tracks[i];
             uint32_t trackCols[6] = { 0xFF3B82F6, 0xFF22C55E, 0xFFEAB308, 0xFFEF4444, 0xFFA855F7, 0xFF06B6D4 };
             TrackHeaderRenderer::Track uiTrack = { (uint32_t)t->getId(), t->getName(), "audio", t->isMuted(), t->isSolo(), false, t->getVolume(), t->getPan(), t->getPeakL(), t->getPeakR(), trackCols[i % 6] };
             m_headerRenderer.render(kernel, inspectorW, listY + (i * trackH), trackHeaderW, trackH, uiTrack, (i == 0));
        }

        // --- 5. ARRANGEMENT VIEW (The Heart) ---
        std::vector<ArrangementView::Region> uiRegions;
        for (auto& t : tracks) {
            for (auto& reg : t->getAudioRegions()) {
                uiRegions.push_back({ (float)reg->getMeta().samplePosition / 44100.0f, (float)reg->getMeta().sampleLength / 44100.0f, reg->getMeta().name, "audio", false });
            }
        }
        
        float playheadX = (float)timeline.getCurrentPos() / 44100.0f * 100.0f;
        m_arrangement.render(kernel, arrangementX, listY, w - arrangementX, h - listY - 24, uiRegions, 0, playheadX);

        // --- 6. GLOBAL FOOTER ---
        kernel.drawGradientRect(0, h - 24, w, 24, 0xFF1C1C1E, 0xFF0A0A0C);
        kernel.drawText("AURA DAW ULTIMATE // PRO MIX ENGINE ACTIVE // LOW LATENCY MONITORING", 15, h - 8, 9, 0xFF666666);
    }

private:
    void drawToolbarIcon(Platform::IGraphicsKernel& kernel, float x, float y, const char* label, uint32_t col) {
        kernel.drawGradientRect(x, y, 34, 30, 0xFF353538, 0xFF28282A);
        kernel.drawRoundedRect(x, y, 34, 30, 4, 0x22FFFFFF);
        kernel.drawText(label, x + 6, y + 18, 9, col);
    }

private:
    TransportHUD m_transport;
    TrackHeaderRenderer m_headerRenderer;
    InspectorPanel m_inspector;
    ArrangementView m_arrangement;
};

} // namespace Aura::Graphics::UI
