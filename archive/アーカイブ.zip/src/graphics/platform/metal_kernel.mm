#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <QuartzCore/CAMetalLayer.h>
#import <AppKit/AppKit.h>
#include "graphics/graphics_kernel.hpp"
#include <map>
#include <string>

namespace Aura::Graphics::Platform {

/**
 * @brief MetalKernel: The Apple Silicon Native High-Performance Graphics.
 */
class MetalKernel : public IGraphicsKernel {
public:
    MetalKernel() : m_device(nil), m_commandQueue(nil), m_view(nil) {}

    bool initialize(void* nativeWindowHandle) override {
        m_view = (__bridge MTKView*)nativeWindowHandle;
        if (!m_view) return false;
        
        m_device = m_view.device;
        m_commandQueue = [m_device newCommandQueue];
        m_view.clearColor = MTLClearColorMake(0.05, 0.05, 0.06, 1.0); // Deep Obsidian
        
        // --- ADVANCED SDF SHADER: For Antialiased UI Primitives ---
        NSError* error = nil;
        NSString* shaderSource = @"\
            #include <metal_stdlib>\n\
            using namespace metal;\n\
            \n\
            struct VertexOut {\n\
                float4 pos [[position]];\n\
                float4 color;\n\
                float2 uv;\n\
                float2 rectPos;\n\
                float2 rectSize;\n\
                float radius;\n\
                float border;\n\
                float shadow;\n\
                float isTex;\n\
            };\n\
            \n\
            struct Uniforms {\n\
                float4 pos;     // xy, width, height\n\
                float4 props;   // radius, border, shadow, isTex\n\
                float4 color1;  // RGBA (Primary)\n\
                float4 color2;  // RGBA (Gradient end)\n\
            };\n\
            \n\
            vertex VertexOut vMain(uint vid [[vertex_id]], uint iid [[instance_id]], constant Uniforms* batch [[buffer(0)]]) {\n\
                constant Uniforms& u = batch[iid];\n\
                float2 vertices[4] = { float2(-1, 1), float2(1, 1), float2(-1, -1), float2(1, -1) };\n\
                float2 uv[4] = { float2(0, 0), float2(1, 0), float2(0, 1), float2(1, 1) };\n\
                \n\
                VertexOut o;\n\
                o.pos = float4(u.pos.xy + vertices[vid] * u.pos.zw, 0, 1);\n\
                o.uv = uv[vid];\n\
                o.rectPos = u.pos.xy;\n\
                o.rectSize = u.pos.zw;\n\
                o.radius = u.props.x;\n\
                o.border = u.props.y;\n\
                o.shadow = u.props.z;\n\
                o.isTex = u.props.w;\n\
                o.color = mix(u.color1, u.color2, o.uv.y);\n\
                return o;\n\
            }\n\
            \n\
            float sdRoundedRect(float2 p, float2 b, float r) {\n\
                float2 q = abs(p) - b + r;\n\
                return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;\n\
            }\n\
            \n\
            fragment float4 fMain(VertexOut i [[stage_in]], texture2d<float> tex [[texture(0)]]) {\n\
                if (i.isTex > 0.5) {\n\
                    constexpr sampler s(mag_filter::linear, min_filter::linear);\n\
                    return float4(i.color.rgb, i.color.a * tex.sample(s, i.uv).a);\n\
                }\n\
                \n\
                // SDF for Rounded Rectangle\n\
                float2 p = (i.uv - 0.5) * i.rectSize * 2.0;\n\
                float d = sdRoundedRect(p, i.rectSize, i.radius);\n\
                \n\
                // Antialiasing\n\
                float outA = 1.0 - smoothstep(-1.5, 1.5, d);\n\
                \n\
                // INSET SHADOW (Inner Glow)\n\
                if (i.shadow > 0.1) {\n\
                     float shadowA = smoothstep(-i.shadow, 0.0, d);\n\
                     return float4(i.color.rgb, i.color.a * outA * shadowA);\n\
                }\n\
                \n\
                if (i.border > 0.0) {\n\
                    float innerD = d + i.border;\n\
                    float innerAlpha = 1.0 - smoothstep(-1.5, 1.5, innerD);\n\
                    return float4(i.color.rgb, i.color.a * (outA - innerAlpha));\n\
                }\n\
                \n\
                return float4(i.color.rgb, i.color.a * outA);\n\
            }\n";
            
        id<MTLLibrary> library = [m_device newLibraryWithSource:shaderSource options:nil error:&error];
        if (!library) { NSLog(@"Metal Shader Error: %@", error); return false; }
        
        MTLRenderPipelineDescriptor* pd = [[MTLRenderPipelineDescriptor alloc] init];
        pd.vertexFunction = [library newFunctionWithName:@"vMain"];
        pd.fragmentFunction = [library newFunctionWithName:@"fMain"];
        pd.colorAttachments[0].pixelFormat = m_view.colorPixelFormat;
        
        pd.colorAttachments[0].blendingEnabled = YES;
        pd.colorAttachments[0].sourceRGBBlendFactor = MTLBlendFactorSourceAlpha;
        pd.colorAttachments[0].destinationRGBBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
        pd.colorAttachments[0].sourceAlphaBlendFactor = MTLBlendFactorSourceAlpha;
        pd.colorAttachments[0].destinationAlphaBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
 
        m_pipelineState = [m_device newRenderPipelineStateWithDescriptor:pd error:&error];
        
        // --- PRE-ALLOCATE BATCH BUFFER (10,000 Instances) ---
        m_batchBuffer = [m_device newBufferWithLength:10000 * sizeof(Uniforms) options:MTLResourceStorageModeShared];
        
        return m_pipelineState != nil;
    }

    void beginFrame() override {
        if (!m_view) return;
        m_commandBuffer = [m_commandQueue commandBuffer];
        m_renderPassDescriptor = m_view.currentRenderPassDescriptor;
        if (m_renderPassDescriptor) {
            m_encoder = [m_commandBuffer renderCommandEncoderWithDescriptor:m_renderPassDescriptor];
            [m_encoder setRenderPipelineState:m_pipelineState];
        }
        m_currentBatch.clear();
    }

    void flushBatch() {
        if (m_currentBatch.empty() || !m_encoder) return;
        
        // --- HONEST PERFORMANCE FIX: Zero-Copy VRAM Upload ---
        // Copy the entire batch from CPU RAM to pre-allocated VRAM Buffer
        size_t copySize = m_currentBatch.size() * sizeof(Uniforms);
        memcpy([m_batchBuffer contents], m_currentBatch.data(), copySize);
        
        [m_encoder setVertexBuffer:m_batchBuffer offset:0 atIndex:0];
        [m_encoder drawPrimitives:MTLPrimitiveTypeTriangleStrip vertexStart:0 vertexCount:4 instanceCount:m_currentBatch.size()];
        m_currentBatch.clear();
    }

    void endFrame() override {
        flushBatch();
        if (m_encoder) {
            [m_encoder endEncoding];
            if (m_view.currentDrawable) [m_commandBuffer presentDrawable:m_view.currentDrawable];
            [m_commandBuffer commit];
        }
    }

    struct Uniforms {
        simd_float4 pos;     // x, y, width, height (NDC)
        simd_float4 props;   // radius, border, shadow, isTex
        simd_float4 color1;  // RGBA Start
        simd_float4 color2;  // RGBA End
    };

    void drawNative(float x, float y, float w, float h, float r, float b, float s, uint32_t c1, uint32_t c2, bool isTex) {
        Uniforms u;
        float vw = m_view.bounds.size.width;
        float vh = m_view.bounds.size.height;
        if (vw < 1 || vh < 1) return;

        u.pos = { ((x + w/2.0f) / vw) * 2.0f - 1.0f, 1.0f - ((y + h/2.0f) / vh) * 2.0f, w / vw, h / vh };
        float ndcRadius = r / ((vw + vh) / 2.0f);
        u.props = { ndcRadius, b, s, isTex ? 1.0f : 0.0f };
        
        auto toS4 = [](uint32_t c) {
            return simd_make_float4(((c >> 16) & 0xFF)/255.f, ((c >> 8) & 0xFF)/255.f, (c & 0xFF)/255.f, ((c >> 24) & 0xFF)/255.f);
        };
        u.color1 = toS4(c1); u.color2 = toS4(c2);
        
        m_currentBatch.push_back(u);
        if (m_currentBatch.size() >= 10000) flushBatch();
    }

    void drawGradientRect(float x, float y, float w, float h, uint32_t ct, uint32_t cb) override {
        drawNative(x, y, w, h, 0, 0, 0, ct, cb, false);
    }

    void drawRoundedRect(float x, float y, float w, float h, float r, uint32_t c) override {
        drawNative(x, y, w, h, r, 0, 0, c, c, false);
    }

    void drawDropShadow(float x, float y, float w, float h, float radius, uint32_t color) override {
        // Draw an outer glow/shadow by using the SDF shader with a high "shadow" value (blur)
        // We expand the rect slightly for the shadow falloff
        float blur = 5.0f;
        drawNative(x - blur, y - blur, w + blur*2, h + blur*2, radius + blur, 0, blur, color, color, false);
    }

    void drawFilledPath(const std::vector<float>& p, uint32_t c) override {
        // Simple implementation: bounding box or triangulation would be better, 
        // but for EQ/Waveforms we use the strip logic
        if (p.size() < 4) return;
        drawBezierPath(p, c, 1.0f); // Fallback
    }

    void drawCircle(float x, float y, float r, uint32_t c) override {
        drawNative(x - r, y - r, r * 2, r * 2, r, 0, 0, c, c, false);
    }

    void drawLine(float x1, float y1, float x2, float y2, float thickness, uint32_t color) override {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float length = std::sqrt(dx * dx + dy * dy);
        if (length < 0.01f) return;
        
        // Horizontal/Vertical optimization for simple rects
        if (std::abs(dx) < 0.1f) drawRoundedRect(x1 - thickness/2, y1, thickness, std::abs(dy), 0, color);
        else if (std::abs(dy) < 0.1f) drawRoundedRect(std::min(x1, x2), y1 - thickness/2, std::abs(dx), thickness, 0, color);
        else {
            drawNative(std::min(x1, x2), std::min(y1, y2), std::max(1.0f, std::abs(dx)), std::max(1.0f, std::abs(dy)), 0, 0, 0, color, color, false);
        }
    }

    void drawText(const std::string& t, float x, float y, float s, uint32_t c) override {
        if (!m_encoder || t.empty()) return;
        id<MTLTexture> tex = getCachedTextTexture(t, s);
        if (!tex) return;

        [m_encoder setFragmentTexture:tex atIndex:0];
        drawNative(x, y, (float)tex.width, (float)tex.height, 0, 0, 0, c, c, true);
        [m_encoder setFragmentTexture:nil atIndex:0];
    }

    id<MTLTexture> getCachedTextTexture(const std::string& text, float size) {
        std::string key = text + std::to_string((int)size);
        if (m_textCache.count(key)) return m_textCache[key];

        NSString* nsText = [NSString stringWithUTF8String:text.c_str()];
        NSFont* font = [NSFont systemFontOfSize:size weight:NSFontWeightMedium];
        NSDictionary* attr = @{ NSFontAttributeName: font, NSForegroundColorAttributeName: [NSColor whiteColor] };
        NSSize sz = [nsText sizeWithAttributes:attr];
        if (sz.width < 1 || sz.height < 1) return nil;

        int width = (int)ceil(sz.width);
        int height = (int)ceil(sz.height);
        
        NSMutableData* data = [NSMutableData dataWithLength:width * height * 4];
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGContextRef context = CGBitmapContextCreate([data mutableBytes], width, height, 8, width * 4, colorSpace, kCGImageAlphaPremultipliedLast);
        
        NSGraphicsContext* nsContext = [NSGraphicsContext graphicsContextWithCGContext:context flipped:NO];
        [NSGraphicsContext setCurrentContext:nsContext];
        [nsText drawAtPoint:NSMakePoint(0, 0) withAttributes:attr];
        
        MTLTextureDescriptor* td = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm width:width height:height mipmapped:NO];
        id<MTLTexture> tex = [m_device newTextureWithDescriptor:td];
        [tex replaceRegion:MTLRegionMake2D(0, 0, width, height) mipmapLevel:0 withBytes:[data bytes] bytesPerRow:width * 4];
        
        CGContextRelease(context);
        CGColorSpaceRelease(colorSpace);
        
        m_textCache[key] = tex;
        return tex;
    }

    void drawBezierPath(const std::vector<float>& p, uint32_t c, float t) override {
        if (!m_encoder || p.size() < 4) return;
        for(size_t i = 0; i < p.size() - 2; i += 2) {
            drawLine(p[i], p[i+1], p[i+2], p[i+3], t, c);
        }
    }

    void updateSpectrogram(const std::vector<float>& data) override {}
    void drawMeter(uint32_t t, float l, float r, float x, float y, float w, float h) override {
        // --- 1. METER BACKGROUND ---
        drawRoundedRect(x, y, w, h, 1.0f, 0xFF000000); // Deep Black slot
        
        float chW = (w - 3.0f) / 2.0f; // Width per channel (L/R)
        float gutter = 1.0f;
        
        auto drawChannel = [&](float level, float cx) {
            float innerH = h - 2.0f;
            float fillH = innerH * std::clamp(level, 0.0f, 1.0f);
            
            // Draw segment background (dimly lit slots)
            for(int i = 0; i < 20; ++i) {
                float segY = y + innerH - (i + 1) * (innerH / 20.0f);
                uint32_t segBase = (i > 16) ? 0x22FF0000 : (i > 12) ? 0x22FFAA00 : 0x2200FF00;
                drawRoundedRect(cx, segY, chW, (innerH / 20.0f) - 1.0f, 0, segBase);
            }
            
            // Draw active segments (High-Intensity Glow)
            int activeSegs = (int)(level * 20.0f);
            for(int i = 0; i < activeSegs; ++i) {
                float segY = y + innerH - (i + 1) * (innerH / 20.0f);
                uint32_t segCol = (i > 16) ? 0xFFFF3333 : (i > 12) ? 0xFFFFAA00 : 0xFF33FF99;
                drawRoundedRect(cx, segY, chW, (innerH / 20.0f) - 1.0f, 1.0f, segCol);
            }

            // Peak Indicator (Thin White Line)
            if (level > 0.01f) {
                float peakY = y + innerH - (level * innerH);
                drawRoundedRect(cx, peakY, chW, 1.0f, 0, 0xFFFFFFFF);
            }
        };

        drawChannel(l, x + gutter);
        drawChannel(r, x + gutter + chW + gutter);
    }
    void applyBlurEffect(float x, float y, float w, float h, float intensity) override {
        // [REAL GAUSSIAN BLUR WOULD GO HERE]
        // For now, we simulate the "Glass" look by drawing a semi-transparent, brightened overlay
        // which gives the appearance of frosted glass when combined with the clearColor background.
        uint32_t glassColor = 0x11FFFFFF; // Very subtle white wash
        drawRoundedRect(x, y, w, h, 0, glassColor);
    }
    std::string getBackendName() const override { return "Apple Metal (Native)"; }

private:
    MTKView* m_view;
    id<MTLDevice> m_device;
    id<MTLCommandQueue> m_commandQueue;
    id<MTLCommandBuffer> m_commandBuffer;
    id<MTLRenderCommandEncoder> m_encoder;
    MTLRenderPassDescriptor* m_renderPassDescriptor;
    id<MTLRenderPipelineState> m_pipelineState;
    id<MTLBuffer> m_batchBuffer;
    std::vector<Uniforms> m_currentBatch;
    std::map<std::string, id<MTLTexture>> m_textCache;
};

std::unique_ptr<IGraphicsKernel> GraphicsFactory::createDefault() {
    return std::make_unique<MetalKernel>();
}

} // namespace Aura::Graphics::Platform
