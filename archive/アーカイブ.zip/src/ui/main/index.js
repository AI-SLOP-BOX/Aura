/**
 * @file index.js (Aura DAW UI Controller)
 * @description Logic Pro-inspired UI hydration and event-handling.
 */
document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('main-step-grid');
    const toggleMixerBtn = document.getElementById('btn-toggle-mixer');
    const mixer = document.getElementById('mixer');

    // 1. HYDRATE STEP SEQUENCER MATRIX (Logic Pro Colored Grid)
    // 16th Note resolution, 16 Lanes (General MIDI standard)
    const numLanes = 16;
    const numSteps = 32;

    for (let l = 0; l < numLanes; l++) {
        for (let s = 0; s < numSteps; s++) {
            const cell = document.createElement('div');
            cell.className = 'step-cell';

            // Logic Pro Style: Color rows differently for groupings (Drums/Percussion)
            if (l < 4) cell.style.borderColor = "#FF3B30"; // Kicks/Snares
            else if (l < 8) cell.style.borderColor = "#29FF42"; // Hats/Cymbal
            else cell.style.borderColor = "#3B9EFF"; // Perc/FX

            // Toggle Logic
            cell.onclick = () => {
                cell.classList.toggle('active');
                // notify_engine(l, s, cell.classList.contains('active'));
            };

            grid.appendChild(cell);
        }
    }

    // 2. MIXER TOGGLE (Collapsible view)
    let mixerOpen = false;
    toggleMixerBtn.onclick = () => {
        mixerOpen = !mixerOpen;
        mixer.classList.toggle('open', mixerOpen);
        toggleMixerBtn.classList.toggle('active', mixerOpen);
    };

    // 3. TRANSPORT (Aura Engine Bridge)
    const playBtn = document.getElementById('btn-play');
    const stopBtn = document.getElementById('btn-stop');
    const lcdTop = document.querySelector('.lcd-segment-top');

    let playing = false;
    let timer = 0;

    playBtn.onclick = () => {
        playing = !playing;
        playBtn.innerText = playing ? "II" : ">";
        playBtn.style.color = playing ? "#29FF42" : "#FFF";
    };

    stopBtn.onclick = () => {
        playing = false;
        timer = 0;
        playBtn.innerText = ">";
        playBtn.style.color = "#FFF";
        lcdTop.innerText = "1 1 1 1";
    };

    // --- ANIMATION LOOP: UI Telemetry ---
    setInterval(() => {
        if (playing) {
            timer++;
            const bar = Math.floor(timer / 16) + 1;
            const beat = Math.floor((timer % 16) / 4) + 1;
            const step = (timer % 4) + 1;
            lcdTop.innerText = `${bar} ${beat} ${step} 1`;
        }
    }, 125); // 120BPM 16th notes approx.
});
