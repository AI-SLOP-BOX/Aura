#pragma once

#include <cmath>
#include <algorithm>
#include <atomic>

namespace Aura::UI::Main {

/**
 * @brief MeterProcessor: Professional level meter ballistics.
 * Converts raw signal peaks into musically intuitive VU-style visuals with peak-hold.
 */
class MeterProcessor {
public:
    explicit MeterProcessor(double sampleRate) : m_sampleRate(sampleRate) {}

    /**
     * @brief Updates the meter value with ballistic decay.
     * @param rawPeak: The linear normalized peak from the audio engine (0.0 to 1.0).
     */
    void update(float rawPeak) {
        // 1. LOG SCALING: Linear normalized 0-1.0 to dB scale.
        float dB = (rawPeak > 1e-6f) ? 20.0f * std::log10(rawPeak) : -100.0f;
        
        // 2. BALLISTICS: Decay logic (approx 300ms for VU standard)
        if (dB > m_currentVUDecibels) {
            m_currentVUDecibels = dB; // Instant attack
        } else {
            // Smooth decay: -20dB per second for high-end "Vibe"
            float decayStep = 20.0f / m_sampleRate;
            m_currentVUDecibels -= decayStep;
        }

        // 3. PEAK HOLD: Persistence
        if (dB > m_peakHoldDecibels) {
            m_peakHoldDecibels = dB;
            m_peakTimer = 0;
        } else {
            m_peakTimer++;
            if (m_peakTimer > (m_sampleRate * 2.0)) { // 2 second hold
                m_peakHoldDecibels = -100.0f;
            }
        }
    }

    float getVUDecibels() const { return m_currentVUDecibels.load(); }
    float getPeakHoldDecibels() const { return m_peakHoldDecibels.load(); }

private:
    double m_sampleRate;
    std::atomic<float> m_currentVUDecibels{-100.0f};
    std::atomic<float> m_peakHoldDecibels{-100.0f};
    uint64_t m_peakTimer = 0;
};

} // namespace Aura::UI::Main
