#pragma once

#include "graphics/ui_components/waveform_renderer.hpp"
#include "graphics/ui_components/smart_controls_ui.hpp"
#include "graphics/ui_components/piano_roll_renderer.hpp"
#include "graphics/ui_components/aura_pro_ui.hpp"
#include "core/engine/param_tree.hpp"
#include "ui/mixer/channel_strip.hpp"
#include "core/engine/timeline_system.hpp"
#include "AuraUltimate.hpp"
#include <iostream>

namespace Aura::UI::Main {

struct Theme {
    uint32_t bgMain = 0xFF0A0A0B;
    uint32_t bgTrackOdd = 0xFF141416;
    uint32_t bgTrackEven = 0xFF1A1A1C;
    uint32_t bgHeader = 0xFF1C1C1E;
    uint32_t accentBlue = 0xFF3B9EFF;
    uint32_t regionBlue = 0xFF2B8EDF;
    uint32_t textPrimary = 0xFFE0E0E0;
    uint32_t playheadRed = 0xFFFF3B30;
};

class AuraWorkspace {
public:
    static AuraWorkspace& getInstance() {
        static AuraWorkspace instance;
        return instance;
    }

    void initialize(float w, float h) { m_width = w; m_height = h; }

    void render(Graphics::Platform::IGraphicsKernel& kernel) {
        // --- THE AURA PRO ULTIMATE UI (METAL OPTIMIZED + LIVE ENGINE) ---
        m_proUI.render(kernel, m_width, m_height, Aura::AuraEngine::getInstance());
    }

    // HIT TESTING & INTERACTION
    void handleMouseDown(float x, float y) {
        m_draggedRegion = nullptr;
        
        float transportH = 56.0f, toolbarH = 36.0f, rulerH = 34.0f;
        float inspectorW = (m_width < 1000) ? 0.0f : 240.0f; 
        float editorH = std::max(300.0f, std::min(550.0f, m_height * 0.45f)); 
        
        auto& engine = Aura::AuraEngine::getInstance();
        auto& timeline = engine.getTimeline();

        // --- TRANSPORT HIT TESTING ---
        if (y >= 8 && y <= 38) {
            if (x >= 10 && x <= 50) { timeline.setPlaying(false); return; } // STOP
            if (x >= 50 && x <= 90) { timeline.setPlaying(true); return; }  // PLAY
        }

        if (x < inspectorW || y < timey || y > m_height - editorH) return;

        auto& timeline = Aura::AuraEngine::getInstance().getTimeline();
        auto& tracks = timeline.getTracks();
        float th = (m_height < 800) ? 90.0f : 110.0f;

        for (size_t t = 0; t < tracks.size(); ++t) {
            float ty = timey + (t * (th + 1));
            if (y >= ty && y < ty + th) {
                if (x < timex) return; // Inside header
                for (auto& region : tracks[t]->getAudioRegions()) {
                    float rx = timex + (region->getMeta().samplePosition * m_timeScale);
                    float rw = region->getMeta().sampleLength * m_timeScale;
                    if (x >= rx && x < rx + rw) {
                        m_draggedRegion = region.get();
                        m_dragStartSamples = region->getMeta().samplePosition;
                        m_clickX = x;
                        return;
                    }
                }
            }
        }
    }

    void handleMouseDrag(float x, float y) {
        if (m_draggedRegion) {
            float dx = x - m_clickX;
            int64_t dSamples = static_cast<int64_t>(dx / m_timeScale);
            int64_t newPos = static_cast<int64_t>(m_dragStartSamples) + dSamples;
            if (newPos < 0) newPos = 0;
            m_draggedRegion->setSamplePosition(static_cast<uint64_t>(newPos));
        }
    }

    void handleMouseUp(float x, float y) { m_draggedRegion = nullptr; }

private:
    Aura::Graphics::UI::AuraProUI m_proUI;
    AuraWorkspace() = default;
    float m_width = 1280, m_height = 800;
    float m_trackHeight = 100, m_headerWidth = 250, m_timeScale = 0.05f, m_offsetTop = 60.0f;
    Theme m_theme;
    Aura::Core::AudioRegion* m_draggedRegion = nullptr;
    uint64_t m_dragStartSamples = 0;
    float m_clickX = 0;
};

} // namespace Aura::UI::Main
