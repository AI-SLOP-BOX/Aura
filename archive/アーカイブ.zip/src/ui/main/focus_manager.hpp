#pragma once

#include <string>
#include <map>
#include <memory>

namespace Aura::UI::Main {

/**
 * @brief FocusManager: Orchestrates UI focus and keyboard event routing.
 * Ensures the DAW responds correctly to shortcuts within the active pane.
 */
class FocusManager {
public:
    enum class PaneType { Timeline, Mixer, Inspector, Editor };

    static FocusManager& getInstance() {
        static FocusManager instance;
        return instance;
    }

    void setFocus(PaneType type) { m_focusedPane = type; }
    PaneType getFocusedPane() const { return m_focusedPane; }

    /**
     * @brief Routes key events to the focused pane.
     */
    void onKeyEvent(int keyCode, bool isDown) {
        // Logic Pro-style Command+X/C/V routing based on focus
    }

private:
    FocusManager() : m_focusedPane(PaneType::Timeline) {}
    PaneType m_focusedPane;
};

} // namespace Aura::UI::Main
