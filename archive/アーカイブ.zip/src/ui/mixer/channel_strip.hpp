#pragma once

#include <string>
#include <vector>
#include <memory>
#include "../../core/engine/param_tree.hpp"

namespace Aura::UI::Mixer {

/**
 * @brief ChannelStrip: The professional visual unit of the Aura Mixer.
 * Every track has one, containing Fader, Meter, Panning, and Plugin Inserts.
 */
class ChannelStrip {
public:
    struct Layout {
        float x, y, width, height;
        float faderPos; // 0.0 - 1.0 (internal visual)
    };

    ChannelStrip(uint32_t trackId, const std::string& name) 
        : m_trackId(trackId), m_name(name) {
        
        // Link to global Parameter IDs (Standard Mixer Range)
        m_gainParamId = 2000 + (trackId * 10) + 0; // gain
        m_panParamId  = 2000 + (trackId * 10) + 1; // pan

        auto& tree = Core::Engine::ParamTree::getInstance();
        tree.registerParam(m_gainParamId, "Fader", -48.0f, 0.0f, -6.0f);
        tree.registerParam(m_panParamId, "Pan", -1.0f, 1.0f, 0.0f);
    }

    void setLayout(Layout l) { m_layout = l; }
    const Layout& getLayout() const { return m_layout; }
    
    uint32_t getTrackId() const { return m_trackId; }
    const std::string& getName() const { return m_name; }

    uint32_t getGainParamId() const { return m_gainParamId; }
    uint32_t getPanParamId() const { return m_panParamId; }

private:
    uint32_t m_trackId;
    std::string m_name;
    uint32_t m_gainParamId;
    uint32_t m_panParamId;
    Layout m_layout;
};

/**
 * @brief MixerConsole: The "Main Mixer Page" of Aura DAW.
 */
class MixerConsole {
public:
    static MixerConsole& getInstance() {
        static MixerConsole instance;
        return instance;
    }

    void addStrip(uint32_t trackId, const std::string& name) {
        m_strips.push_back(std::make_shared<ChannelStrip>(trackId, name));
        recalculateLayout();
    }

    const std::vector<std::shared_ptr<ChannelStrip>>& getStrips() const { return m_strips; }

private:
    MixerConsole() = default;

    void recalculateLayout() {
        float x = 0;
        float stripWidth = 100.0f; // Standard DAW strip width
        for (auto& s : m_strips) {
            s->setLayout({x, 600.0f, stripWidth, 400.0f, 0.7f});
            x += stripWidth;
        }
    }

    std::vector<std::shared_ptr<ChannelStrip>> m_strips;
};

} // namespace Aura::UI::Mixer
