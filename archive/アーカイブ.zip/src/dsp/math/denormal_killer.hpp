#pragma once

#include <cmath>
#include <xmmintrin.h>

namespace Aura::DSP::Math {

/**
 * @brief DenormalNumberKiller: Prevents CPU spikes caused by Denormal floating point numbers.
 * Essential Logic Pro-grade protection for high-precision DSP calculations.
 */
class DenormalNumberKiller {
public:
    /**
     * @brief Sets the CPU flags to Flush-To-Zero (FTZ) and Denormals-Are-Zero (DAZ).
     * This physically prevents the CPU from falling into the slow denormal path.
     */
    static void setDenormalFlags() {
#if defined(__x86_64__) || defined(_M_X64) || defined(i386) || defined(_M_IX86)
        _mm_setcsr(_mm_getcsr() | 0x8040); // FTZ & DAZ
#endif
    }

    /**
     * @brief Adds a tiny, inaudible DC offset to a signal to prevent it from decaying to denormal levels.
     */
    static float kill(float s) {
        return s + 1e-25f; // Constant micro-noise to keep the signal "alive" in floating point space
    }
};

} // namespace Aura::DSP::Math
