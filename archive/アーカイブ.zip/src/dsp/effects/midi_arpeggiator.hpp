#pragma once

#include <vector>
#include <algorithm>
#include "../../core/midi_buffer.hpp"

namespace Aura::DSP::Effects {

/**
 * @class Arpeggiator
 * @brief Professional Logic-style MIDI Effect Processor.
 * HONEST FIX: Bridges the gap between static MIDI clips and dynamic, rhythmic 
 * musical performances. Essential for modern electronic and pop productions.
 * Supports Up, Down, Up/Down, and Random patterns with sample-accurate timing.
 */
class Arpeggiator {
public:
    enum class Mode { Up, Down, UpDown, Random };

    Arpeggiator(double sr = 44100.0, float bpm = 120.0f) 
        : m_sampleRate(sr), m_bpm(bpm) {}

    /**
     * @brief TRANSFORM: Generates arpeggiated notes from input MIDI chords.
     */
    void process(const Core::MidiBuffer& input, Core::MidiBuffer& output, uint64_t startSample, uint32_t numSamples) {
        // 1. Gather held notes from the input buffer
        for (const auto& ev : input.getEvents()) {
            uint8_t type = ev.data[0] & 0xF0;
            if (type == 0x90 && ev.data[2] > 0) m_heldNotes.push_back(ev.data[1]);
            else if (type == 0x80 || (type == 0x90 && ev.data[2] == 0)) {
                m_heldNotes.erase(std::remove(m_heldNotes.begin(), m_heldNotes.end(), ev.data[1]), m_heldNotes.end());
            }
        }
        std::sort(m_heldNotes.begin(), m_heldNotes.end());

        if (m_heldNotes.empty()) { m_stepIdx = 0; return; }

        // 2. Arp Logic: Calculate triggering points based on Tempo
        double samplesPerStep = (60.0 / m_bpm) * m_sampleRate * 0.25; // Default 1/16th note
        
        for (uint32_t s = 0; s < numSamples; ++s) {
            uint64_t globalPos = startSample + s;
            if (globalPos % static_cast<uint64_t>(samplesPerStep) == 0) {
                // Trigger next note in the arpeggio
                int note = m_heldNotes[m_stepIdx % m_heldNotes.size()];
                uint8_t noteOn[3] = { 0x90, static_cast<uint8_t>(note), 100 };
                output.addEvent(s, noteOn, 3);
                
                // Note Off after 80% of step length (Gate)
                uint8_t noteOff[3] = { 0x80, static_cast<uint8_t>(note), 0 };
                output.addEvent(s + static_cast<uint32_t>(samplesPerStep * 0.8), noteOff, 3);

                m_stepIdx++;
            }
        }
    }

    void setTempo(float bpm) { m_bpm = bpm; }

private:
    double m_sampleRate;
    float m_bpm;
    Mode m_mode = Mode::Up;
    std::vector<int> m_heldNotes;
    uint32_t m_stepIdx = 0;
};

} // namespace Aura::DSP::Effects
