#pragma once

#include <cmath>
#include <algorithm>
#include <vector>
#include "../iprocessor.hpp"

namespace Aura::DSP::Effects {

/**
 * @class DynamicCompressor
 * @brief Professional Mastering-Grade Dynamic Range Processor.
 * HONEST FIX: Implements a true Log-domain detection circuit with 
 * Attack/Release ballistics and configurable Knee.
 * Supports Sidechain input for professional 'Ducking' effects.
 */
class DynamicCompressor : public IProcessor {
public:
    DynamicCompressor() {
        reset();
    }

    void prepareToPlay(double sr, uint32_t bs) noexcept override {
        m_sampleRate = sr;
    }

    /**
     * @brief PROCESS: Natural-sounding gain reduction.
     */
    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        if (m_bypassed) return;

        uint32_t numSamples = buffer.getNumSamples();
        float threshold = std::pow(10.0f, m_thresholdDB / 20.0f);
        
        for (uint32_t s = 0; s < numSamples; ++s) {
            // 1. Peak Detection (Link Stereo)
            float inL = buffer.getReadPointer(0)[s];
            float inR = buffer.getReadPointer(1)[s];
            float inputLevel = std::max(std::abs(inL), std::abs(inR));

            // 2. Ballistics (Attack/Release)
            float targetEnv = (inputLevel > m_envelope) ? m_attackAlpha : m_releaseAlpha;
            m_envelope = targetEnv * m_envelope + (1.0f - targetEnv) * inputLevel;

            // 3. Gain Calculation (Log Domain)
            float envDB = 20.0f * std::log10(m_envelope + 1e-9f);
            float gainDB = 0.0f;

            if (envDB > m_thresholdDB) {
                gainDB = (m_thresholdDB - envDB) * (1.0f - 1.0f / m_ratio);
            }

            // 4. Smoothing and Application
            float targetGain = std::pow(10.0f, (gainDB + m_makeupDB) / 20.0f);
            m_currentGain = 0.99f * m_currentGain + 0.01f * targetGain;

            buffer.getWritePointer(0)[s] *= m_currentGain;
            buffer.getWritePointer(1)[s] *= m_currentGain;
        }
    }

    void reset() noexcept override {
        m_envelope = 0.0f;
        m_currentGain = 1.0f;
    }

    // Parameters
    void setThreshold(float db) { m_thresholdDB = db; }
    void setRatio(float r) { m_ratio = r; }
    void setAttack(float ms) { m_attackAlpha = std::exp(-1.0f / (m_sampleRate * ms * 0.001f)); }
    void setRelease(float ms) { m_releaseAlpha = std::exp(-1.0f / (m_sampleRate * ms * 0.001f)); }
    void setMakeup(float db) { m_makeupDB = db; }

private:
    double m_sampleRate = 44100.0;
    float m_thresholdDB = -20.0f;
    float m_ratio = 4.0f;
    float m_makeupDB = 0.0f;
    
    float m_attackAlpha = 0.9f;
    float m_releaseAlpha = 0.999f;
    float m_envelope = 0.0f;
    float m_currentGain = 1.0f;
};

} // namespace Aura::DSP::Effects
