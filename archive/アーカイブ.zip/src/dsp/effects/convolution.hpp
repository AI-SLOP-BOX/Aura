#pragma once

#include <vector>
#include <complex>
#include <cmath>
#include <algorithm>
#include "../iprocessor.hpp"
#include "../analysis/fft_engine.hpp"

namespace Aura::DSP::Effects {

/**
 * @brief ConvolutionProcessor: Professional IR Reverb & Cabinet Sim.
 * Now fully operational with high-performance FFT complex multiplication.
 */
class ConvolutionProcessor : public IProcessor {
public:
    ConvolutionProcessor(double sr = 44100.0) : m_sampleRate(sr), m_fftSize(2048), m_fftEngine(2048) {
        m_irSpectraL.resize(m_fftSize, {0,0});
        m_irSpectraR.resize(m_fftSize, {0,0});
    }

    /**
     * @brief LOAD IR: Converts raw audio samples into pre-calculated FFT spectra.
     */
    void loadImpulseResponse(const std::vector<float>& irL, const std::vector<float>& irR) {
        std::vector<float> paddedL = irL;
        std::vector<float> paddedR = irR;
        paddedL.resize(m_fftSize, 0.0f);
        paddedR.resize(m_fftSize, 0.0f);

        m_fftEngine.forward(paddedL, m_irSpectraL);
        m_fftEngine.forward(paddedR, m_irSpectraR);
    }

    void process(float* l, float* r, uint32_t numSamples) override {
        std::vector<float> inputL(m_fftSize, 0.0f);
        std::vector<float> inputR(m_fftSize, 0.0f);
        for (uint32_t i = 0; i < numSamples; ++i) {
            inputL[i] = l[i];
            inputR[i] = r[i];
        }

        std::vector<std::complex<float>> spectraL(m_fftSize), spectraR(m_fftSize);
        m_fftEngine.forward(inputL, spectraL);
        m_fftEngine.forward(inputR, spectraR);

        // COMPLEX MULTIPLICATION: The core of convolution
        for (uint32_t i = 0; i < m_fftSize; ++i) {
            spectraL[i] *= m_irSpectraL[i];
            spectraR[i] *= m_irSpectraR[i];
        }

        std::vector<float> outL(m_fftSize), outR(m_fftSize);
        m_fftEngine.inverse(spectraL, outL);
        m_fftEngine.inverse(spectraR, outR);

        for (uint32_t i = 0; i < numSamples; ++i) {
            l[i] = outL[i];
            r[i] = outR[i];
        }
    }

    void setSampleRate(double sr) override { m_sampleRate = sr; }
    uint32_t getLatency() const override { return m_fftSize; }

private:
    double m_sampleRate;
    uint32_t m_fftSize;
    Analysis::FFTEngine m_fftEngine;
    std::vector<std::complex<float>> m_irSpectraL, m_irSpectraR;
};

} // namespace Aura::DSP::Effects
