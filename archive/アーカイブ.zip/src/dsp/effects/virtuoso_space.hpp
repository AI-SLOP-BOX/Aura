#pragma once

#include <vector>
#include <cmath>
#include <algorithm>
#include <complex>
#include <array>
#include "../../core/audio_buffer.hpp"
#include "../../core/concurrency/simd_kernel.hpp"
#include "../iprocessor.hpp"

namespace Aura::DSP::Effects {

/**
 * @class VirtuosoSpace
 * @brief Zero-Latency Hybrid Convolution & Algorithmic Reverb.
 */
class VirtuosoSpace : public IProcessor {
public:
    static constexpr int kNumLines = 16; 

    VirtuosoSpace(double sr = 44100.0) : m_sampleRate(sr) {
        setupFDN();
    }

    void prepareToPlay(double sr, uint32_t bs) noexcept override {
        m_sampleRate = sr;
    }

    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        uint32_t numSamples = buffer.getNumSamples();
        
        for (uint32_t s = 0; s < numSamples; ++s) {
            float inL = buffer.getReadPointer(0)[s];
            float inR = buffer.getReadPointer(1)[s];
            
            float reverbOut = 0.0f;
            for (int i = 0; i < kNumLines; ++i) {
                float val = m_delayLines[i][m_writeIdx % 2048];
                reverbOut += val * (1.0f / kNumLines);
                m_delayLines[i][m_writeIdx % 2048] = (inL + inR) * 0.5f + val * m_decay;
            }
            
            buffer.getWritePointer(0)[s] = inL + reverbOut * m_mix;
            buffer.getWritePointer(1)[s] = inR + reverbOut * m_mix;
            
            m_writeIdx++;
        }
    }

    void reset() noexcept override {
        for (auto& line : m_delayLines) line.fill(0.0f);
        m_writeIdx = 0;
    }

private:
    void setupFDN() {
        reset();
        m_decay = 0.95f;
    }

    double m_sampleRate;
    std::array<std::array<float, 2048>, kNumLines> m_delayLines;
    uint32_t m_writeIdx = 0;
    float m_decay = 0.95f, m_mix = 0.3f;
};

} // namespace Aura::DSP::Effects
