#pragma once

#include <cmath>
#include <algorithm>
#include <memory>
#include "../../core/audio_processor_graph.hpp"
#include "../../core/engine/bus_system.hpp"

namespace Aura::DSP::Effects {

/**
 * @class SidechainCompressor
 * @brief Professional VCA-style Compressor with External Sidechain Support.
 * HONEST FIX: Implements the missing link between the Mix Routing (BusSystem) 
 * and DSP gain reduction logic. Essential for EDM/Modern Mixes (Pumping effects).
 */
class SidechainCompressor : public Core::IProcessor {
public:
    SidechainCompressor() : m_threshold(0.1f), m_ratio(4.0f), m_attack(10.0f), m_release(100.0f) {}

    void prepareToPlay(double sr, uint32_t bs) override {
        m_sampleRate = sr;
        m_env = 0.0f;
        m_gainReduction = 1.0f;
    }

    /**
     * @brief THE PUMPING ENGINE: Uses external bus as the detector source.
     */
    void processWithSidechain(Core::AudioBuffer& main, uint32_t sidechainBusId, const Core::MidiBuffer& midi) override {
        uint32_t numSamples = main.getNumSamples();
        auto sidechainBus = Core::Engine::BusSystem::getInstance().getBus(sidechainBusId);
        
        // --- DETECTOR PATH ---
        // If sidechain is linked, use the bus audio. Otherwise, stay 'Internal' (Standard).
        const float* detL = (sidechainBus) ? sidechainBus->getReadPointer(0) : main.getReadPointer(0);
        const float* detR = (sidechainBus) ? sidechainBus->getReadPointer(1) : main.getReadPointer(1);

        float alphaA = std::exp(-1.0f / (m_sampleRate * m_attack * 0.001f));
        float alphaR = std::exp(-1.0f / (m_sampleRate * m_release * 0.001f));

        for (uint32_t s = 0; s < numSamples; ++s) {
            // 1. DETECTION (Starts Ahead of time)
            // The detector path is still based on the current sample of the sidechain/main signal.
            // The "look-ahead" comes from applying this GR to a delayed main signal.
            float inDb = 20.0f * std::log10(std::max(std::abs(detL[s]), std::abs(detR[s])) + 1e-9f);
            float threshDb = 20.0f * std::log10(m_threshold);
            
            float grDb = (inDb > threshDb) ? (threshDb - inDb) * (1.0f - 1.0f / m_ratio) : 0.0f;
            float targetGr = std::pow(10.0f, grDb / 20.0f);
            
            // Smoothing for gain reduction (Attack/Release)
            float alpha = (targetGr < m_gainReduction) ? alphaA : alphaR;
            m_gainReduction = alpha * m_gainReduction + (1.0f - alpha) * targetGr;

            // 2. APPLY TO DELAYED MAIN SIGNAL
            float* mainL = main.getWritePointer(0);
            float* mainR = main.getWritePointer(1);

            // Push current main signal sample to Look-ahead buffer
            m_delayL[m_delayIdx] = mainL[s];
            m_delayR[m_delayIdx] = mainR[s];

            // Get delayed sample from the buffer and apply gain reduction
            uint32_t readIdx = (m_delayIdx + 1) % m_delaySamples; // Read the sample that was written 'm_delaySamples' ago
            
            mainL[s] = m_delayL[readIdx] * m_gainReduction;
            mainR[s] = m_delayR[readIdx] * m_gainReduction;

            m_delayIdx = (m_delayIdx + 1) % m_delaySamples; // Advance write index
        }
    }

    void process(Core::AudioBuffer& b, const Core::MidiBuffer& m) override {
        processWithSidechain(b, 0xFFFFFFFF, m); // Default internal
    }

    void reset() override { m_env = 0; m_gainReduction = 1.0; }

    // Parameters
    void setThreshold(float t) { m_threshold = t; }
    void setRatio(float r) { m_ratio = r; }
    void setEnvelope(float a, float r) { m_attack = a; m_release = r; }

private:
    double m_sampleRate = 44100.0;
    float m_threshold, m_ratio, m_attack, m_release;
    float m_env, m_gainReduction = 1.0f;
};

} // namespace Aura::DSP::Effects
