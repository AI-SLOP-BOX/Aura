#pragma once

#include <vector>
#include <cmath>
#include <algorithm>
#include <random>
#include "../../core/audio_buffer.hpp"
#include "../../core/concurrency/simd_kernel.hpp"
#include "../iprocessor.hpp"

namespace Aura::DSP::Effects {

/**
 * @class VirtuosoTapeSaturator
 * @brief Professional Analog Tape Emulation & Warming Engine.
 */
class VirtuosoTapeSaturator : public IProcessor {
public:
    VirtuosoTapeSaturator(double sr = 44100.0) : m_sampleRate(sr) {
        reset();
    }

    void prepareToPlay(double sr, uint32_t bs) noexcept override {
        m_sampleRate = sr;
        m_lfoPhase = 0.0;
    }

    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        uint32_t numSamples = buffer.getNumSamples();
        float drive = std::pow(10.0f, m_driveDb / 20.0f);
        
        for (uint32_t c = 0; c < buffer.getNumChannels(); ++c) {
            float* samples = buffer.getWritePointer(c);
            
            for (uint32_t s = 0; s < numSamples; ++s) {
                float x = samples[s] * drive;
                float xAbs = std::abs(x);
                float y = (xAbs < 0.5f) ? x : (x > 0 ? (0.75f - std::pow(0.5f - xAbs, 2.0f)) : (-0.75f + std::pow(0.5f - xAbs, 2.0f)));
                
                m_lfoPhase += (2.0 * M_PI * m_flutterRate) / m_sampleRate;
                if (m_lfoPhase > 2.0 * M_PI) m_lfoPhase -= 2.0 * M_PI;
                
                samples[s] = (y * (1.0f - m_mix)) + (samples[s] * m_mix);
            }
        }
    }

    void setDrive(float db) { m_driveDb = db; }
    void setFlutter(float rate, float depth) { m_flutterRate = rate; m_flutterDepth = depth; }
    
    void reset() noexcept override { m_lfoPhase = 0.0; }

private:
    double m_sampleRate;
    double m_lfoPhase = 0.0;
    float m_driveDb = 6.0f;
    float m_mix = 0.5f;
    float m_flutterRate = 1.0f; 
    float m_flutterDepth = 0.0005f;
};

} // namespace Aura::DSP::Effects
