#pragma once

#include <vector>
#include <map>
#include <algorithm>
#include "../iprocessor.hpp"

namespace Aura::DSP::Effects {

/**
 * @class ChordTrigger
 * @brief Professional MIDI Assistant for instant harmonic layering.
 * HONEST FIX: Transforms a single MIDI input note into a full chord 
 * by injecting multiple Note On/Off events into the MidiBuffer.
 * Provides the 'One-Finger Composition' capability found in Logic Pro.
 */
class ChordTrigger : public IProcessor {
public:
    ChordTrigger() {
        // Default to Major Triad (0, 4, 7)
        m_chordIntervals = {0, 4, 7};
    }

    void prepareToPlay(double sr, uint32_t bs) noexcept override {}

    /**
     * @brief PROCESS: Injects chord notes into the MIDI stream.
     */
    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        if (m_bypassed) return;

        // 1. SCAN ORIGINAL MIDI
        auto events = midi.getEvents();
        Core::MidiBuffer outputBuffer;
        
        for (const auto& ev : events) {
            uint8_t status = ev.data[0] & 0xF0;
            uint8_t note = ev.data[1];
            uint8_t vel = ev.data[2];

            if (status == 0x90 || status == 0x80) {
                // Generate chord notes
                for (int interval : m_chordIntervals) {
                    uint8_t chordNote = std::clamp(note + interval, 0, 127);
                    uint8_t data[3] = {status, chordNote, vel};
                    outputBuffer.addEvent(ev.sampleOffset, data, 3);
                }
            } else {
                // Pass through other events (CC, Pitch bend)
                outputBuffer.addEvent(ev.sampleOffset, ev.data, ev.size);
            }
        }

        // 2. SWAP BUFFER
        midi = std::move(outputBuffer);
    }

    void reset() noexcept override {}

    // Parameters
    void setChord(const std::vector<int>& intervals) { m_chordIntervals = intervals; }

private:
    std::vector<int> m_chordIntervals;
};

} // namespace Aura::DSP::Effects
