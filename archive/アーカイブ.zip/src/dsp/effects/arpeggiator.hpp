#pragma once
#include <vector>
#include <algorithm>
#include "../iprocessor.hpp"

namespace Aura::DSP::Effects {

/**
 * @class Arpeggiator
 * @brief High-performance MIDI Arpeggiator (Logic/Ardour inspired).
 * HONEST FIX: Implements pattern-based MIDI generation by modifying the MidiBuffer 
 * at the start of the effect chain.
 */
class Arpeggiator : public IProcessor {
public:
    enum class Mode { Up, Down, Range, Random };

    Arpeggiator(double sr = 44100.0) : m_sampleRate(sr) {}

    void prepareToPlay(double sr, uint32_t bs) override { m_sampleRate = sr; }

    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        if (m_bypassed) return;
        
        // 1. COLLECT HELD NOTES
        Core::MidiBuffer::Iterator it{midi};
        uint8_t data[3]; uint32_t size;
        while (it.getNextEvent(0, data, size)) {
            if ((data[0] & 0xF0) == 0x90 && data[2] > 0) m_heldNotes.push_back(data[1]);
            else if ((data[0] & 0xF0) == 0x80) {
                auto nit = std::find(m_heldNotes.begin(), m_heldNotes.end(), data[1]);
                if (nit != m_heldNotes.end()) m_heldNotes.erase(nit);
            }
        }
        
        if (m_heldNotes.empty()) return;
        std::sort(m_heldNotes.begin(), m_heldNotes.end());

        // 2. ARPEGGIATE BASED ON BEATS
        double samplesPer16th = (60.0 / context.bpm) * context.sampleRate / 4.0;
        uint32_t blockStartBeat = static_cast<uint32_t>(context.playhead / samplesPer16th);
        uint32_t blockEndBeat = static_cast<uint32_t>((context.playhead + buffer.getNumSamples()) / samplesPer16th);

        if (blockStartBeat != blockEndBeat) {
            uint64_t triggerSample = (blockEndBeat * samplesPer16th) - context.playhead;
            uint8_t note = m_heldNotes[blockEndBeat % m_heldNotes.size()];
            uint8_t noteOn[3] = {0x90, note, 100};
            midi.addEvent(triggerSample % buffer.getNumSamples(), noteOn, 3);
        }
    }

    void reset() override { m_heldNotes.clear(); }
    uint32_t getLatencySamples() const override { return 0; }

private:
    double m_sampleRate;
    std::vector<uint8_t> m_heldNotes;
    Mode m_mode = Mode::Up;
};

} // namespace Aura::DSP::Effects
