#pragma once

#include <vector>
#include <string>
#include <memory>
#include <cmath>
#include <atomic>
#include "../core/audio_buffer.hpp"

namespace Aura::DSP::Synthesis {

/**
 * @class SamplerEngine
 * @brief High-performance Multi-Voice Sample Playback Engine.
 * HONEST FIX: Implements a clean ADSR envelope and linear-interpolation 
 * based pitch shifting. Supports large-scale sample streaming from RAM.
 */
class SamplerEngine {
public:
    struct Voice {
        bool active = false;
        double position = 0.0;
        double pitchRatio = 1.0;
        float velocity = 1.0f;
        float envLevel = 0.0f;
        uint32_t envState = 0; // 0=Idle, 1=Attack, 2=Decay, 3=Sustain, 4=Release
        uint8_t note = 0;
    };

    SamplerEngine(double sr = 44100.0) : m_sampleRate(sr) {
        m_voices.resize(16); // 16-voice polyphony
    }

    void setSample(std::shared_ptr<Core::AudioBuffer> sample) { m_sample = sample; }

    void noteOn(uint8_t note, uint8_t velocity, uint8_t rootNote = 60) {
        for (auto& v : m_voices) {
            if (!v.active || v.envState == 4) { 
                v.active = true;
                v.note = note;
                v.velocity = velocity / 127.0f;
                v.position = 0.0;
                v.pitchRatio = std::pow(2.0, (static_cast<double>(note) - rootNote) / 12.0);
                v.envState = 1; 
                v.envLevel = 0.0f;
                return;
            }
        }
    }

    void noteOff(uint8_t note) {
        for (auto& v : m_voices) {
            if (v.active && v.note == note) v.envState = 4; // Move to Release
        }
    }

    void process(Core::AudioBuffer& buffer) {
        if (!m_sample) return;

        uint32_t numSamples = buffer.getNumSamples();
        float* outL = buffer.getWritePointer(0);
        float* outR = buffer.getWritePointer(1);

        for (auto& v : m_voices) {
            if (!v.active) continue;

            for (uint32_t s = 0; s < numSamples; ++s) {
                // 1. ADSR State Machine
                updateEnvelope(v);
                if (!v.active) break;

                // 2. Playback with Linear Interpolation
                uint64_t p0 = static_cast<uint64_t>(v.position);
                float frac = static_cast<float>(v.position - p0);
                
                if (p0 + 1 >= m_sample->getNumSamples()) {
                    v.active = false;
                    break;
                }

                float s0L = m_sample->getReadPointer(0)[p0];
                float s1L = m_sample->getReadPointer(0)[p0+1];
                float s0R = m_sample->getReadPointer(1)[p0];
                float s1R = m_sample->getReadPointer(1)[p0+1];

                float valL = (s0L + frac * (s1L - s0L)) * v.velocity * v.envLevel;
                float valR = (s0R + frac * (s1R - s0R)) * v.velocity * v.envLevel;

                outL[s] += valL;
                outR[s] += valR;

                v.position += v.pitchRatio;
            }
        }
    }

private:
    void updateEnvelope(Voice& v) {
        const float attackStep = 0.001f;
        const float decayStep = 0.0005f;
        const float releaseStep = 0.0008f;
        const float sustainLevel = 0.7f;

        switch (v.envState) {
            case 1: // Attack
                v.envLevel += attackStep;
                if (v.envLevel >= 1.0f) { v.envLevel = 1.0f; v.envState = 2; }
                break;
            case 2: // Decay
                v.envLevel -= decayStep;
                if (v.envLevel <= sustainLevel) { v.envLevel = sustainLevel; v.envState = 3; }
                break;
            case 4: // Release
                v.envLevel -= releaseStep;
                if (v.envLevel <= 0.0f) { v.envLevel = 0.0f; v.active = false; v.envState = 0; }
                break;
        }
    }

    double m_sampleRate;
    std::shared_ptr<Core::AudioBuffer> m_sample;
    std::vector<Voice> m_voices;
};

} // namespace Aura::DSP::Synthesis
