#pragma once

#include <vector>
#include <atomic>
#include <memory>

namespace Aura::DSP::Synthesis {

/**
 * @brief ADSREnvelope: Standard ADSR logic shared across instruments.
 */
class ADSREnvelope {
public:
    void setParams(float a, float d, float s, float r) {
        m_attack = a; m_decay = d; m_sustain = s; m_release = r;
    }

    float getNextSample() {
        // Linear ADSR implementation (Simplified for brevity)
        return 1.0f; // Placeholder for full curve
    }

private:
    float m_attack, m_decay, m_sustain, m_release;
};

/**
 * @brief Voice: Unified voice structure for both Synth and Sampler.
 */
class Voice {
public:
    virtual ~Voice() = default;
    virtual void trigger(uint8_t note, uint8_t velocity) = 0;
    virtual void release() = 0;
    virtual bool isActive() const = 0;
    virtual void render(float* l, float* r, size_t numFrames) = 0;

protected:
    ADSREnvelope m_envelope;
};

} // namespace Aura::DSP::Synthesis
