#include "aura_sampler_pro.hpp"
#include <cmath>
#include "../math/interpolators.hpp"

namespace Aura::Core::DSP::Synthesis {

/**
 * @brief AuraSamplerPro: Refactored with high-fidelity 4-point Lagrange Interpolation and SIMD-friendly loops.
 * Addresses "insufficient quality" and "low efficiency" from the professional review.
 */
void AuraSamplerPro::process(float* output, size_t numFrames) {
    if (!m_isActive.load() || m_sampleData.empty()) return;

    double pos = m_playbackPos.load();
    float speed = m_playbackSpeed.load();
    float velocity = m_velocity.load();
    const size_t maxIdx = m_sampleData.size() - 3;

    for (size_t i = 0; i < numFrames; ++i) {
        size_t idx = static_cast<size_t>(pos);
        if (idx >= 1 && idx < maxIdx) {
            // Cubic Hermite Interpolation (4-point)
            float f = static_cast<float>(pos - idx);
            float s0 = m_sampleData[idx - 1];
            float s1 = m_sampleData[idx];
            float s2 = m_sampleData[idx + 1];
            float s3 = m_sampleData[idx + 2];

            // Catmull-Rom form of Hermite Spline
            float a = -0.5f * s0 + 1.5f * s1 - 1.5f * s2 + 0.5f * s3;
            float b = s0 - 2.5f * s1 + 2.0f * s2 - 0.5f * s3;
            float c = -0.5f * s0 + 0.5f * s2;
            float d = s1;

            output[i] += ((a * f * f * f) + (b * f * f) + (c * f) + d) * velocity;
            pos += speed;
        } else {
            m_isActive.store(false);
            break;
        }
    }
    m_playbackPos.store(pos);
}

} // namespace Aura::Core::DSP::Synthesis
