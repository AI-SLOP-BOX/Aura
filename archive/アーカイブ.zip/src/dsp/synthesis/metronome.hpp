#include <cmath>
#include <algorithm>
#include "../../core/engine/tempo_map.hpp"

namespace Aura::DSP::Synthesis {

/**
 * @class Metronome
 * @brief High-performance Damped-Sine Metronome.
 */
class Metronome {
public:
    Metronome(double sr = 44100.0) : m_sampleRate(sr), m_phase(0.0) {}

    void process(float* l, float* r, uint64_t startPos, double bpm, uint32_t len) {
        if (!m_isEnabled) return;

        double samplesPerBeat = (60.0 / bpm) * m_sampleRate;
        uint64_t nextBeatPos = static_cast<uint64_t>(std::ceil(static_cast<double>(startPos) / samplesPerBeat) * samplesPerBeat);

        for (uint32_t s = 0; s < len; ++s) {
            uint64_t pos = startPos + s;
            
            // Trigger Click
            if (pos == nextBeatPos) {
                m_clickCounter = static_cast<uint32_t>(m_sampleRate * 0.05); // 50ms total
                bool isDownbeat = (static_cast<int>(pos / samplesPerBeat) % 4 == 0);
                m_freq = isDownbeat ? 2200.0 : 1200.0;
                m_phase = 0.0;
                nextBeatPos += static_cast<uint64_t>(samplesPerBeat);
            }

            if (m_clickCounter > 0) {
                // Generate Damped Sine (Woodblock effect)
                float decay = static_cast<float>(m_clickCounter) / (m_sampleRate * 0.05f);
                float val = std::sin(m_phase) * decay * decay; // Squared decay for snappier feel
                
                l[s] += val * 0.4f;
                r[s] += val * 0.4f;
                
                m_phase += (2.0 * 3.1415926535 * m_freq) / m_sampleRate;
                m_clickCounter--;
            }
        }
    }

    void setEnabled(bool e) { m_isEnabled = e; }

private:
    double m_sampleRate;
    bool m_isEnabled = false;
    uint32_t m_clickCounter = 0;
    double m_freq = 1000.0, m_phase = 0.0;
};

} // namespace Aura::DSP::Synthesis
