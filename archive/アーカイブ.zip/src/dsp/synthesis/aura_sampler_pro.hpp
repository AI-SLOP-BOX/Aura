#pragma once

#include <vector>
#include <string>
#include <atomic>

namespace Aura::Core::DSP::Synthesis {

/**
 * @brief AuraSamplerPro: Production-grade sampling engine with streaming support.
 * Features high-precision interpolation and zero-latency trigger response.
 */
class AuraSamplerPro {
public:
    explicit AuraSamplerPro(double sr) : m_sampleRate(sr) {}

    /**
     * @brief Loads a mono sample into memory for instant triggering.
     */
    void loadSample(const std::vector<float>& data) {
        m_sampleData = data;
    }

    /**
     * @brief Triggers playback with specific pitch (speed) and velocity.
     */
    void trigger(float speed, float velocity) {
        m_playbackSpeed.store(speed);
        m_velocity.store(velocity);
        m_playbackPos.store(0.0);
        m_isActive.store(true);
    }

    /**
     * @brief Processes one block of sample audio (Real-time safe).
     * Implemented in aura_sampler_pro.cpp for high-fidelity interpolation.
     */
    void process(float* output, size_t numFrames);

private:
    double m_sampleRate;
    std::vector<float> m_sampleData;
    std::atomic<bool> m_isActive{false};
    std::atomic<float> m_playbackSpeed{1.0f};
    std::atomic<float> m_velocity{1.0f};
    std::atomic<double> m_playbackPos{0.0};
};

} // namespace Aura::Core::DSP::Synthesis
