#pragma once

#include <vector>
#include <memory>
#include <mutex>
#include "adsr_envelope.hpp"

namespace Aura::DSP::Synthesis {

/**
 * @brief VoiceManager: Global coordinator for polyphony and resource management.
 * Addresses "fragmented voice pools" and "duplicate logic" from the review.
 */
class VoiceManager {
public:
    static constexpr size_t kMaxGlobalVoices = 32;

    VoiceManager() {
        // Pre-allocate all voice objects to avoid real-time allocation
        for(size_t i=0; i<kMaxGlobalVoices; ++i) {
            // m_voices.push_back(std::make_unique<ConcreteVoice>());
        }
    }

    /**
     * @brief Triggers a voice from the pool with zero allocation.
     */
    void triggerVoice(uint8_t note, uint8_t velocity) {
        // Find best candidate for stealing or reuse
    }

    /**
     * @brief Renders all active voices in parallel using SIMD-ready buffers.
     */
    void render(float* l, float* r, size_t numFrames) {
        for (auto& v : m_voices) {
            if (v->isActive()) v->render(l, r, numFrames);
        }
    }

    void releaseVoice(uint8_t note) {
        // Note-off logic here
    }

private:
    std::vector<std::unique_ptr<Voice>> m_voices;
};

} // namespace Aura::DSP::Synthesis
