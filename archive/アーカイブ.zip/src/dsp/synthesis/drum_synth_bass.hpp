#pragma once

#include <cmath>
#include <atomic>
#include <random>

namespace Aura::Core::DSP::Synthesis {

/**
 * @brief DrumSynthBass: Professional SOTA Kick Designer.
 * Refactored with non-linear saturation and transient noise-burst for maximum punch.
 */
class DrumSynthBass {
public:
    explicit DrumSynthBass(double sr) : m_sampleRate(sr), m_noiseGen(std::random_device{}()) {}

    void trigger(float pitchStart = 150.0f, float decay = 0.5f, float saturation = 1.2f) {
        m_phase = 0.0; m_envPos = 0.0;
        m_pitchStart = pitchStart; m_decay = decay;
        m_saturation = saturation;
        m_isActive.store(true);
    }

    void render(float* l, float* r, size_t numFrames) {
        if (!m_isActive.load()) return;

        std::uniform_real_distribution<float> dist(-1.0f, 1.0f);

        for (size_t i = 0; i < numFrames; ++i) {
            // High-end Pitch ADSR: Logarithmic sweep for professional results
            double freqEnv = std::exp(-m_envPos * 15.0);
            double freq = 45.0 + m_pitchStart * freqEnv;
            double amp = std::exp(-m_envPos / (m_decay + 0.01));

            // Synthesis core: Sine + Noise burst (Click)
            float sineSample = std::sin(m_phase * 6.2831853f);
            float clickSample = (m_envPos < 0.01) ? dist(m_noiseGen) * 0.5f : 0.0f;
            float raw = (sineSample + clickSample) * static_cast<float>(amp);

            // LOGIC PRO SECRET: Non-linear Saturation (Tanh) for warm harmonics
            float saturated = std::tanh(raw * m_saturation);

            l[i] += saturated;
            r[i] += saturated;

            m_phase += freq / m_sampleRate;
            m_envPos += 1.0 / m_sampleRate;
            if (amp < 0.0001) m_isActive.store(false);
        }
    }

private:
    double m_sampleRate;
    double m_phase = 0.0;
    double m_envPos = 0.0;
    float m_pitchStart = 150.0f;
    float m_decay = 0.5f;
    float m_saturation = 1.2f;
    std::atomic<bool> m_isActive{false};
    std::mt19937 m_noiseGen;
};

} // namespace Aura::Core::DSP::Synthesis
