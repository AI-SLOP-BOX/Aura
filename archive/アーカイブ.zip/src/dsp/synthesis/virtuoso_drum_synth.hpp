#include <cmath>
#include <algorithm>
#include <array>
#include "../../core/audio_buffer.hpp"
#include "../../core/midi_buffer.hpp"
#include "../iprocessor.hpp"
#include "../utils/dsp_utils.hpp"

namespace Aura::DSP::Synthesis {

/**
 * @class VirtuosoDrumSynth
 * @brief Professional High-Fidelity Drum Synthesis Engine.
 */
class VirtuosoDrumSynth : public IProcessor {
public:
    VirtuosoDrumSynth(double sr = 44100.0) : m_sampleRate(sr) {
        reset();
    }

    void prepareToPlay(double sr, uint32_t bs) noexcept override { m_sampleRate = sr; }

    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        // --- 1. MIDI Parse ---
        for (const auto& event : midi) {
            if ((event.data[0] & 0xF0) == 0x90 && event.data[2] > 0) {
                triggerDrum(event.data[1], event.data[2] / 127.0f);
            }
        }

        // --- 2. Synthesis ---
        float* l = buffer.getWritePointer(0);
        float* r = buffer.getWritePointer(1);
        uint32_t numSamples = buffer.getNumSamples();

        for (uint32_t s = 0; s < numSamples; ++s) {
            float out = 0.0f;
            
            // KICK: Sine Sweep + Pitch Envelope + Saturation
            if (m_kickEnv > 0.001f) {
                float freq = 40.0f + 160.0f * std::pow(m_kickEnv, 2.0f);
                m_kickPhase += Utils::DSPUtils::TWO_PI * freq / m_sampleRate;
                out += std::tanh(std::sin(m_kickPhase) * 1.2f) * m_kickEnv;
                m_kickEnv *= 0.9994f;
            }
            
            // SNARE: XORShift Noise + Fundamental
            if (m_snareEnv > 0.001f) {
                float noise = (fastRand() / (float)0xFFFFFFFF) * 2.0f - 1.0f;
                m_snarePhase += Utils::DSPUtils::TWO_PI * 180.0f / m_sampleRate;
                out += (noise * 0.6f + std::sin(m_snarePhase) * 0.4f) * m_snareEnv;
                m_snareEnv *= 0.9992f;
            }

            // HI-HAT: 808-style Oscillator Cluster (6 square waves)
            if (m_hatEnv > 0.001f) {
                static const float hatFreqs[] = { 245.0f, 306.0f, 368.0f, 417.0f, 523.0f, 659.0f };
                float cluster = 0;
                for (int i = 0; i < 6; ++i) {
                    m_hatPhases[i] += Utils::DSPUtils::TWO_PI * hatFreqs[i] / m_sampleRate;
                    cluster += (std::sin(m_hatPhases[i]) > 0.0f) ? 1.0f : -1.0f;
                }
                // High pass filter emulation
                m_hatZ1 = (cluster * 0.16f) - m_hatZ1 * 0.85f; 
                out += m_hatZ1 * m_hatEnv;
                m_hatEnv *= 0.9982f;
            }

            l[s] += out;
            r[s] += out;
        }
    }

    void reset() noexcept override {
        m_kickEnv = m_snareEnv = m_hatEnv = 0.0f;
        m_kickPhase = m_snarePhase = 0.0f;
        m_hatPhases.fill(0.0f);
    }

private:
    uint32_t fastRand() {
        m_randState ^= m_randState << 13;
        m_randState ^= m_randState >> 17;
        m_randState ^= m_randState << 5;
        return m_randState;
    }

    void triggerDrum(uint8_t note, float velocity) {
        if (note == 36) { // Kick
            m_kickEnv = velocity;
            m_kickPhase = 0.0f;
        } else if (note == 38 || note == 40) { // Snare
            m_snareEnv = velocity;
            m_snarePhase = 0.0f;
        } else if (note == 42 || note == 44) { // Hats
            m_hatEnv = velocity * 0.4f;
        }
    }

    double m_sampleRate;
    uint32_t m_randState = 0xACE1;
    float m_kickEnv = 0.0f, m_kickPhase = 0.0f;
    float m_snareEnv = 0.0f, m_snarePhase = 0.0f;
    float m_hatEnv = 0.0f, m_hatZ1 = 0.0f;
    std::array<float, 6> m_hatPhases;
};

} // namespace Aura::DSP::Synthesis
