#pragma once
#include <cmath>
#include <random>
#include <array>

namespace Aura::DSP::Utils {

/**
 * @class TPDFDither
 * @brief High-precision Triangular Probability Density Function Dither.
 * Standard for 24-bit/32-bit internal DAW processing.
 */
class TPDFDither {
public:
    TPDFDither() : m_dist(-1.0f, 1.0f) {
        std::random_device rd;
        m_rng.seed(rd());
    }

    /**
     * @brief Generate 1 LSB of TPDF noise at 24-bit level.
     */
    inline float process() {
        return (m_dist(m_rng) + m_dist(m_rng)) * (1.0f / 8388608.0f);
    }

private:
    std::mt19937 m_rng;
    std::uniform_real_distribution<float> m_dist;
};

/**
 * @class NoiseShapingDither
 * @brief Mastering-Grade Psychoacoustic Noise-Shaping Dither.
 */
class NoiseShapingDither {
public:
    NoiseShapingDither() : m_dist(-1.0f, 1.0f) {
        std::random_device rd;
        m_rng.seed(rd());
        m_errorHistory.fill(0.0f);
    }

    inline float process(double sample, int bits = 24) {
        float bitStep = 1.0f / (1LL << (bits - 1));
        float noise = (m_dist(m_rng) + m_dist(m_rng)) * bitStep;
        
        float filteredError = m_errorHistory[0] * 2.033f 
                            - m_errorHistory[1] * 2.165f 
                            + m_errorHistory[2] * 1.259f 
                            - m_errorHistory[3] * 0.304f;
                            
        float input = static_cast<float>(sample) + filteredError;
        float quantized = std::round(input / bitStep) * bitStep;
        
        m_errorHistory[3] = m_errorHistory[2];
        m_errorHistory[2] = m_errorHistory[1];
        m_errorHistory[1] = m_errorHistory[0];
        m_errorHistory[0] = input - quantized;

        return quantized + noise;
    }

private:
    std::mt19937 m_rng;
    std::uniform_real_distribution<float> m_dist;
    std::array<float, 4> m_errorHistory;
};

} // namespace Aura::DSP::Utils
