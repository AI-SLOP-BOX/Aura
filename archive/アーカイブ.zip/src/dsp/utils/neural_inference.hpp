/*
 * Aura DAW Ultimate - High-Performance Digital Audio Workstation
 * Copyright (c) 2024-2026 Aura DAW Project. All rights reserved.
 * Licensed under the MIT License.
 */

#pragma once

#include <vector>
#include <array>
#include <cmath>
#include <algorithm>

namespace Aura::DSP::Utils {

/**
 * @class NeuralInference
 * @brief High-performance Multi-Layer Perceptron (MLP) Inference Engine.
 * Optimized for real-time audio processing (No allocations, SIMD-friendly).
 * Used for modeling non-linear analog behaviors (Neural DSP style).
 */
template<size_t InputSize, size_t HiddenSize, size_t OutputSize>
class NeuralInference {
public:
    NeuralInference() { reset(); }

    void reset() {
        m_hiddenState.fill(0.0f);
    }

    /**
     * @brief FORWARD PASS: Predicts the next state or output.
     * Activation: Tanh (Analog-like sigmoid).
     */
    void process(const float* input, float* output, 
                 const std::array<float, HiddenSize * InputSize>& weightsIH,
                 const std::array<float, HiddenSize>& biasH,
                 const std::array<float, OutputSize * HiddenSize>& weightsHO,
                 const std::array<float, OutputSize>& biasO) {
        
        // 1. Input to Hidden
        for (size_t h = 0; h < HiddenSize; ++h) {
            float sum = biasH[h];
            for (size_t i = 0; i < InputSize; ++i) {
                sum += input[i] * weightsIH[h * InputSize + i];
            }
            m_hiddenState[h] = std::tanh(sum);
        }

        // 2. Hidden to Output
        for (size_t o = 0; o < OutputSize; ++o) {
            float sum = biasO[o];
            for (size_t h = 0; h < HiddenSize; ++h) {
                sum += m_hiddenState[h] * weightsHO[o * HiddenSize + h];
            }
            output[o] = sum; // Linear output or Tanh depending on use
        }
    }

private:
    std::array<float, HiddenSize> m_hiddenState;
};

} // namespace Aura::DSP::Utils
