#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>

namespace Aura::DSP::Utils {

/**
 * @brief DSP Utils: High-performance bitwise and mathematical helpers.
 * Addresses the "fragmented constants" and "duplicate logic" from the review.
 */
class DSPUtils {
public:
    static constexpr size_t kMaxBufferSize = 1024;
    static constexpr uint32_t kIndexMask = kMaxBufferSize - 1;

    /**
     * @brief Constants
     */
    static constexpr float PI = 3.14159265358979323846f;
    static constexpr float TWO_PI = 6.28318530717958647692f;
    static constexpr float HALF_PI = 1.57079632679489661923f;

    /**
     * @brief High-speed hard clipper.
     */
    static inline float hardClip(float in) {
        return std::clamp(in, -1.0f, 1.0f);
    }

    /**
     * @brief Sample-rate independent decay coefficient calculation.
     */
    static inline float calculateDecayCoeff(float releaseMs, double sampleRate) {
        return std::exp(-1.0f / (releaseMs * 0.001f * static_cast<float>(sampleRate)));
    }

    /**
     * @brief DB to linear gain conversion.
     */
    static inline float dbToLinear(float db) {
        return std::pow(10.0f, db / 20.0f);
    }
};

} // namespace Aura::DSP::Utils
