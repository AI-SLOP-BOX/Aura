/*
 * Aura DAW Ultimate - High-Performance Digital Audio Workstation
 * Copyright (c) 2024-2026 Aura DAW Project. All rights reserved.
 * Licensed under the MIT License.
 */

#pragma once

#include <cmath>
#include <algorithm>
#include "dsp_utils.hpp"

namespace Aura::DSP::Utils {

/**
 * @class ZDFFilter
 * @brief Zero-Delay Feedback State Variable Filter (SVF).
 * Optimized for high-resonance stability and modulation.
 */
class ZDFFilter {
public:
    enum class Type { LowPass, HighPass, BandPass, Notch };

    ZDFFilter() : m_type(Type::LowPass), m_sampleRate(44100.0) {
        reset();
    }

    void setSampleRate(double sr) noexcept {
        m_sampleRate = sr;
        updateCoefficients(m_lastFc, m_lastQ);
    }

    void setType(Type t) noexcept { m_type = t; }

    void updateCoefficients(float fc, float q) noexcept {
        m_lastFc = std::clamp(fc, 10.0f, 20000.0f);
        m_lastQ = std::clamp(q, 0.5f, 25.0f);

        float g = std::tan(Utils::DSPUtils::PI * m_lastFc / m_sampleRate);
        m_res = 1.0f / m_lastQ;
        m_g = g;
        m_h = 1.0f / (1.0f + m_res * g + g * g);
    }

    float process(float in) noexcept {
        float hp = (in - m_res * m_s1 - m_g * m_s1 - m_s2) * m_h;
        float bp = m_g * hp + m_s1;
        float lp = m_g * bp + m_s2;

        m_s1 = m_g * hp + bp;
        m_s2 = m_g * bp + lp;

        switch (m_type) {
            case Type::LowPass:  return lp;
            case Type::HighPass: return hp;
            case Type::BandPass: return bp;
            case Type::Notch:    return hp + lp;
            default: return lp;
        }
    }

    void reset() noexcept {
        m_s1 = m_s2 = 0.0f;
    }

private:
    Type m_type;
    double m_sampleRate;
    float m_g, m_h, m_res;
    float m_s1 = 0, m_s2 = 0;
    float m_lastFc = 1000.0f, m_lastQ = 0.707f;
};

} // namespace Aura::DSP::Utils
