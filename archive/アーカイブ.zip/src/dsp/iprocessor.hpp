/*
 * Aura DAW Ultimate - High-Performance Digital Audio Workstation
 * Copyright (c) 2024-2026 Aura DAW Project. All rights reserved.
 * Licensed under the MIT License.
 */

#pragma once
#include <cstdint>
#include <algorithm>
#include "../core/audio_buffer.hpp"
#include "../core/midi_buffer.hpp"

namespace Aura::DSP {

/**
 * @struct ProcessContext
 */
struct ProcessContext {
    uint64_t playhead;
    double sampleRate;
    double bpm;
    uint32_t blockSize;
    bool isPlaying;
};

/**
 * @interface IProcessor
 * @brief THE REAL-TIME CONTRACT: No exceptions, no allocations.
 */
class IProcessor {
public:
    virtual ~IProcessor() = default;

    virtual void prepareToPlay(double sr, uint32_t bs) noexcept = 0;
    virtual void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept = 0;
    virtual void reset() noexcept = 0;
    
    virtual uint32_t getLatencySamples() const noexcept { return 0; }
    
    // Parameter Interface
    virtual void setParameter(uint32_t id, float value) noexcept {}
    virtual float getParameter(uint32_t id) const noexcept { return 0.0f; }
    virtual uint32_t getNumParameters() const noexcept { return 0; }
    virtual void getParameterName(uint32_t id, char* outName, uint32_t maxSize) const noexcept {
        if (outName && maxSize > 0) outName[0] = '\0';
    }

    // Mix and Bypass
    void setMix(float mix) noexcept { m_mix = std::clamp(mix, 0.0f, 1.0f); }
    float getMix() const noexcept { return m_mix; }
    void setBypassed(bool b) noexcept { m_bypassed = b; }
    bool isBypassed() const noexcept { return m_bypassed; }

    // Sidechain
    void setSidechainBus(uint32_t busId) noexcept { m_sidechainBusId = busId; }
    uint32_t getSidechainBus() const noexcept { return m_sidechainBusId; }

protected:
    bool m_bypassed = false;
    float m_mix = 1.0f;
    uint32_t m_sidechainBusId = 0;
};

} // namespace Aura::DSP
