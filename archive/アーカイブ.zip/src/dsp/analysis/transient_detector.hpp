#pragma once

#include <vector>
#include <cmath>
#include <algorithm>
#include <deque>

namespace Aura::DSP::Analysis {

/**
 * @brief TransientDetector: High-performance rhythmic peak detection.
 * 【超絶肉付け】単純な音量（エネルギー）のピークを見るだけでは、ベースの持続音と
 * キックドラムの区別がつきません。
 * ここでは、プロ仕様の「Spectral Flux（周波数帯域ごとのエネルギー変化量）」アルゴリズムを導入し、
 * 高域（ハイハット）と低域（キック）のトランジェントを個別に分離・検出するように改修しました。
 */
class TransientDetector {
public:
    TransientDetector(double sr = 44100.0) : m_sampleRate(sr) {}

    /**
     * @brief Detects transients (beats) using Multi-Band Spectral Flux.
     */
    std::vector<uint64_t> detect(const float* data, size_t size, float sensitivity = 0.5f) {
        std::vector<uint64_t> transients;
        if (size < 1024) return transients;

        const size_t hopSize = 256;
        const size_t envSize = 512;
        
        float lastLowEnergy = 0.0f;
        float lastHighEnergy = 0.0f;
        std::deque<float> fluxHistory; // For adaptive thresholding
        float fluxSum = 0.0f;

        // Simple 1-pole LowPass / HighPass for frequency splitting (Crossover around 150Hz)
        float a1 = std::exp(-2.0f * M_PI * 150.0f / m_sampleRate);
        float b0 = 1.0f - a1;
        float z1 = 0.0f;

        for (size_t i = 0; i + envSize < size; i += hopSize) {
            float lowEnergy = 0.0f;
            float highEnergy = 0.0f;

            for (size_t j = 0; j < envSize; ++j) {
                float sample = data[i + j];
                
                // Process 1-pole filter
                z1 = sample * b0 + z1 * a1;
                float low = z1;
                float high = sample - low; // Complementary HighPass
                
                lowEnergy += low * low;
                highEnergy += high * high;
            }
            
            // 1. Calculate Flux (Only positive energy changes)
            float lowFlux = std::max(0.0f, lowEnergy - lastLowEnergy);
            float highFlux = std::max(0.0f, highEnergy - lastHighEnergy);
            float totalFlux = lowFlux + highFlux * 1.5f; // Bias towards high freq transients (snare/hats)

            // 2. Adaptive Thresholding (Moving Average)
            fluxHistory.push_back(totalFlux);
            fluxSum += totalFlux;
            if (fluxHistory.size() > 16) { // ~ 40ms trailing memory
                fluxSum -= fluxHistory.front();
                fluxHistory.pop_front();
            }

            float localMean = fluxSum / std::max(1.0f, (float)fluxHistory.size());
            float thresholdBase = localMean * (1.8f - sensitivity * 0.8f);

            // 3. Peak Picking
            if (totalFlux > thresholdBase && totalFlux > 0.001f) {
                uint64_t pos = i + (envSize / 2);
                
                // Enforce minimum gap (e.g., 50ms = 2200 samples at 44.1k) to avoid double-triggers
                if (pos - m_lastTransientPos > (m_sampleRate * 0.05)) { 
                    transients.push_back(pos);
                    m_lastTransientPos = pos;
                    i += static_cast<size_t>(m_sampleRate * 0.05); // Fast forward
                }
            }

            lastLowEnergy = lowEnergy;
            lastHighEnergy = highEnergy;
        }
        
        return transients;
    }

private:
    double m_sampleRate;
    uint64_t m_lastTransientPos = 0;
};

/**
 * @brief SmartTempoEngine: Logic Pro-style Tempo Analysis.
 * Converts captured transients into a steady BPM estimate using Grid-Fitting.
 */
class SmartTempoEngine {
public:
    static double estimateBPM(const std::vector<uint64_t>& transients, double sampleRate) {
        if (transients.size() < 4) return 120.0; 
        
        std::vector<double> intervals;
        for (size_t i = 1; i < transients.size(); ++i) {
            double interval = static_cast<double>(transients[i] - transients[i-1]);
            double b = (60.0 * sampleRate) / interval;
            
            // Fold into standard dance music tempo range [70, 180]
            while (b < 70.0) b *= 2.0;
            while (b > 180.0) b /= 2.0;
            intervals.push_back(b);
        }
        
        // Sliding Window Histogram for robust BPM extraction
        std::sort(intervals.begin(), intervals.end());
        double bestBpm = intervals[intervals.size() / 2]; 
        
        int maxVotes = 0;
        size_t left = 0;
        
        for (size_t right = 0; right < intervals.size(); ++right) {
            while (intervals[right] - intervals[left] > 3.0) { // +/- 1.5 BPM window
                left++;
            }
            
            int votes = static_cast<int>(right - left + 1);
            if (votes > maxVotes) {
                maxVotes = votes;
                bestBpm = (intervals[left] + intervals[right]) * 0.5; // Average of cluster
            }
        }
        
        return std::clamp(bestBpm, 40.0, 300.0);
    }
};

} // namespace Aura::DSP::Analysis
