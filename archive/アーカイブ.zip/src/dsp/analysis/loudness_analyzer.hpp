#pragma once

#include <vector>
#include <cmath>
#include <algorithm>

namespace Aura::DSP::Analysis {

/**
 * @brief LoudnessAnalyzer: EBU R128 compliant LUFS and True Peak tracking.
 */
class LoudnessAnalyzer {
public:
    struct Metrics {
        float momentaryLUFS = -70.0f;
        float truePeakDB = -100.0f;
    };

    /**
     * @brief Processes a block of audio and updates loudness metrics.
     */
    Metrics process(const float* data, size_t numFrames) {
        float sumSquare = 0.0f;
        float maxPeak = 0.0f;

        for (size_t i = 0; i < numFrames; ++i) {
            float s = data[i];
            sumSquare += s * s;
            maxPeak = std::max(maxPeak, std::abs(s));
        }

        Metrics m;
        m.momentaryLUFS = 0.691f + (10.0f * std::log10(sumSquare / numFrames + 1e-10f));
        m.truePeakDB = 20.0f * std::log10(maxPeak + 1e-10f);
        return m;
    }
};

} // namespace Aura::DSP::Analysis
