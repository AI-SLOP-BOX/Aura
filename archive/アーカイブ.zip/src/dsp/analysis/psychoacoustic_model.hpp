#pragma once

#include <vector>
#include <cmath>
#include <algorithm>

namespace Aura::DSP::Analysis {

/**
 * @brief PsychoacousticModel: Simulated human hearing for DSP resource skipping.
 * Addresses the "weak intelligence" in SCAE by implementing frequency masking.
 */
class PsychoacousticModel {
public:
    struct FrameAnalysis {
        float maskingThreshold = -60.0f; // dB at current band
        float perceptualImportance = 1.0f; // 0.0 (masked) to 1.0 (audible)
    };

    /**
     * @brief Calculates masking effect based on spectral density.
     */
    float calculateMasking(float f, float spl) {
        // Simplified masking curve based on frequency f and sound pressure spl
        float threshold = 3.64f * std::pow(f/1000.0f, -0.8f) - 6.5f * std::exp(-0.6f * std::pow(f/3000.0f - 1, 2));
        return std::max(threshold, spl - 20.0f); // 20dB masking delta
    }

    /**
     * @brief Determines if a track node is "invisible" to the human ear.
     */
    bool isMasked(float signalDB, float backgroundDB) {
        return signalDB < (backgroundDB - 15.0f); // Auditory masking heuristic
    }
};

} // namespace Aura::DSP::Analysis
