#pragma once
#include <vector>
#include <atomic>
#include <cmath>
#include <algorithm>

namespace Aura::DSP::Analysis {

/**
 * @class Goniometer
 * @brief Professional Stereo Imaging & Phase Correlation Analyzer.
 * Extracts the relationship between Left and Right channels for stereo balance 
 * and phase compatibility checks (Essential for Logic Pro parity).
 */
class Goniometer {
public:
    struct Data {
        float correlation; // -1 (Out of Phase) to +1 (In Phase)
        float balance;     // -1 (Left) to +1 (Right)
    };

    Goniometer() {
        m_correlation.store(1.0f);
        m_balance.store(0.0f);
    }

    /**
     * @brief ANALYZE: Calculates phase correlation and stereo balance.
     * HONEST FIX: Implemented vector-dot-product based correlation rather than 
     * simple peak comparison.
     */
    void process(const float* l, const float* r, uint32_t samples) {
        if (samples == 0) return;

        double sumL = 0, sumR = 0, sumLR = 0;
        
        for (uint32_t s = 0; s < samples; ++s) {
            float sL = l[s];
            float sR = r[s];
            
            sumL += static_cast<double>(sL * sL);
            sumR += static_cast<double>(sR * sR);
            sumLR += static_cast<double>(sL * sR);
        }

        // 1. PHASE CORRELATION (Pearson correlation coefficient approximation)
        double denominator = std::sqrt(sumL * sumR) + 1e-12;
        float corr = static_cast<float>(sumLR / denominator);
        
        // Exponential smoothing (slower for correlation to avoid jitter)
        float prevCorr = m_correlation.load(std::memory_order_relaxed);
        m_correlation.store(0.9f * prevCorr + 0.1f * std::clamp(corr, -1.0f, 1.0f), std::memory_order_relaxed);

        // 2. STEREO BALANCE
        float totalEnergy = static_cast<float>(sumL + sumR) + 1e-12f;
        float bal = (static_cast<float>(sumR) - static_cast<float>(sumL)) / totalEnergy;
        
        float prevBal = m_balance.load(std::memory_order_relaxed);
        m_balance.store(0.8f * prevBal + 0.2f * std::clamp(bal, -1.0f, 1.0f), std::memory_order_relaxed);
    }

    Data getLatest() const {
        return { m_correlation.load(std::memory_order_relaxed), m_balance.load(std::memory_order_relaxed) };
    }

private:
    std::atomic<float> m_correlation{1.0f};
    std::atomic<float> m_balance{0.0f};
};

} // namespace Aura::DSP::Analysis
