#pragma once

#include <vector>
#include <cmath>
#include <algorithm>

namespace Aura::Core::DSP::Analysis {

/**
 * @brief DrumIsolator: Specialized Transient Separator for rhythmic extraction.
 * Uses a double-envelope tracking system to isolate drum hits from melodic material.
 */
class DrumIsolator {
public:
    explicit DrumIsolator(double sr) : m_sampleRate(sr) {}

    /**
     * @brief Processes one block of audio and separates drum (transient) content.
     */
    void process(const float* input, float* drumOutput, float* melodicOutput, size_t numFrames) {
        for (size_t i = 0; i < numFrames; ++i) {
            float env = std::abs(input[i]);
            
            // PROFESSIONAL LOGIC: Fast-attack, Slow-decay envelope follower
            float attack = 1.0f - std::exp(-1.0f / (m_sampleRate * 0.001f)); // 1ms attack
            float release = 1.0f - std::exp(-1.0f / (m_sampleRate * 0.1f));   // 100ms release
            
            if (env > m_envelope) m_envelope += attack * (env - m_envelope);
            else m_envelope += release * (env - m_envelope);

            // Ratio-based masking for transient extraction
            float mask = std::clamp((env / (m_envelope + 1e-6f)) * 0.5f, 0.0f, 1.0f);
            
            drumOutput[i] = input[i] * mask;
            melodicOutput[i] = input[i] * (1.0f - mask);
        }
    }

private:
    double m_sampleRate;
    float m_envelope = 0.0f;
};

} // namespace Aura::Core::DSP::Analysis
