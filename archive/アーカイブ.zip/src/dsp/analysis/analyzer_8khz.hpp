#pragma once

#include <atomic>
#include <vector>

namespace Aura::Core::DSP::Analysis {

/**
 * @brief Analyzer8kHz: Spectral analysis eye for the 8kHz high-frequency band.
 * Feeds the Intelligence system to allow psychoacoustic optimization decisions.
 */
class Analyzer8kHz {
public:
    Analyzer8kHz() : m_highFreqEnergy(0.0f) {}

    /**
     * @brief Performs FFT or Filtered energy detection on a temporal block.
     */
    void analyze(const float* buffer, size_t numFrames);

    /**
     * @brief Returns the average energy detected in the high-frequency range.
     */
    float getEnergy() const;

private:
    std::atomic<float> m_highFreqEnergy;
};

} // namespace Aura::Core::DSP::Analysis
