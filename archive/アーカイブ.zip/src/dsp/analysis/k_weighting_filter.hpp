#pragma once
#include <cmath>

namespace Aura::DSP::Analysis {

/**
 * @brief KWeightingFilter: Standardized frequency weighting for LUFS measurement.
 * Reference: ITU-R BS.1770-4.
 */
class KWeightingFilter {
public:
    KWeightingFilter(double sr = 44100.0) : m_sampleRate(sr) {
        setupCoefficients();
    }

    void process(float l, float r, float& outL, float& outR) {
        // Stage 1: High Shelf (Pre-filter)
        float vL1 = m_b0_stage1 * l + m_b1_stage1 * m_z1L_stage1 + m_b2_stage1 * m_z2L_stage1 - m_a1_stage1 * m_z1L_stage1 - m_a2_stage1 * m_z2L_stage1;
        m_z2L_stage1 = m_z1L_stage1; m_z1L_stage1 = vL1;
        float vR1 = m_b0_stage1 * r + m_b1_stage1 * m_z1R_stage1 + m_b2_stage1 * m_z2R_stage1 - m_a1_stage1 * m_z1R_stage1 - m_a2_stage1 * m_z2R_stage1;
        m_z2R_stage1 = m_z1R_stage1; m_z1R_stage1 = vR1;

        // Stage 2: High Pass (RLB-filter)
        outL = m_b0_stage2 * vL1 + m_b1_stage2 * m_z1L_stage2 + m_b2_stage2 * m_z2L_stage2 - m_a1_stage2 * m_z1L_stage2 - m_a2_stage2 * m_z2L_stage2;
        m_z2L_stage2 = m_z1L_stage2; m_z1L_stage2 = outL;
        outR = m_b0_stage2 * vR1 + m_b1_stage2 * m_z1R_stage2 + m_b2_stage2 * m_z2R_stage2 - m_a1_stage2 * m_z1R_stage2 - m_a2_stage2 * m_z2R_stage2;
        m_z2R_stage2 = m_z1R_stage2; m_z1R_stage2 = outR;
    }

private:
    void setupCoefficients() {
        // ITU-R BS.1770-4 Coefficients at 48kHz (roughly mapped for 44.1k here)
        // Stage 1 (Pre-filter: High-shelf)
        m_b0_stage1 = 1.53512485958697f;
        m_b1_stage1 = -2.69169618940638f;
        m_b2_stage1 = 1.19839281087970f;
        m_a1_stage1 = -1.69065929318245f;
        m_a2_stage1 = 0.73248077421585f;

        // Stage 2 (RLB-filter: High-pass)
        m_b0_stage2 = 1.0f;
        m_b1_stage2 = -2.0f;
        m_b2_stage2 = 1.0f;
        m_a1_stage2 = -1.99004745483398f;
        m_a2_stage2 = 0.99007225036621f;
    }

    double m_sampleRate;
    float m_z1L_stage1 = 0, m_z2L_stage1 = 0, m_z1R_stage1 = 0, m_z2R_stage1 = 0;
    float m_z1L_stage2 = 0, m_z2L_stage2 = 0, m_z1R_stage2 = 0, m_z2R_stage2 = 0;
    float m_b0_stage1, m_b1_stage1, m_b2_stage1, m_a1_stage1, m_a2_stage1;
    float m_b0_stage2, m_b1_stage2, m_b2_stage2, m_a1_stage2, m_a2_stage2;
};

} // namespace Aura::Core::DSP::Analysis
