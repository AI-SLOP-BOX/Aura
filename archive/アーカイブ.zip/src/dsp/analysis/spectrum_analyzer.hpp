#pragma once
#include <vector>
#include <cmath>
#include <atomic>
#include <array>
#include "../mixing/state_variable_filter.hpp"

namespace Aura::DSP::Analysis {

/**
 * @class SpectrumAnalyzer
 * @brief 【大罪修正】ロックフリー・並列動作対応 32バンド周波数アナライザー
 * 以前のコードは「Singleton」かつ内部で `std::mutex` をロックしていました。
 * これでは、複数のトラックにアナライザーを指した瞬間、オーディオスレッド同士が
 * 1つの鍵（Mutex）を奪い合って待機状態になり、CPU負荷が爆発して音が止まる「デッドロック寸前」の状態でした。
 *
 * 【修正版】はシングルトンを廃止し、個別のインスタンスとして動作。
 * ロックを完全に排除し、`std::atomic` による非ブロッキングなデータ更新を実現しました。
 */
class SpectrumAnalyzer {
public:
    static constexpr uint8_t kNumBands = 32;

    SpectrumAnalyzer(double sr = 44100.0) {
        initializeFilters(sr);
        for (auto& b : m_currentBands) b.store(0.0f, std::memory_order_relaxed);
    }

    /**
     * @brief リアルタイム解析：ロックフリーで実行
     */
    void process(const float* data, size_t size, double sr) {
        if (m_sampleRate != sr) initializeFilters(sr);

        std::array<float, kNumBands> bandEnergy;
        bandEnergy.fill(0.0f);
        float totalSumSq = 0.0f;

        for (size_t i = 0; i < size; ++i) {
            float sample = data[i];
            totalSumSq += sample * sample;

            for (int b = 0; b < kNumBands; ++b) {
                // Band-Pass filtered energy
                float bandSample = m_filters[b].processSampleBP(sample);
                bandEnergy[b] += std::abs(bandSample);
            }
        }

        // 1. UPDATE BROADBAND ENERGY (Atomic)
        float rms = std::sqrt(totalSumSq / (size + 1e-10f));
        m_energy.store(0.8f * m_energy.load(std::memory_order_relaxed) + 0.2f * rms, std::memory_order_relaxed);
        
        float currentPeak = m_peakEnergy.load(std::memory_order_relaxed);
        if (rms > currentPeak) m_peakEnergy.store(rms, std::memory_order_relaxed);

        // 2. UPDATE BAND DATA (Atomic floats for UI)
        float invSize = 1.0f / static_cast<float>(size);
        for (int b = 0; b < kNumBands; ++b) {
            float normEnergy = bandEnergy[b] * invSize;
            float prev = m_currentBands[b].load(std::memory_order_relaxed);
            // なだらかな減衰（Smoothing）
            m_currentBands[b].store(0.95f * prev + 0.05f * normEnergy, std::memory_order_relaxed);
        }
    }

    float getEnergy() const { return m_energy.load(std::memory_order_relaxed); }
    float getPeak() const { return m_peakEnergy.load(std::memory_order_relaxed); }
    
    std::vector<float> getCurrentBands() const {
        std::vector<float> out(kNumBands);
        for (int b = 0; b < kNumBands; ++b) {
            out[b] = m_currentBands[b].load(std::memory_order_relaxed);
        }
        return out;
    }

private:
    void initializeFilters(double sr) {
        m_sampleRate = sr;
        m_filters.clear();
        m_filters.reserve(kNumBands);
        for (int i = 0; i < kNumBands; ++i) {
            // Logarithmic frequency distribution (20Hz to 20kHz)
            float freq = 20.0f * std::pow(1000.0f, static_cast<float>(i) / (kNumBands - 1));
            Mixing::StateVariableFilter filter(sr);
            filter.setParameters(freq, 1.414f, 0); 
            m_filters.push_back(std::move(filter));
        }
    }

    double m_sampleRate = 0;
    std::atomic<float> m_energy{0.0f};
    std::atomic<float> m_peakEnergy{0.0f};
    std::array<std::atomic<float>, kNumBands> m_currentBands;
    std::vector<Mixing::StateVariableFilter> m_filters;
};

} // namespace Aura::DSP::Analysis
