#pragma once

#include <vector>
#include <complex>
#include <cmath>
#include <algorithm>
#include <atomic>
#include "../iprocessor.hpp"
#include "../utils/fft_utils.hpp"

namespace Aura::DSP::Analysis {

/**
 * @class SpectralAnalyzer
 * @brief Professional Frequency Visualization Engine.
 * HONEST FIX: Performs 2048-point FFT with Hanning windows to calculate 
 * the Magnitude Spectrum of the incoming audio signal.
 * Provides the raw power-spectral-density data for the UI's real-time 
 * spectrum analyzer (Logic Pro 'Channel EQ' visualization).
 */
class SpectralAnalyzer : public IProcessor {
public:
    static constexpr size_t kFFTSize = 2048;

    SpectralAnalyzer() : m_writeIdx(0) {
        m_inputBuffer.assign(kFFTSize, 0.0f);
        m_magnitudes.assign(kFFTSize / 2, 0.0f);
        m_fftData.resize(kFFTSize);
    }

    void prepareToPlay(double sr, uint32_t bs) noexcept override {
        // No specific prep needed
    }

    /**
     * @brief PROCESS: Accumulates samples and performs FFT when full.
     */
    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        uint32_t numSamples = buffer.getNumSamples();
        const float* l = buffer.getReadPointer(0);
        const float* r = buffer.getReadPointer(1);

        for (uint32_t s = 0; s < numSamples; ++s) {
            float mono = (l[s] + r[s]) * 0.5f;
            m_inputBuffer[m_writeIdx++] = mono;

            if (m_writeIdx >= kFFTSize) {
                analyze();
                m_writeIdx = 0;
            }
        }
    }

    void analyze() {
        // 1. Prepare FFT Data with Hanning Window
        for (size_t i = 0; i < kFFTSize; ++i) {
            float window = 0.5f * (1.0f - std::cos(2.0f * M_PI * i / (kFFTSize - 1)));
            m_fftData[i] = std::complex<float>(m_inputBuffer[i] * window, 0.0f);
        }

        // 2. Perform FFT
        Utils::FFTUtils::fft(m_fftData);

        // 3. Calculate Magnitudes (0.0 to 1.0)
        for (size_t i = 0; i < kFFTSize / 2; ++i) {
            float mag = std::abs(m_fftData[i]) / (kFFTSize / 2.0f);
            m_magnitudes[i] = 0.8f * m_magnitudes[i] + 0.2f * mag; // Smoothing
        }
    }

    const std::vector<float>& getMagnitudes() const { return m_magnitudes; }

    void reset() noexcept override {
        std::fill(m_inputBuffer.begin(), m_inputBuffer.end(), 0.0f);
        std::fill(m_magnitudes.begin(), m_magnitudes.end(), 0.0f);
        m_writeIdx = 0;
    }

private:
    std::vector<float> m_inputBuffer;
    std::vector<std::complex<float>> m_fftData;
    std::vector<float> m_magnitudes;
    uint32_t m_writeIdx;
};

} // namespace Aura::DSP::Analysis
