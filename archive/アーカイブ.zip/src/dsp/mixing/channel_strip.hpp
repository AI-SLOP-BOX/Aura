#pragma once

#include <atomic>
#include <cmath>
#include "panning_law.hpp"
#include "../../core/audio_buffer.hpp"

namespace Aura::DSP::Mixing {

/**
 * @brief ChannelStrip: Standard mixing unit for mono/stereo sources.
 * Addresses the "missing basic mixing controls" from the review.
 */
class ChannelStrip {
public:
    void setGain(float gain) { m_gain.store(gain); }
    void setPan(float pan) { m_pan.store(pan); } // -1.0 (L) to 1.0 (R)
    void setMute(bool mute) { m_mute.store(mute); }
    void setSolo(bool solo) { m_solo.store(solo); }

    /**
     * @brief Processes a stereo block with constant power panning.
     */
    void process(Core::AudioBuffer& buffer) {
        if (m_mute.load()) {
            buffer.clear();
            return;
        }

        float gain = m_gain.load();
        float pan = m_pan.load();
        
        // Panning gains calculated via Constant Power Law
        float gainL, gainR;
        PanningLaw::calculate(pan, gainL, gainR);

        for (uint32_t s = 0; s < buffer.getNumSamples(); ++s) {
            buffer.getWritePointer(0)[s] *= (gain * gainL);
            buffer.getWritePointer(1)[s] *= (gain * gainR);
        }
    }

private:
    std::atomic<float> m_gain{1.0f};
    std::atomic<float> m_pan{0.0f};
    std::atomic<bool> m_mute{false};
    std::atomic<bool> m_solo{false};
};

} // namespace Aura::DSP::Mixing
