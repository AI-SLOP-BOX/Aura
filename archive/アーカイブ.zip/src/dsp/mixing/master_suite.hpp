#pragma once

#include <vector>
#include <memory>
#include <atomic>
#include "dsp/effects/pro_limiter.hpp"
#include "dsp/effects/true_peak_limiter.hpp"
#include "dsp/effects/virtuoso_tape.hpp"
#include "dsp/effects/virtuoso_pultec.hpp"
#include "dsp/analysis/master_meter.hpp"
#include "dsp/utils/dither.hpp"
#include "core/concurrency/simd_kernel.hpp"
#include "core/audio_buffer.hpp"
#include "dsp/iprocessor.hpp"

namespace Aura::DSP::Mixing {

/**
 * @class MasterSuite
 * @brief Professional High-End Mastering Strip.
 * Inherits from IProcessor for unified engine integration.
 */
class MasterSuite : public IProcessor {
public:
    MasterSuite(double sr = 44100.0) : m_sampleRate(sr), m_pultec(sr), m_tapeSaturator(sr) {}

    void prepareToPlay(double sr, uint32_t bs) noexcept override {
        m_sampleRate = sr;
        m_pultec.prepareToPlay(sr, bs);
        m_tapeSaturator.prepareToPlay(sr, bs);
    }

    void process(Core::AudioBuffer& buffer, Core::MidiBuffer& midi, const ProcessContext& context) noexcept override {
        // 1. ANALYSIS
        m_meter.process(buffer.getWritePointer(0), buffer.getWritePointer(1), buffer.getNumSamples());
        
        // 2. TONAL SHAPING
        m_pultec.process(buffer, midi, context);
        m_tapeSaturator.process(buffer, midi, context);

        // 3. MID/SIDE MATRIX
        float* l = buffer.getWritePointer(0);
        float* r = buffer.getWritePointer(1);
        uint32_t numSamples = buffer.getNumSamples();

        if (m_enableMidSide) {
            Core::SIMD::SIMDKernel::processMidSide(l, r, numSamples);
        }
        
        // 4. FINAL LIMITING
        m_limiter.process(l, r, numSamples, 0.0f, -0.1f);
        
        if (m_enableMidSide) {
            Core::SIMD::SIMDKernel::processMidSide(l, r, numSamples);
            if (m_stereoWidth != 1.0f) Core::SIMD::SIMDKernel::applyGain(r, m_stereoWidth, numSamples);
        }

        // 5. DITHER
        for (uint32_t s = 0; s < numSamples; ++s) {
            l[s] += m_ditherL.process();
            r[s] += m_ditherR.process();
        }
    }

    void reset() noexcept override {
        m_pultec.reset();
        m_tapeSaturator.reset();
        m_limiter.reset();
    }

    Analysis::MasterMeter::MeterData getLatestMetrics() const {
        return m_meter.getLatestData();
    }

    void setMidSideMode(bool enable, float width = 1.0f) {
        m_enableMidSide = enable;
        m_stereoWidth = width;
    }

private:
    double m_sampleRate = 44100.0;
    bool m_enableMidSide = false;
    float m_stereoWidth = 1.0f;
    Effects::TruePeakLimiter m_limiter;
    Effects::VirtuosoTapeSaturator m_tapeSaturator;
    Effects::VirtuosoPultec m_pultec;
    Analysis::MasterMeter m_meter;
    Utils::TPDFDither m_ditherL, m_ditherR;
};

} // namespace Aura::DSP::Mixing
