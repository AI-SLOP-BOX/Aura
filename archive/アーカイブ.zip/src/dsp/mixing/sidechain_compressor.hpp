#pragma once

#include <vector>
#include <cmath>
#include <atomic>

namespace Aura::Core::DSP::Mixing {

/**
 * @brief SidechainCompressor: External signal dynamic range processor.
 * Iconic Logic Pro feature for "Pumping" effects and vocal/instrument ducking.
 */
class SidechainCompressor {
public:
    /**
     * @brief Processes the main audio using an external trigger energy.
     */
    void process(float* l, float* r, const float* sidechainInput, size_t numFrames) {
        float threshLinear = std::pow(10.0f, m_threshold.load() / 20.0f);
        float ratio = m_ratio.load();

        for (size_t i = 0; i < numFrames; ++i) {
            // DETECTOR Stage: Analyze external sidechain energy
            float scEnergy = std::abs(sidechainInput[i]);
            
            // GAIN Reducer: Apply compression only when sidechain exceeds threshold
            float attenuation = 1.0f;
            if (scEnergy > threshLinear) {
                attenuation = 1.0f - (1.0f - (1.0f / ratio)) * (scEnergy - threshLinear) / (scEnergy + 1e-10f);
            }

            l[i] *= attenuation;
            r[i] *= attenuation;
        }
    }

private:
    std::atomic<float> m_threshold{-20.0f}, m_ratio{4.0f};
};

} // namespace Aura::Core::DSP::Mixing
