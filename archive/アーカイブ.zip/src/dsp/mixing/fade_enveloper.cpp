#include "fade_enveloper.hpp"
#include <cmath>
#include <algorithm>

namespace Aura::DSP::Mixing {

/**
 * @brief FadeEnveloper: Provides logarithmic crossfades between regions.
 * Addresses the "missing non-destructive fades" from the review.
 */
void FadeEnveloper::apply(float* out, const float* in1, const float* in2, size_t numFrames) {
    for (size_t i = 0; i < numFrames; ++i) {
        float t = static_cast<float>(i) / static_cast<float>(numFrames);
        
        // Equal Power Crossfade formula
        float gain1 = std::cos(t * 1.57079632679f); // sqrt(1.0 - t^2)
        float gain2 = std::sin(t * 1.57079632679f); // t

        out[i] = (in1[i] * gain1) + (in2[i] * gain2);
    }
}

} // namespace Aura::DSP::Mixing
