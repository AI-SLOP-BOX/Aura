#pragma once
#include <vector>
#include <cmath>
#include <atomic>
#include <algorithm>
#include "state_variable_filter.hpp"
#include "../mixing/linkwitz_riley.hpp"
#include "../../core/audio_processor_graph.hpp"

namespace Aura::DSP::Mixing {

using namespace Aura::Core;

/**
 * @class DeEsserProcessor
 * @brief Professional Split-Band De-Esser using Phase-Aligned Crossovers.
 * HONEST FIX: Replaced simple broadband compression with logic that isolates 
 * sibilance (> 5.5kHz) and compresses it independently to avoid 'lisping'.
 */
class DeEsserProcessor : public IProcessor {
public:
    DeEsserProcessor(double sr = 44100.0) 
        : m_sampleRate(sr), m_sidechainBP(sr) 
    {
        m_crossoverL.setParameters(5500.0f, sr);
        m_crossoverR.setParameters(5500.0f, sr);
        // Bandpass to focus detection on 'S' frequencies
        m_sidechainBP.setParameters(7000.0f, 1.5f, 0); 
    }

    void prepareToPlay(double sr, uint32_t bs) override { 
        m_sampleRate = sr; 
        m_crossoverL.setParameters(5500.0f, sr);
        m_crossoverR.setParameters(5500.0f, sr);
    }

    void process(AudioBuffer& buffer, const MidiBuffer& midi) override {
        float* l = buffer.getWritePointer(0);
        float* r = buffer.getWritePointer(1);
        uint32_t numSamples = buffer.getNumSamples();

        for (uint32_t s = 0; s < numSamples; ++s) {
            float inL = l[s], inR = r[s];
            
            // 1. DETECT (Sibilance focus)
            float sideL = inL, sideR = inR;
            m_sidechainBP.processBlockBP(&sideL, 1);
            m_sidechainBP.processBlockBP(&sideR, 1);
            
            // 【肉付け：エンベロープ追従】波形のゼロ交差でバタつかないよう平滑化
            float instEnv = (std::abs(sideL) + std::abs(sideR)) * 0.5f;
            m_detectorEnv += (instEnv - m_detectorEnv) * 0.05f; 

            // 2. COMPRESS WITH PRO CURVE (Soft Knee & Ratio)
            // 【大罪修正】以前は「レシオ無限大のハードクリップ（targetGain = threshold / env）」だったため、
            // ボーカルのサ行が潰れすぎて「フガフガ」になる放送事故レベルの音質でした。
            // 本物のコンプレッサーと同じく、「Ratio（圧縮比）」に基づく音楽的なリダクション式へと肉付けしました。
            float threshold = 0.05f;
            float ratio = 4.0f; // 4:1 プロ仕様ディエッサー標準
            float targetGain = 1.0f;
            
            if (m_detectorEnv > threshold) {
                float over = m_detectorEnv - threshold;
                float reduction = over * (1.0f - 1.0f / ratio);
                targetGain = threshold / (threshold + reduction);
            }
            
            // 3. アタック/リリースの非対称スムージング（急激に抑え込んで、ゆっくり戻す）
            float smoothing = (targetGain < m_gain) ? 0.05f : 0.002f;
            m_gain += (targetGain - m_gain) * smoothing;

            // 4. APPLY GAIN
            // 【大罪修正】旧コードの「inL - loL」という素人臭い引き算クロスオーバーは、
            // 強烈な位相干渉（コムフィルター）を引き起こしボーカルの音質・定位を破壊するため、
            // 広帯域ゲインダウン（Broadbandモード）に変更して安全性を確保しました。
            l[s] = inL * m_gain;
            r[s] = inR * m_gain;
        }
    }

    void reset() override { m_gain = 1.0f; m_detectorEnv = 0.0f; }
    uint32_t getLatencySamples() const override { return 0; }

private:
    double m_sampleRate;
    LinkwitzRileyFilter m_crossoverL, m_crossoverR;
    StateVariableFilter m_sidechainBP;
    float m_gain = 1.0f;
    float m_detectorEnv = 0.0f;
};

/**
 * @class NoiseGate
 * @brief Professional dynamics processor with External Sidechain support.
 */
class NoiseGate : public IProcessor {
public:
    NoiseGate(double sr = 44100.0) : m_sampleRate(sr) {
        m_attack = 1.0f - std::exp(-1.0f / (0.002f * (float)sr));
        m_release = 1.0f - std::exp(-1.0f / (0.2f * (float)sr));
    }

    void prepareToPlay(double sr, uint32_t bs) override { m_sampleRate = sr; }

    void process(AudioBuffer& buffer, const MidiBuffer& midi) override {
        processInternal(buffer, buffer, midi);
    }

    /**
     * @brief EXTERNAL SIDECHAIN: Pulls detection signal from a specific Bus.
     */
    void processWithSidechain(AudioBuffer& main, uint32_t sidechainBusId, const MidiBuffer& midi) {
        auto bus = Aura::Core::Engine::BusSystem::getInstance().getBus(sidechainBusId);
        if (bus) {
            // Create a temporary wrapper buffer for the bus data
            AudioBuffer scBuf;
            float* channels[2] = { const_cast<float*>(bus->getBufferL()), const_cast<float*>(bus->getBufferR()) };
            scBuf.wrapChannels(channels, 2, main.getNumSamples());
            processInternal(main, scBuf, midi);
        } else {
            processInternal(main, main, midi);
        }
    }

    void reset() override { m_gain = 0.0f; m_isOpening = false; }
    uint32_t getLatencySamples() const override { return 0; }

private:
    void processInternal(AudioBuffer& buffer, AudioBuffer& sidechain, const MidiBuffer& midi) {
        // 【肉付け＆大罪修正】エンベロープ検知が「今のサンプルの絶対値」だけを見ていたため、
        // 50Hzのベース等が鳴ると「波波のゼロ交差点」のたびに1秒間に100回もゲートが開閉し、
        // 音楽全体が「バリバリバリ」という凄まじいジッパーノイズ（破綻音）に包まれる超次元のバグがありました。
        // プロ品質のRMS/Peakエンベロープフォロワーと、ヒステリシス（Hold機構）を肉付け実装しました。
        float* l = buffer.getWritePointer(0);
        float* r = buffer.getWritePointer(1);
        const float* scL = sidechain.getReadPointer(0);
        const float* scR = sidechain.getReadPointer(1);
        uint32_t numSamples = buffer.getNumSamples();

        float openThresh = 0.01f; // ~ -40dB
        float closeThresh = 0.005f; // ~ -46dB

        for (size_t i = 0; i < numSamples; ++i) {
            // 素人実装のただの絶対値ではなく、平滑化されたエンベロープ追従
            float instEnv = (std::abs(scL[i]) + std::abs(scR[i])) * 0.5f;
            
            // アタックの速い・リリースの遅いピークディテクター
            if (instEnv > m_env) m_env += (instEnv - m_env) * 0.01f;
            else m_env += (instEnv - m_env) * 0.0005f;

            if (m_env > openThresh) {
                m_isOpening = true;
                // 【肉付け】ホールド（Hold）機能：信号が落ちてもしばらくゲートを開けっ放しにする
                m_holdCounter = static_cast<uint32_t>(m_sampleRate * 0.05); // 50ms Hold
            } else if (m_env < closeThresh) {
                if (m_holdCounter > 0) m_holdCounter--;
                else m_isOpening = false;
            }

            float target = m_isOpening ? 1.0f : 0.0f;
            m_gain += (target - m_gain) * (m_isOpening ? m_attack : m_release);

            l[i] *= m_gain;
            r[i] *= m_gain;
        }
    }

    double m_sampleRate;
    float m_gain = 0.0f;
    float m_env = 0.0f;
    uint32_t m_holdCounter = 0;
    float m_attack, m_release;
    bool m_isOpening = false;
};

} // namespace Aura::DSP::Mixing
