#pragma once

#include <vector>
#include <algorithm>
#include <memory>
#include "iprocessor.hpp"

namespace Aura::DSP {

/**
 * @brief BlockProcessor: Architecture for fixed-size DSP (FFT/STFT).
 * Bridges dynamic driver buffers (e.g. 512) to fixed spectral buffers (e.g. 2048).
 * Essential for Reverb, Pitch Shifting, and Spectral Repair.
 */
class BlockProcessor {
public:
    BlockProcessor(uint32_t processSize, uint32_t hopSize) 
        : m_processSize(processSize), m_hopSize(hopSize) {
        m_inputBuffer.resize(processSize, 0.0f);
        m_outputBuffer.resize(processSize, 0.0f);
        m_writePos = 0;
        m_readPos = 0;
    }

    /**
     * @brief PUMP: Feeds samples into the STFT stream.
     * @param callback: The high-end spectral process to run on a full block.
     */
    void process(float* data, uint32_t numSamples, 
                 std::function<void(const std::vector<float>&, std::vector<float>&)> callback) {
        for (uint32_t i = 0; i < numSamples; ++i) {
            m_inputBuffer[m_writePos++] = data[i];

            if (m_writePos >= m_processSize) {
                // RUN FFT PROCESS ON FULL BLOCK
                std::vector<float> processed(m_processSize, 0.0f);
                callback(m_inputBuffer, processed);
                
                // OVERLAP-ADD INTO OUTPUT BUFFER
                for (uint32_t j = 0; j < m_processSize; ++j) m_outputBuffer[j] += processed[j];
                
                // SHIFT INPUT (Hop Size)
                std::shift_left(m_inputBuffer.begin(), m_inputBuffer.end(), m_hopSize);
                m_writePos -= m_hopSize;
            }

            data[i] = m_outputBuffer[m_readPos++];
            if (m_readPos >= m_hopSize) {
                // SHIFT OUTPUT (Hop Size)
                std::shift_left(m_outputBuffer.begin(), m_outputBuffer.end(), m_hopSize);
                m_readPos -= m_hopSize;
            }
        }
    }

private:
    uint32_t m_processSize, m_hopSize;
    std::vector<float> m_inputBuffer, m_outputBuffer;
    uint32_t m_writePos, m_readPos;
};

} // namespace Aura::DSP
