#pragma once

#include "../AuraUltimate.hpp"

namespace Aura::Ultimate {

/**
 * @deprecated Use Aura::Ultimate::Engine instead.
 * @brief AuraUnifiedEngine (LEGACY): Compatible bridge to the Ultimate Kernel.
 */
class AuraUnifiedEngine {
public:
    static AuraUnifiedEngine& getInstance() {
        static AuraUnifiedEngine instance;
        return instance;
    }

    void initialize(double sr, uint32_t bs) {
        Engine::getInstance().initialize(sr, bs);
    }

    void process(const float** in, float** out, uint32_t n) {
        Engine::getInstance().process(in, out, n);
    }

private:
    AuraUnifiedEngine() = default;
};

} // namespace Aura::Ultimate
