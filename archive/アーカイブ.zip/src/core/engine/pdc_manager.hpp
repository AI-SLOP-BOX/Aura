#pragma once
#include <vector>
#include <algorithm>
#include <array>
#include <atomic>

namespace Aura::Core::Engine {

/**
 * @class PDCManager
 * @brief Professional Plug-in Delay Compensation (PDC) System.
 */
class PDCManager {
public:
    static constexpr size_t kMaxTracks = 512;

    static PDCManager& getInstance() {
        static PDCManager instance;
        return instance;
    }

    /**
     * @brief AUDIO THREAD: Returns the compensation offset (in samples) for a track.
     * HONEST FIX: Made it O(1) and LOCK-FREE using a fixed-size array.
     */
    uint32_t getCompensationOffset(uint32_t trackId) const {
        if (trackId >= kMaxTracks) return 0;
        return m_activeOffsets[trackId];
    }

    /**
     * @brief UI THREAD: Updates the latency of a specific track.
     */
    void setTrackLatency(uint32_t trackId, uint32_t samples) {
        if (trackId < kMaxTracks) {
            m_pendingLatencies[trackId] = samples;
            m_dirty = true;
        }
    }

    /**
     * @brief AUDIO THREAD (Block Boundary): Swaps pending to active.
     */
    void recalculate() {
        if (!m_dirty.load(std::memory_order_relaxed)) return;
        
        uint32_t maxL = 0;
        for (uint32_t l : m_pendingLatencies) {
            maxL = std::max(maxL, l);
        }
        
        m_globalMaxLatency = maxL;
        for (uint32_t i = 0; i < kMaxTracks; ++i) {
            m_activeOffsets[i] = maxL - m_pendingLatencies[i];
        }
        
        m_dirty = false;
    }

    uint32_t getGlobalMaxLatency() const { return m_globalMaxLatency; }
    
    void markDirty() { m_dirty = true; }

private:
    PDCManager() {
        m_pendingLatencies.fill(0);
        m_activeOffsets.fill(0);
    }
    
    std::array<uint32_t, kMaxTracks> m_pendingLatencies;
    std::array<uint32_t, kMaxTracks> m_activeOffsets;
    uint32_t m_globalMaxLatency = 0;
    std::atomic<bool> m_dirty{true};
};

} // namespace Aura::Core::Engine
