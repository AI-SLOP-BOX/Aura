#pragma once

#include <vector>
#include <string>
#include <map>
#include <chrono>
#include <memory>
#include "param_tree.hpp"
#include "track.hpp"

namespace Aura::Core::Engine {

/**
 * @struct Snapshot
 * @brief Represents a full state of the DAW at a point in time.
 * 【超絶肉付け】Logic Proの「Project Alternatives」や「Mix Snapshots」を
 * 超える柔軟性を持つスナップショット。全てのトラックのフェーダー、パン、
 * 全プラグインの全オートメーション・パラメータを一括保存します。
 */
struct Snapshot {
    std::string name;
    std::chrono::system_clock::time_point timestamp;
    
    struct TrackState {
        float volume;
        float pan;
        bool mute;
        bool solo;
        std::map<uint32_t, float> parameters;
    };
    
    std::vector<TrackState> trackStates;
};

/**
 * @class SnapshotManager
 * @brief High-performance State Capture & Recall Engine.
 */
class SnapshotManager {
public:
    static SnapshotManager& getInstance() { static SnapshotManager i; return i; }

    /**
     * @brief CAPTURE: Saves the current state of all tracks.
     */
    void takeSnapshot(const std::string& name, const std::vector<std::shared_ptr<Track>>& tracks) {
        Snapshot s;
        s.name = name;
        s.timestamp = std::chrono::system_clock::now();
        
        for (const auto& track : tracks) {
            Snapshot::TrackState ts;
            ts.volume = track->getVolume();
            ts.pan = track->getPan();
            ts.mute = track->isMuted();
            ts.solo = track->isSolo();
            
            s.trackStates.push_back(std::move(ts));
        }
        m_snapshots.push_back(std::move(s));
    }

    /**
     * @brief RECALL: Restores a saved state instantly (with sample-accurate smoothing).
     */
    void recallSnapshot(size_t index, std::vector<std::shared_ptr<Track>>& tracks) {
        if (index >= m_snapshots.size()) return;
        
        const auto& s = m_snapshots[index];
        for (size_t i = 0; i < std::min(s.trackStates.size(), tracks.size()); ++i) {
            const auto& ts = s.trackStates[i];
            auto& track = tracks[i];
            
            track->setVolume(ts.volume);
            track->setPan(ts.pan);
            track->setMuted(ts.mute);
            track->setSolo(ts.solo);
        }
    }

    const std::vector<Snapshot>& getSnapshots() const { return m_snapshots; }

private:
    std::vector<Snapshot> m_snapshots;
};

} // namespace Aura::Core::Engine
