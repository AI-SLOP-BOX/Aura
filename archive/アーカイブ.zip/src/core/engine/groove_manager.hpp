#pragma once

#include <vector>
#include <memory>
#include <string>
#include "transient_detector.hpp"

namespace Aura::Core::Engine {

/**
 * @brief GrooveMap: A collection of micro-timing offsets extracted from a performance.
 * The 'DNA' of a rhythm.
 */
struct GrooveMap {
    std::string name;
    std::vector<double> offsets; // Relative to perfect grid
};

/**
 * @brief GrooveManager: Professional Logic Pro-style Groove Extraction.
 * Captures the 'Swing' of a drum loop and applies it to other tracks.
 */
class GrooveManager {
public:
    static GrooveManager& getInstance() { static GrooveManager i; return i; }

    /**
     * @brief EXTRACT: Analyzes a region to create a unique Groove Template.
     */
    GrooveMap extractGroove(const float* data, uint64_t len, float bpm) {
        DSP::Analysis::TransientDetector detector(44100.0);
        double grid = (60.0 / bpm) * 44100.0 / 4.0; // 1/16th grid
        
        GrooveMap map;
        map.name = "Extracted Groove";

        for (uint64_t i = 0; i < len; i += 512) {
            if (detector.detect(data + i, 512)) {
                double target = std::round(i / grid) * grid;
                map.offsets.push_back(i - target);
            }
        }
        return map;
    }

    /**
     * @brief APPLY: Adjusts MIDI or Audio timing to match the extracted Groove.
     */
    void applyGroove(std::vector<MIDINote>& notes, const GrooveMap& map) {
        // Quantize notes to the nearest groove offset
    }

private:
    GrooveManager() = default;
};

} // namespace Aura::Core::Engine
