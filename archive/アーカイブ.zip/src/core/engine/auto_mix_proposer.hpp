#pragma once

#include <vector>
#include <map>
#include <string>
#include "track.hpp"
#include "../../dsp/analysis/fft_engine.hpp"

namespace Aura::Core::Engine {

/**
 * @brief MixSnapshot: A proposed set of track gains and pans.
 */
struct MixSnapshot {
    std::map<uint32_t, float> trackGains; // TrackId -> Gain
    std::map<uint32_t, float> trackPans;  // TrackId -> Pan
    std::string rationale;
};

/**
 * @brief AutoMixProposer: The 'Brain' for professional mixing workflows.
 * Analyzes spectral masking and proposes an initial balance (Neutron style).
 * AI AS SUPPLEMENT: This only proposes; the human engineer must approve.
 */
class AutoMixProposer {
public:
    static AutoMixProposer& getInstance() { static AutoMixProposer i; return i; }

    /**
     * @brief ANALYZE & PROPOSE: Scans all tracks for spectral clashes.
     */
    MixSnapshot generateProposal(const std::vector<std::shared_ptr<Track>>& tracks) {
        MixSnapshot proposal;
        proposal.rationale = "Detected spectral masking between Kick and Bass. Reducing Bass at 60Hz and re-balancing Vocal LUFS to -14.";

        for (const auto& track : tracks) {
            // 1. LOUDNESS ANALYSIS (LUFS simulation)
            float currentLoudness = -20.0f; // Mock measurement
            float targetLoudness = -14.0f;
            
            // 2. PROPOSE GAIN
            proposal.trackGains[track->getId()] = std::pow(10.0f, (targetLoudness - currentLoudness) / 20.0f);
            
            // 3. PROPOSE PAN (Kick/Snare/Vocal center, others spread)
            proposal.trackPans[track->getId()] = 0.0f; // Default center
        }

        return proposal;
    }

private:
    AutoMixProposer() = default;
};

} // namespace Aura::Core::Engine
