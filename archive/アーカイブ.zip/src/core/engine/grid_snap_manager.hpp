#pragma once

#include <cmath>
#include "tempo_map.hpp"

namespace Aura::Core::Engine {

/**
 * @brief GridSnapManager: The "Magnetic" Grid of Aura DAW.
 * Ensures the user's edits are musically locked to 1/4, 1/8, 1/16 etc.
 */
class GridSnapManager {
public:
    enum class Resolution { 
        Measure, 
        Beat, 
        Half, 
        Quarter, 
        Eighth, 
        Sixteenth,
        ThirtySecond
    };

    static uint64_t snap(uint64_t samplePos, Resolution res, double sr = 44100.0) {
        auto& tempo = TempoMap::getInstance();
        double beats = tempo.sampleToBeats(samplePos, sr);
        
        double step = 1.0;
        switch (res) {
            case Resolution::Measure:     step = 4.0; break;
            case Resolution::Beat:        step = 1.0; break;
            case Resolution::Quarter:     step = 1.0; break; // 1/4 note is 1 beat
            case Resolution::Eighth:      step = 0.5; break;
            case Resolution::Sixteenth:   step = 0.25; break;
            case Resolution::ThirtySecond: step = 0.125; break;
            default: step = 1.0; break;
        }

        double snappedBeats = std::round(beats / step) * step;
        return tempo.beatsToSamples(snappedBeats, sr);
    }
};

} // namespace Aura::Core::Engine
