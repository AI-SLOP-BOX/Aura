#pragma once
#include <cmath>
#include <vector>
#include "../audio_buffer.hpp"

namespace Aura::Core::Engine {

/**
 * @brief Metronome: Generates rhythmic click signals for synchronization.
 * HONEST FIX: Uses an impulsive oscillator to prevent spectral bleed.
 */
class Metronome {
public:
    Metronome(double sr = 44100.0) : m_sampleRate(sr) {}

    void setEnabled(bool e) { m_isEnabled = e; }
    bool isEnabled() const { return m_isEnabled; }

    /**
     * @brief THE CLICK: Triggers a high/low pitch sample-accurate pulse.
     */
    void trigger(bool accent) {
        m_phase = 0.0;
        m_frequency = accent ? 880.0 : 440.0; // Higher pitch for bar start
        m_active = true;
        m_samplesLeft = static_cast<uint32_t>(0.05 * m_sampleRate); // 50ms click
    }

    void process(float* l, float* r, uint32_t numSamples) {
        if (!m_isEnabled || !m_active) return;

        for (uint32_t s = 0; s < numSamples; ++s) {
            if (m_samplesLeft > 0) {
                // Sine oscillator with basic linear decay envelope
                float env = static_cast<float>(m_samplesLeft) / (0.05f * m_sampleRate);
                float val = std::sin(static_cast<float>(m_phase * 2.0 * M_PI)) * env * 0.5f;
                
                l[s] += val;
                r[s] += val;

                m_phase += m_frequency / m_sampleRate;
                if (m_phase >= 1.0) m_phase -= 1.0;
                --m_samplesLeft;
            } else {
                m_active = false;
                break;
            }
        }
    }

private:
    double m_sampleRate;
    double m_frequency = 440.0;
    double m_phase = 0.0;
    bool m_isEnabled = false;
    bool m_active = false;
    uint32_t m_samplesLeft = 0;
};

} // namespace Aura::Core::Engine
