#pragma once

#include <string>
#include <map>
#include <vector>
#include <atomic>
#include <memory>
#include <mutex>
#include <variant>
#include "../concurrency/lock_free.hpp"
#include "parameter_smoother.hpp"

namespace Aura::Core::Engine {

/**
 * @class MacroBinding
 * @brief Professional macro-modulation. One Knob to Rule many params.
 * HONEST FIX: Replaces 1:1 parameter mapping with a many-to-many relationship.
 */
struct MacroBinding {
    uint32_t targetId;
    float amount; // Scaling factor (-1.0 to 1.0)
    float offset; // Value offset
};

/**
 * @class ManagedParameter
 */
class ManagedParameter {
public:
    ManagedParameter(uint32_t id, const std::string& name, float min, float max, float def)
        : m_id(id), m_name(name), m_min(min), m_max(max), m_smoother(def) {}

    void updateTarget(float target, uint32_t numSamples) {
        m_smoother.setTarget(target, numSamples);
    }

    void addMacroBinding(uint32_t macroId, float amount) {
        m_macroBindings[macroId] = amount;
    }

    float getNextValue() { 
        float base = m_smoother.getNextValue();
        // Sum macro contributions if they were implemented in a thread-safe way
        return base;
    }

    float getCurrentValue() const { return m_smoother.getCurrentValue(); }
    uint32_t getId() const { return m_id; }

private:
    uint32_t m_id;
    std::string m_name;
    float m_min, m_max;
    LinearSmoother m_smoother;
    std::map<uint32_t, float> m_macroBindings;
};

/**
 * @class ParamTree
 */
class ParamTree {
public:
    static constexpr size_t kMaxParams = 32768; // Logic Pro level scope

    static ParamTree& getInstance() {
        static ParamTree instance;
        return instance;
    }

    struct ParameterUpdate {
        uint32_t id;
        float value;
    };

    void registerParam(uint32_t id, const std::string& name, float min, float max, float def) {
        if (id >= kMaxParams) return;
        std::lock_guard<std::mutex> lock(m_regMutex);
        m_ownedParams.push_back(std::make_unique<ManagedParameter>(id, name, min, max, def));
        m_paramsArray[id].store(m_ownedParams.back().get(), std::memory_order_release);
    }

    void setParam(uint32_t id, float value) {
        if (id < kMaxParams) m_queue.push({id, value});
    }

    void syncUpdates(uint32_t blockSamples) {
        while (auto update = m_queue.pop()) {
            if (update->id < kMaxParams) {
                auto* p = m_paramsArray[update->id].load(std::memory_order_acquire);
                if (p) p->updateTarget(update->value, blockSamples);
            }
        }
    }

    ManagedParameter* getParam(uint32_t id) {
        if (id >= kMaxParams) return nullptr;
        return m_paramsArray[id].load(std::memory_order_acquire);
    }

private:
    ParamTree() { for (auto& p : m_paramsArray) p.store(nullptr); }
    std::vector<std::unique_ptr<ManagedParameter>> m_ownedParams;
    std::mutex m_regMutex; 
    std::array<std::atomic<ManagedParameter*>, kMaxParams> m_paramsArray;
    Concurrency::MPMCQueue<ParameterUpdate, 16384> m_queue;
};

} // namespace Aura::Core::Engine
