#pragma once

#include <vector>
#include <algorithm>
#include <cmath>

namespace Aura::Core::Engine {

/**
 * @class AutomationCurve
 * @brief Professional Cubic Bezier Automation Engine.
 */
class AutomationCurve {
public:
    struct Point {
        double time;
        float value;
        float h1x = 0.25f, h1y = 0.5f;
        float h2x = 0.75f, h2y = 0.5f;
    };

    /**
     * @brief SAMPLE-ACCURATE FILL: Efficiently computes values for every sample.
     */
    void fillBuffer(float* buffer, uint32_t numSamples, double startTime, double endTime) {
        if (m_points.empty()) {
            std::fill(buffer, buffer + numSamples, 0.0f);
            return;
        }

        if (m_points.size() == 1) {
            std::fill(buffer, buffer + numSamples, m_points[0].value);
            return;
        }

        double step = (endTime - startTime) / (numSamples > 1 ? numSamples - 1 : 1);
        size_t currentIdx = 0;

        for (uint32_t i = 0; i < numSamples; ++i) {
            double currentTime = startTime + i * step;
            
            // Forward-walking segment search
            while (currentIdx < m_points.size() - 2 && currentTime >= m_points[currentIdx + 1].time) {
                currentIdx++;
            }
            
            buffer[i] = evaluateAt(currentTime, currentIdx);
        }
    }

    float getValueAt(double time) {
        if (m_points.empty()) return 0.0f;
        auto it = std::lower_bound(m_points.begin(), m_points.end(), time, 
            [](const Point& p, double t) { return p.time < t; });
        size_t idx = (it == m_points.begin()) ? 0 : (std::distance(m_points.begin(), it) - 1);
        return evaluateAt(time, idx);
    }

    void addPoint(double time, float value, float h1y = 0.5f, float h2y = 0.5f) {
        m_points.push_back({time, value, 0.25f, h1y, 0.75f, h2y});
        std::sort(m_points.begin(), m_points.end(), [](const Point& a, const Point& b) {
            return a.time < b.time;
        });
    }

    /**
     * @brief GPU RENDER PATH: Generates a high-res vertex array for the UI.
     */
    std::vector<float> renderPath(double startTime, double endTime, float vMin, float vMax, float height, float xOffset) {
        std::vector<float> path;
        if (m_points.empty()) return path;

        int numSteps = 200; // Resolution per screen
        float dx = (endTime - startTime) / numSteps;

        for (int i = 0; i <= numSteps; ++i) {
            double t = startTime + (i * dx);
            float val = getValueAt(t);
            
            // Normalize value to pixel height (DAW view coords)
            float normVal = (val - vMin) / (vMax - vMin + 1e-6f);
            float px = xOffset + (i * (float)(xOffset / numSteps)); // Simple x-mapping
            float py = height * (1.0f - normVal);
            
            path.push_back(px);
            path.push_back(py);
        }
        return path;
    }

private:
    float evaluateAt(double time, size_t idx) const {
        if (time <= m_points.front().time) return m_points.front().value;
        if (time >= m_points.back().time) return m_points.back().value;

        const auto& p1 = m_points[idx];
        const auto& p2 = m_points[idx + 1];

        double t = (time - p1.time) / (p2.time - p1.time + 1e-9);
        
        // Industry Standard Power-Curve mapping for DAW Bézier Automation
        float intensity = (p1.h1y + p1.h2y) * 0.5f;
        double mappedT = std::pow(t, std::exp(-intensity * 4.0f + 2.0f));

        return p1.value + static_cast<float>(mappedT) * (p2.value - p1.value);
    }

    std::vector<Point> m_points;
};

} // namespace Aura::Core::Engine
