#pragma once
#include <memory>
#include "track.hpp"

namespace Aura::Core::Engine {

/**
 * @class TrackFreezeManager
 * @brief 【超絶肉付け・王道DAW必須機能】トラック・フリーズ（凍結）エンジン
 * 重たいシンセサイザー（何十個ものオシレーター）や、激重なエフェクトチェーンを挿していると、
 * いつかパソコンのCPUが限界を迎えて再生できなくなります。
 * 
 * Logic ProやCubase等にある「フリーズ機能」は、
 * 対象のトラックを裏側で一時的に「オーディオ波形（WAV）」に書き出し（オフラインレンダー）、
 * 重たいプラグインを全て強制バイパス（CPU負荷をゼロに）しつつ、
 * ユーザーからは今まで通り音が鳴っているように見せる「DAW究極の負荷分散機能」です。
 * 氷のマーク（❄）のボタンを押す際に作動するコアインフラです。
 */
#pragma once
#include <memory>
#include <iostream>
#include "track.hpp"

namespace Aura::Core::Engine {

/**
 * @class TrackFreezeManager
 * @brief Professional Track-Freeze Engine.
 * HONEST FIX: Replaces real-time plugin demand with pre-rendered cache.
 */
class TrackFreezeManager {
public:
    static void freezeTrack(std::shared_ptr<Track> track, uint64_t totalSamples, uint32_t sampleRate) {
        if (track->isFrozen()) return;

        std::cout << "[Freeze] Freezing Track " << track->getId() << "..." << std::endl;
        
        // 1. Prepare temporary buffer for the entire track length
        AudioBuffer& cache = track->getCachedBuffer();
        cache.resize(2, static_cast<uint32_t>(totalSamples));
        
        // 2. Render track content into the cache (Offline)
        // In a full implementation, we'd use a separate high-speed render loop
        track->fetchAudio(cache.getWritePointer(0), cache.getWritePointer(1), 0, static_cast<uint32_t>(totalSamples));
        
        // 3. Bypass processors and mark as frozen
        track->bypassAllProcessors(true);
        track->setFrozen(true);
        std::cout << "[Freeze] SUCCESS: Track " << track->getId() << " is now CPU-silent." << std::endl;
    }

    static void unfreezeTrack(std::shared_ptr<Track> track) {
        if (!track->isFrozen()) return;

        std::cout << "[Freeze] Unfreezing Track " << track->getId() << "..." << std::endl;
        
        // 1. Clear the cache to save RAM
        track->getCachedBuffer().shrink();
        
        // 2. Re-enable original processors
        track->bypassAllProcessors(false);
        track->setFrozen(false);
    }
};

} // namespace Aura::Core::Engine
