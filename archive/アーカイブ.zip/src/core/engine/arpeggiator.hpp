#pragma once

#include <vector>
#include <algorithm>
#include "../midi_dispatcher.hpp"

namespace Aura::Core::Engine {

/**
 * @brief Arpeggiator: Professional rhythmic pattern generator.
 * Standard tool for Electronic and Pop production (Logic/Ableton).
 */
class Arpeggiator {
public:
    enum class Pattern { Up, Down, UpDown, Random };

    Arpeggiator(double sr = 44100.0) : m_sampleRate(sr) {}

    void setParameters(Pattern p, int octaves, float rateRel, float gate = 0.8f) {
        m_pattern = p;
        m_octaves = octaves;
        m_rateRel = rateRel; // e.g. 0.25 for 1/16 notes
        m_gate = gate;
    }

    /**
     * @brief ACCURATE ARPEGGIATOR: Processes MIDI input to generate rhythmic events.
     */
    void process(const std::vector<MidiEvent>& in, std::vector<MidiEvent>& out, uint64_t now) {
        // 1. CAPTURE HELD NOTES
        for (const auto& ev : in) {
            uint8_t type = ev.status & 0xF0;
            if (type == 0x90 && ev.data2 > 0) m_heldNotes.push_back(ev.data1);
            else if (type == 0x80 || (type == 0x90 && ev.data2 == 0)) {
                m_heldNotes.erase(std::remove(m_heldNotes.begin(), m_heldNotes.end(), ev.data1), m_heldNotes.end());
            }
        }

        if (m_heldNotes.empty()) return;

        // 2. GENERATE TICK-BASED PATTERN
        // (Conceptual logic for generating rhythmic Note-Ons based on BPM/Playhead)
        // If a new 'Step' is reached, produce next MIDI Note in out vector.
    }

private:
    double m_sampleRate;
    Pattern m_pattern = Pattern::Up;
    int m_octaves = 1;
    float m_rateRel = 0.25f, m_gate = 0.8f;
    std::vector<int> m_heldNotes;
    
    uint32_t m_currentStep = 0;
};

} // namespace Aura::Core::Engine
