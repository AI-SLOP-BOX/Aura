#pragma once

#include <vector>
#include <array>
#include <map>
#include <string>
#include <cmath>
#include <atomic>
#include "param_tree.hpp"

namespace Aura::Core::Engine {

enum class TransferCurve {
    Linear,
    Exponential,
    Logarithmic,
    SCurve
};

/**
 * @brief MacroTarget: A single parameter linked to a macro.
 */
struct MacroTarget {
    uint32_t trackId;
    uint32_t pluginIdx;
    uint32_t paramId;
    float minVal = 0.0f;
    float maxVal = 1.0f;
    TransferCurve curve = TransferCurve::Linear;
};

/**
 * @brief MacroControlManager: Professional 'Smart Control' Infrastructure.
 * 【超絶肉付け】Serum / Logic Pro水準のモジュレーション・マトリックスへ昇華。
 * 1つのノブで複数のパラメータを同時に、しかも「異なるカーブ（S字、指数関数等）」で
 * コントロールできる高度なマッピング機能を提供します。
 */
class MacroControlManager {
public:
    static MacroControlManager& getInstance() { static MacroControlManager i; return i; }

    /**
     * @brief LINK: Maps a macro knob to an internal engine parameter with a specific curve.
     */
    void link(uint32_t macroIdx, const MacroTarget& target) {
        if (macroIdx < kMaxMacros) {
            auto& m = m_macros[macroIdx];
            size_t count = m.count.load(std::memory_order_relaxed);
            if (count < kMaxTargetsPerMacro) {
                m.targets[count] = target;
                m.count.store(count + 1, std::memory_order_release);
            }
        }
    }

    /**
     * @brief SET VALUE: Propagates a macro value to all its targets using mathematical curves.
     * @param value: Normalized [0, 1] macro knob position.
     */
    void setMacroValue(uint32_t macroIdx, float value) {
        if (macroIdx >= kMaxMacros) return;
        
        m_macroValues[macroIdx].store(value, std::memory_order_relaxed);
        
        auto& m = m_macros[macroIdx];
        size_t count = m.count.load(std::memory_order_acquire);
        
        for (size_t i = 0; i < count; ++i) {
            const auto& target = m.targets[i];
            
            // 1. Apply Transfer Curve
            float shapedValue = value;
            switch(target.curve) {
                case TransferCurve::Exponential:
                    shapedValue = std::pow(value, 2.5f);
                    break;
                case TransferCurve::Logarithmic:
                    shapedValue = std::log10(1.0f + 9.0f * value); // 0.0 to 1.0 mapping
                    break;
                case TransferCurve::SCurve:
                    shapedValue = value * value * (3.0f - 2.0f * value); // Smoothstep
                    break;
                case TransferCurve::Linear:
                default:
                    shapedValue = value;
                    break;
            }

            // 2. Scale to Parameter Range
            float scaled = target.minVal + shapedValue * (target.maxVal - target.minVal);
            
            // 3. Dispatch
            ParamTree::getInstance().setParam(target.paramId, scaled);
        }
    }

    /**
     * @brief Get the current normalized value of a macro (used by UI).
     */
    float getMacroValue(uint32_t macroIdx) const {
        if (macroIdx < kMaxMacros) {
            return m_macroValues[macroIdx].load(std::memory_order_relaxed);
        }
        return 0.0f;
    }

private:
    MacroControlManager() {
        for (auto& v : m_macroValues) v.store(0.0f);
    }
    
    static constexpr size_t kMaxMacros = 256;
    static constexpr size_t kMaxTargetsPerMacro = 64; 
    
    struct MacroGroup {
        std::array<MacroTarget, kMaxTargetsPerMacro> targets;
        std::atomic<size_t> count{0};
    };
    
    std::array<MacroGroup, kMaxMacros> m_macros;
    std::array<std::atomic<float>, kMaxMacros> m_macroValues; // Feedback for UI
};

} // namespace Aura::Core::Engine
