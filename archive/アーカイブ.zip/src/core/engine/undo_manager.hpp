#pragma once

#include <vector>
#include <string>
#include <memory>
#include <functional>
#include <deque>

namespace Aura::Core::Engine {

/**
 * @brief Action: Abstract base for any undoable user action in the DAW.
 * Captures the state before and after the change.
 */
class Action {
public:
    virtual ~Action() = default;
    virtual void undo() = 0;
    virtual void redo() = 0;
    virtual std::string getName() const = 0;
};

/**
 * @brief UndoManager: The "Time Machine" of Aura DAW.
 * Manages the history of actions for perfect session recovery and editing safety.
 */
class UndoManager {
public:
    static UndoManager& getInstance() {
        static UndoManager instance;
        return instance;
    }

    void perform(std::shared_ptr<Action> action) {
        action->redo();
        m_history.erase(m_history.begin() + m_currentIndex, m_history.end());
        m_history.push_back(action);
        m_currentIndex++;
        
        // Circular window (e.g., last 100 actions)
        if (m_history.size() > 100) {
            m_history.pop_front();
            m_currentIndex--;
        }
    }

    void undo() {
        if (m_currentIndex > 0) {
            m_currentIndex--;
            m_history[m_currentIndex]->undo();
        }
    }

    void redo() {
        if (m_currentIndex < m_history.size()) {
            m_history[m_currentIndex]->redo();
            m_currentIndex++;
        }
    }

    bool canUndo() const { return m_currentIndex > 0; }
    bool canRedo() const { return m_currentIndex < m_history.size(); }

private:
    UndoManager() = default;
    std::deque<std::shared_ptr<Action>> m_history;
    size_t m_currentIndex = 0;
};

} // namespace Aura::Core::Engine
