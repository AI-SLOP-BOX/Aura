#include "engine_clock.hpp"

namespace Aura::Core::Engine {

/**
 * @brief EngineClock: The unwavering temporal pulse of the DAW.
 * Bridges musical time (BPM/Beats) with physical time (Samples/Seconds).
 */
EngineClock& EngineClock::getInstance() {
    static EngineClock instance;
    return instance;
}

void EngineClock::advance(uint32_t samples) {
    m_currentSample.fetch_add(samples);
}

double EngineClock::samplesToBeats(uint64_t samples, double bpm) {
    return (samples / m_sampleRate) * (bpm / 60.0);
}

uint64_t EngineClock::beatsToSamples(double beats, double bpm) {
    return static_cast<uint64_t>((beats * 60.0 / bpm) * m_sampleRate);
}

uint64_t EngineClock::getCurrentSample() const {
    return m_currentSample.load();
}

} // namespace Aura::Core::Engine
