#pragma once

#include <cmath>
#include <atomic>
#include "grid_system.hpp"

namespace Aura::Core::Engine {

/**
 * @brief MetronomeEngine: High-precision timing click generator for recording.
 * Synchronizes with the GridSystem to provide downbeat and upbeat audible cues.
 */
class MetronomeEngine {
public:
    explicit MetronomeEngine(double sr) : m_sampleRate(sr) {}

    /**
     * @brief Generates one block of click audio if active.
     */
    void process(float* l, float* r, size_t numFrames, uint64_t currentSample) {
        if (!m_isActive.load()) return;

        double samplesPerBeat = (60.0 / m_bpm) * m_sampleRate;
        for (size_t i = 0; i < numFrames; ++i) {
            uint64_t globalPos = currentSample + i;
            bool isBeatStart = (globalPos % static_cast<uint64_t>(samplesPerBeat)) < 512;
            bool isDownbeat = (globalPos % static_cast<uint64_t>(samplesPerBeat * 4)) < 512;

            if (isBeatStart) {
                float freq = isDownbeat ? 1000.0f : 800.0f; // Accent on downbeat
                float sample = std::sin(m_phase * 6.283185f) * 0.5f;
                l[i] += sample; r[i] += sample;
                m_phase += freq / m_sampleRate;
            } else {
                m_phase = 0.0f;
            }
        }
    }

    void setActive(bool active) { m_isActive.store(active); }
    void setBPM(double bpm) { m_bpm = bpm; }

private:
    double m_sampleRate;
    std::atomic<bool> m_isActive{false};
    double m_bpm = 120.0;
    float m_phase = 0.0f;
};

} // namespace Aura::Core::Engine
