#pragma once

#include <vector>
#include <deque>
#include <mutex>
#include "midi_sequencer.hpp"

namespace Aura::Core::Engine {

/**
 * @brief RetrospectiveMidiCapture: Always-on "Shadow" recording for MIDI.
 * Iconic Logic Pro feature that allows "Shift-R" to salvage captures performed before record-on.
 */
class RetrospectiveMidiCapture {
public:
    static RetrospectiveMidiCapture& getInstance() {
        static RetrospectiveMidiCapture instance;
        return instance;
    }

    /**
     * @brief Automatically pushes every incoming MIDI event to a ring buffer.
     */
    void logEvent(const MidiNote& note) {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_captureBuffer.push_back(note);
        if (m_captureBuffer.size() > m_maxBuffer) m_captureBuffer.pop_front();
    }

    /**
     * @brief Fetches all captured notes to be placed on the timeline.
     */
    std::vector<MidiNote> flushCapture() {
        std::lock_guard<std::mutex> lock(m_mutex);
        std::vector<MidiNote> capture(m_captureBuffer.begin(), m_captureBuffer.end());
        m_captureBuffer.clear();
        return capture;
    }

private:
    RetrospectiveMidiCapture() = default;

    std::deque<MidiNote> m_captureBuffer;
    const size_t m_maxBuffer = 5000; // Store last ~5000 notes
    std::mutex m_mutex;
};

} // namespace Aura::Core::Engine
