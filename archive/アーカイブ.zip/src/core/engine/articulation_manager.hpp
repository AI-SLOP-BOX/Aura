#pragma once

#include <vector>
#include <string>
#include <map>

namespace Aura::Core::Engine {

/**
 * @brief Articulation: A musical playing technique (Legato, Staccato, etc.).
 */
struct Articulation {
    uint32_t id;
    std::string name;
    uint8_t switchNote; // MIDI note that triggers this
    uint8_t targetMidiChannel; // (For multi-channel instruments like Kontakt)
};

/**
 * @brief ArticulationManager: Professional Orchestral Scoring tool.
 * Standard for managing complex library switches (Legato/Pizz/Trem).
 */
class ArticulationManager {
public:
    static ArticulationManager& getInstance() { static ArticulationManager i; return i; }

    /**
     * @brief REGISTER ARTICULATION: Maps a musical technique to a MIDI trigger.
     */
    void registerArticulation(uint32_t trackId, const Articulation& art) {
        m_trackArticulations[trackId][art.id] = art;
    }

    /**
     * @brief TRIGGER: Switches the active articulation for a track.
     */
    void setActiveArticulation(uint32_t trackId, uint32_t artId) {
        m_activeArticulation[trackId] = artId;
        // (Conceptual MIDI message dispatch to the instrument)
    }

    const Articulation* getActiveArticulation(uint32_t trackId) const {
        if (!m_activeArticulation.count(trackId)) return nullptr;
        uint32_t id = m_activeArticulation.at(trackId);
        return &m_trackArticulations.at(trackId).at(id);
    }

private:
    ArticulationManager() = default;

    // TrackId -> ArtId -> Articulation
    std::map<uint32_t, std::map<uint32_t, Articulation>> m_trackArticulations;
    std::map<uint32_t, uint32_t> m_activeArticulation;
};

} // namespace Aura::Core::Engine
