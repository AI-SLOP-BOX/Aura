#pragma once
#include <atomic>
#include <cstdint>

namespace Aura::Core::Engine {

class EngineClock {
public:
    static EngineClock& getInstance();
    
    void advance(uint32_t samples);
    double samplesToBeats(uint64_t samples, double bpm);
    uint64_t beatsToSamples(double beats, double bpm);
    uint64_t getCurrentSample() const;
    
    void setSampleRate(double sr) { m_sampleRate = sr; }
    double getSampleRate() const { return m_sampleRate; }

private:
    EngineClock() : m_currentSample(0), m_sampleRate(44100.0) {}
    std::atomic<uint64_t> m_currentSample;
    double m_sampleRate;
};

} // namespace Aura::Core::Engine
