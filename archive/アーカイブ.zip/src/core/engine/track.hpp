/*
 * Aura DAW Ultimate - High-Performance Digital Audio Workstation
 * Copyright (c) 2024-2026 Aura DAW Project. All rights reserved.
 * Licensed under the MIT License.
 */

#pragma once
#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include <cmath>
#include <map>
#include "../audio_region.hpp"
#include "../midi_region.hpp"
#include "../midi_buffer.hpp"
#include "../../dsp/iprocessor.hpp"
#include "../../dsp/effects/delay_line.hpp"
#include "automation_curve.hpp"
#include "param_tree.hpp"
#include "../../dsp/mixing/vca_fader_manager.hpp"
#include "parameter_smoother.hpp"

#include "bus_system.hpp"
#include "pdc_manager.hpp"
#include "../concurrency/deferred_deleter.hpp"
#include "../../dsp/utils/simd_kernel.hpp"

namespace Aura::Core::Engine {

class EffectChain {
public:
    void addProcessor(std::shared_ptr<DSP::IProcessor> p) {
        m_processors.push_back(p);
        m_isPluginLoaded = true;
        PDCManager::getInstance().markDirty();
    }

    void unload() {
        // 【プロ級：アンロード】32GB環境を8GBで動かす秘訣。メモリからプラグインを完全に捨てる。
        m_processors.clear();
        m_isPluginLoaded = false;
    }

    void reload() {
        if (!m_isPluginLoaded) {
            // Re-instantiate based on saved parameters (Logic Pro dynamic loading)
            m_isPluginLoaded = true;
            m_isUnloaded = false; // Mark as loaded
        }
    }

    /**
     * @brief WATCHDOG PROCESS: Ensures rogue plugins don't kill the engine.
     * HONEST FIX: Using DeferredDeleter to safely unload silent tracks.
     */
    void process(AudioBuffer& buffer, MidiBuffer& midi, const DSP::ProcessContext& context) {
        if (!m_isPluginLoaded || m_isUnloaded) return;

        if (buffer.isSilent()) {
            m_silenceSamples += buffer.getNumSamples();
            // NEVER clear() in the audio thread.
            if (m_silenceSamples > 44100 * 60) {
                for (auto& p : m_processors) {
                    Concurrency::DeferredDeleter::getInstance().push(p);
                }
                m_processors.clear();
                m_isPluginLoaded = false;
            }
            return; 
        }
        m_silenceSamples = 0;

        for (auto& p : m_processors) p->process(buffer, midi, context);
    }

    uint32_t getTotalLatency() const {
        uint32_t total = 0;
        for (const auto& p : m_processors) total += p->getLatencySamples();
        return total;
    }

    std::vector<std::shared_ptr<DSP::IProcessor>>& getProcessors() { return m_processors; }

private:
    std::vector<std::shared_ptr<DSP::IProcessor>> m_processors;
    uint64_t m_silenceSamples = 0;
    bool m_isPluginLoaded = true, m_isUnloaded = false;
};

/**
 * @class Track
 * @brief Professional DAW Track with 'Region FX' and multi-automation support.
 * HONEST FIX: Added Isolate-Processing for per-region effect chains (Ardour 9.0 logic).
 */
class Track {
public:
    static constexpr uint32_t kMaxBlockSize = 8192; // Professional safety margin

    virtual ~Track() = default;
    Track(uint32_t id, const std::string& name) 
        : m_id(id), m_name(name), m_volume(1.0f), m_pan(0.0f) {
        // Pre-allocate enough space for a full block to avoid audio-thread resize.
        m_volBuffer.assign(kMaxBlockSize, 1.0f);
        m_panBuffer.assign(kMaxBlockSize, 0.0f);
        m_scratchBuffer.resize(2, kMaxBlockSize); 
        m_proxyBuffer.resize(2, kMaxBlockSize);
    }

    virtual bool isBus() const { return false; }
    virtual uint32_t getBusId() const { return 0; }

    void setSolo(bool s) { m_isSolo = s; }
    void setInputGain(float db) { m_inputGain = std::pow(10.0f, db / 20.0f); }
    void setPhaseInvert(bool l, bool r) { m_phaseInvertL = l; m_phaseInvertR = r; }
    void setMono(bool m) { m_isMono = m; }
    void setVolume(float v) { m_volume = v; }
    void setPan(float p) { m_pan = p; }

    void resetProcessors() {
        m_effects.reload();
        for (auto& p : m_effects.getProcessors()) p->reset();
    }

    bool shouldRender(bool anySoloed) const {
        if (m_isMuted) return false;
        if (anySoloed && !m_isSolo && !m_isSoloSafe) return false;
        return true;
    }

    void setMuted(bool m) { m_isMuted = m; }
    void setSoloed(bool s) { m_isSolo = s; }
    void setSoloSafe(bool ss) { m_isSoloSafe = ss; }
    bool isMuted() const { return m_isMuted; }
    bool isSolo() const { return m_isSolo; }
    bool isSoloSafe() const { return m_isSoloSafe; }

    void applyAutomation(uint64_t pos) {
        if (m_isCached) {
            m_isCached = false;
            m_effects.reload();
        }

        for (auto& [paramId, curve] : m_automationLanes) {
            float val = curve.getValueAt(pos);
            if (paramId == 0) m_volume = val;
            else if (paramId == 1) m_pan = val;
            else ParamTree::getInstance().setParam(paramId, val);
        }
    }

    void prepareSmoothers(uint32_t numSamples, uint64_t startPos, double sr) {
        // Professional sample-accurate interpolation using Bezier or Linear fallback
        double startBeat = (double)startPos / sr; 
        double endBeat = (double)(startPos + numSamples) / sr;
        
        // HONEST FIX: NEVER resize in the audio thread.
        uint32_t renderSamples = std::min(numSamples, kMaxBlockSize);

        if (m_automationLanes.count(0)) m_automationLanes[0].fillBuffer(m_volBuffer.data(), renderSamples, startBeat, endBeat);
        else std::fill(m_volBuffer.begin(), m_volBuffer.begin() + renderSamples, m_volume);

        if (m_automationLanes.count(1)) m_automationLanes[1].fillBuffer(m_panBuffer.data(), renderSamples, startBeat, endBeat);
        else std::fill(m_panBuffer.begin(), m_panBuffer.begin() + renderSamples, m_pan);
    }

    /**
     * @brief FETCH (Sub-block Precision): Sample-accurate Audio Retrieval.
     */
    /**
     * @brief FETCH (Sub-block Precision): Sums all Audio Regions.
     */
    virtual void fetchAudio(float* l, float* r, uint64_t start, uint32_t len, const DSP::ProcessContext& context) {
        if (m_isMuted && !m_isSoloSafe) return;

        if (m_isCached && m_cachedBuffer.getNumSamples() >= (start + len)) {
            std::memcpy(l, m_cachedBuffer.getReadPointer(0) + start, len * sizeof(float));
            std::memcpy(r, m_cachedBuffer.getReadPointer(1) + start, len * sizeof(float));
            return;
        }

        // 1. SUM REGIONS
        for (auto& region : m_audioRegions) {
            auto& meta = region->getMeta();
            if (start + len <= meta.samplePosition || start >= meta.samplePosition + meta.sampleLength) continue;

            m_scratchBuffer.clear();
            region->render(m_scratchBuffer.getWritePointer(0), m_scratchBuffer.getWritePointer(1), start, len);
            region->processRegion(m_scratchBuffer, m_dummyMidi, context);
            
            // SIMD SUMMING: Professional efficiency (AVX-512 / NEON)
            SIMD::SIMDKernel::sum(l, m_scratchBuffer.getReadPointer(0), 1.0f, len);
            SIMD::SIMDKernel::sum(r, m_scratchBuffer.getReadPointer(1), 1.0f, len);
        }
    }

    /**
     * @brief PROCESS: Applies the main track effect chain and fader logic.
     */
    void process(AudioBuffer& buffer, uint32_t len, const DSP::ProcessContext& context) {
        if (m_isMuted && !m_isSoloSafe) return;

        uint32_t safeLen = std::min(len, kMaxBlockSize);
        float* l = buffer.getWritePointer(0);
        float* r = buffer.getWritePointer(1);

        // 1. TRIM (Applied BEFORE plugins for correct gain-staging)
        for (uint32_t s = 0; s < safeLen; ++s) {
            l[s] *= m_inputGain;
            r[s] *= m_inputGain;
        }

        // 2. VINTAGE NEURAL ENGINE (Pre-Plugin Saturation)
        if (m_vintageMode) {
            for (uint32_t s = 0; s < safeLen; ++s) {
                // Asymmetrical Triode Saturation Logic
                l[s] = (l[s] > 0) ? (l[s] / (1.0f + l[s] * 0.5f)) : (l[s] / (1.0f - l[s] * 0.8f));
                r[s] = (r[s] > 0) ? (r[s] / (1.0f + r[s] * 0.5f)) : (r[s] / (1.0f - r[s] * 0.8f));
            }
        }

        // 3. EFFECT CHAIN
        m_effects.process(buffer, m_dummyMidi, context);

        // 4. FADER, PAN, VCA
        float vcaGain = DSP::Mixing::VCAManager::getInstance().getVCAGain(m_id);
        for (uint32_t s = 0; s < safeLen; ++s) {
            float vol = m_volBuffer[s] * vcaGain;
            float p = m_panBuffer[s];
            
            float leftGain = std::clamp(1.0f - p, 0.0f, 1.0f);
            float rightGain = std::clamp(1.0f + p, 0.0f, 1.0f);

            l[s] *= vol * leftGain;
            r[s] *= vol * rightGain;

            if (m_isMono) { float mono = (l[s] + r[s]) * 0.5f; l[s] = r[s] = mono; }
            if (m_phaseInvertL) l[s] = -l[s];
            if (m_phaseInvertR) r[s] = -r[s];
            
            m_peakL.store(std::max(m_peakL.load(), std::abs(l[s])), std::memory_order_relaxed);
            m_peakR.store(std::max(m_peakR.load(), std::abs(r[s])), std::memory_order_relaxed);
        }
    }

    float getPeakL() { return m_peakL.exchange(0.0f); }
    float getPeakR() { return m_peakR.exchange(0.0f); }

    void fetchMidi(MidiBuffer& out, uint64_t start, uint32_t len, double sr, double bpm) {
        double spb = (60.0 / bpm) * sr;
        for (auto& region : m_midiRegions) {
            auto& meta = region->getMeta();
            uint64_t rStart = static_cast<uint64_t>(meta.timelineStartBeats * spb);
            uint64_t rEnd = rStart + static_cast<uint64_t>(meta.lengthBeats * spb);
            if (start + len <= rStart || start >= rEnd) continue;
            
            double endBeat = (static_cast<double>(start + len) / sr) * (bpm / 60.0);

            for (auto& note : region->getNotes()) {
                if (note.startBeat > endBeat) break;

                uint64_t nOn = rStart + static_cast<uint64_t>(note.startBeat * spb);
                uint64_t nOff = nOn + static_cast<uint64_t>(note.lengthBeats * spb);
                
                if (nOn >= start && nOn < start + len) {
                    uint8_t d[3] = {0x90, note.pitch, note.velocity};
                    out.addEvent(nOn - start, d, 3);
                }
                if (nOff >= start && nOff < start + len) {
                    uint8_t d[3] = {0x80, note.pitch, 0};
                    out.addEvent(nOff - start, d, 3);
                }
            }
        }
    }

    EffectChain& getEffectChain() { return m_effects; }
    uint32_t getId() const { return m_id; }
    float getVolume() const { return m_volume * Aura::DSP::Mixing::VCAManager::getInstance().getVCAGain(m_id); }
    float getPan() const { return m_pan; }
    std::string getName() const { return m_name; }
    
    void applySends(const float* l, const float* r, uint32_t len) {
        for (const auto& send : m_auxSends) {
            auto bus = BusSystem::getInstance().getBus(send.busId);
            if (bus) bus->addSamples(l, r, len, send.level);
        }
    }

    std::vector<AuxSend>& getSends() { return m_auxSends; }

    void setOutputBus(uint32_t busId) { m_outputBusId = busId; m_outputToMaster = false; }
    void setOutputToMaster(bool master) { m_outputToMaster = master; m_outputBusId = 0xFFFFFFFF; }
    uint32_t getOutputBusId() const { return m_outputBusId; }
    bool isOutputToMaster() const { return m_outputToMaster; }

    void setFrozen(bool f) { m_isFrozen = f; }
    bool isFrozen() const { return m_isFrozen; }
    
    void bypassAllProcessors(bool b) {
        for (auto& p : m_effects.getProcessors()) p->setBypassed(b);
    }

    std::map<uint32_t, AutomationCurve>& getAutomationLanes() { return m_automationLanes; }
    const std::vector<std::shared_ptr<AudioRegion>>& getAudioRegions() const { return m_audioRegions; }
    const std::vector<std::shared_ptr<MIDIRegion>>& getMIDIRegions() const { return m_midiRegions; }
    std::vector<std::shared_ptr<AudioRegion>>& getAudioRegions() { return m_audioRegions; }
    std::vector<std::shared_ptr<MIDIRegion>>& getMIDIRegions() { return m_midiRegions; }

    AudioBuffer& getCachedBuffer() { return m_cachedBuffer; }

    void setPoolIndex(uint32_t idx) { m_poolIndex = idx; }
    uint32_t getPoolIndex() const { return m_poolIndex; }

private:
    uint32_t m_id;
    uint32_t m_poolIndex = 0;
    bool m_isFrozen = false;
    float m_volume, m_pan;
    EffectChain m_effects;
    std::vector<AuxSend> m_auxSends;
    uint32_t m_outputBusId = 0xFFFFFFFF;
    bool m_outputToMaster = true;
    std::vector<std::shared_ptr<AudioRegion>> m_audioRegions;
    std::vector<std::shared_ptr<MIDIRegion>> m_midiRegions;
    std::map<uint32_t, AutomationCurve> m_automationLanes;
    
    AudioBuffer m_scratchBuffer;
    AudioBuffer m_proxyBuffer;
    AudioBuffer m_cachedBuffer;
    AudioBuffer m_trackBufWrapper;
    MidiBuffer m_dummyMidi;
    
    std::vector<float> m_volBuffer, m_panBuffer;
    std::vector<float> m_overviewColumn;
    
    bool m_isSolo = false, m_isMuted = false, m_isSoloSafe = false;
    bool m_isCached = false, m_isPluginLoaded = true, m_isUnloaded = false;
    bool m_vintageMode = false;
    float m_inputGain = 1.0f;
    bool m_phaseInvertL = false, m_phaseInvertR = false, m_isMono = false;
    uint64_t m_silenceSamples = 0;
    std::string m_name;
};

}
