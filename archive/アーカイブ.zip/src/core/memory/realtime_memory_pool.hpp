#pragma once
#include <vector>
#include <atomic>
#include <cstdint>

namespace Aura::Core::Memory {

/**
 * @class RealtimeMemoryPool
 * @brief Lock-free Bump Allocator for Realtime Audio Processing.
 * 【新規・最強の骨組み】OSのヒープアロケータ（new/malloc）は内部でグローバルロックを持つため、
 * オーディオスレッドでプラグインが呼ぶとDAWがフリーズ（音切れ）します。
 * 各モジュールが安全に一時メモリを要求できるよう、DAW起動時に確保した巨大な塊（アリーナ）から
 * O(1)で瞬時にメモリを切り出し、ブロックごとに一括解放する、王道DAW必須の基盤インフラです。
 */
class RealtimeMemoryPool {
public:
    static RealtimeMemoryPool& getInstance() { static RealtimeMemoryPool i; return i; }

    void initialize(size_t poolSizeBytes = 1024 * 1024 * 256) { // 256MB pre-allocated
        m_arena.resize(poolSizeBytes);
        m_head.store(0, std::memory_order_relaxed);
    }

    /**
     * @brief リアルタイムスレッドからの超高速O(1)アロケーション
     */
    void* allocate(size_t sizeBytes) {
        // アトミック加算で安全かつ瞬時にメモリブロックをポインタで切り出す
        size_t current_head = m_head.fetch_add(sizeBytes, std::memory_order_relaxed);
        if (current_head + sizeBytes > m_arena.size()) {
            return nullptr; // Out of memory (fallback to safety mechanism needed)
        }
        return &m_arena[current_head];
    }

    /**
     * @brief オーディオブロックごとの一括解放（高速Bump allocator）
     * 1回の関数呼び出しで、このブロックで使われたすべての中間メモリを初期化・再利用可能にする
     */
    void resetBlock() {
        m_head.store(0, std::memory_order_relaxed);
    }

private:
    RealtimeMemoryPool() = default;
    std::vector<uint8_t> m_arena;
    std::atomic<size_t> m_head{0};
};

} // namespace Aura::Core::Memory
