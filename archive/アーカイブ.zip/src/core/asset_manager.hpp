#pragma once

#include <string>
#include <vector>
#include <memory>
#include <map>
#include <mutex>

namespace Aura::Core {

/**
 * @brief AssetManager: Deduplicate sample data loading for multi-voice instruments.
 * Addresses the "duplicate load risk" from the professional review.
 */
class AssetManager {
public:
    using SampleData = std::vector<float>;
    using SampleRef = std::shared_ptr<const SampleData>;

    /**
     * @brief Loads or retrieves cached sample data by file path.
     */
    SampleRef loadSample(const std::string& path) {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        auto it = m_cache.find(path);
        if (it != m_cache.end()) {
            // Already cached, return shared reference
            return it->second;
        }

        // New asset, load and store
        auto newData = std::make_shared<SampleData>();
        // IO logic (WAV/FLAC Decoder) would populate newData here
        m_cache[path] = newData;
        return newData;
    }

    void clearUnused() {
        std::lock_guard<std::mutex> lock(m_mutex);
        for (auto it = m_cache.begin(); it != m_cache.end(); ) {
            if (it->second.use_count() <= 1) it = m_cache.erase(it);
            else ++it;
        }
    }

private:
    std::map<std::string, SampleRef> m_cache;
    std::mutex m_mutex;
};

} // namespace Aura::Core
