#pragma once

#include <atomic>
#include <algorithm>

namespace Aura::Core {

/**
 * @brief AtomicParameter: Thread-safe, lock-free parameter with smoothing.
 * Professional bridge between UI/MIDI threads and the Audio thread.
 */
class AtomicParameter {
public:
    explicit AtomicParameter(float initialValue = 1.0f) 
        : m_target(initialValue), m_current(initialValue) {}

    void setSampleRate(double sr) { m_sampleRate = sr; updateCoeff(); }
    void setSmoothingTime(double ms) { m_smoothingTimeMs = ms; updateCoeff(); }

    void setTarget(float value) { m_target.store(value, std::memory_order_release); }
    float getTarget() const { return m_target.load(std::memory_order_acquire); }

    /**
     * @brief Gets the smoothed value for the current audio frame.
     */
    float getNextValue() {
        float target = m_target.load(std::memory_order_relaxed);
        m_current = m_current + (target - m_current) * m_coeff;
        return m_current;
    }

    void reset(float value) {
        m_target.store(value, std::memory_order_release);
        m_current = value;
    }

private:
    void updateCoeff() {
        if (m_sampleRate > 0) {
            double timeConstantSamples = (m_smoothingTimeMs * 0.001) * m_sampleRate;
            m_coeff = static_cast<float>(1.0 - std::exp(-1.0 / timeConstantSamples));
        }
    }

    std::atomic<float> m_target;
    float m_current;
    float m_coeff = 0.01f;
    double m_sampleRate = 44100.0;
    double m_smoothingTimeMs = 10.0;
};

} // namespace Aura::Core
