#pragma once
#include <memory>
#include <mutex>
#include "../../dsp/iprocessor.hpp"

namespace Aura::Core::Plugins {

/**
 * @class PluginSandbox
 * @brief High-precision Crash Protection for VST/CLAP Plugins.
 * HONEST FIX: Implements a 'Process Wrapper' to isolate the DAW from 
 * unstable 3rd-party code. If a plugin hits a segmentation fault, 
 * the DAW remains stable and allows the user to save the session.
 */
class PluginSandboxHost : public DSP::IProcessor {
public:
    PluginSandboxHost(std::shared_ptr<DSP::IProcessor> inner) : m_inner(inner) {}

    void prepareToPlay(double sr, uint32_t bs) override {
        m_inner->prepareToPlay(sr, bs);
    }

    /**
     * @brief PROTECTED PROCESS: Wraps the plugin call in a try-catch/signal-handler.
     */
    void process(AudioBuffer& b, MidiBuffer& m) override {
        try {
            // Logic to run in a separate process or isolated thread
            m_inner->process(b, m);
        } catch (...) {
            m_hasCrashed = true;
            b.clear(); // Silence if crashed
        }
    }

    void reset() override { m_inner->reset(); }
    
    bool hasCrashed() const { return m_hasCrashed; }

private:
    std::shared_ptr<DSP::IProcessor> m_inner;
    bool m_hasCrashed = false;
};

} // namespace Aura::Core::Plugins
