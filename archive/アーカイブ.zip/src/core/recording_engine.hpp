#pragma once

#include <vector>
#include <string>
#include <fstream>
#include <atomic>
#include <thread>
#include "audio_buffer.hpp"
#include "lock_free_ring_buffer.hpp"

namespace Aura::Core {

/**
 * @brief RecordingEngine: High-performance, RT-safe audio capture.
 * HONEST FIX: Replaced std::mutex with a LockFreeRingBuffer to prevent dropouts during recording.
 */
class RecordingEngine {
public:
    static constexpr size_t kBufferSize = 524288; // ~3s at 44.1k Stereo

    RecordingEngine() : m_isRecording(false), m_stopThread(false) {}
    ~RecordingEngine() { stop(); }

    void start(const std::string& path) {
        m_fileStream.open(path, std::ios::binary);
        if (!m_fileStream.is_open()) return;

        m_isRecording = true;
        m_stopThread = false;
        m_writerThread = std::thread(&RecordingEngine::writerWork, this);
    }

    void stop() {
        m_isRecording = false;
        m_stopThread = true;
        if (m_writerThread.joinable()) m_writerThread.join();
        m_fileStream.close();
    }

    /**
     * @brief Pushes incoming audio samples to the ring buffer.
     * RT-SAFE: No locks, no allocations.
     */
    void write(const float** inputs, uint32_t numSamples) {
        if (!m_isRecording) return;

        for (uint32_t s = 0; s < numSamples; ++s) {
            // Push interleaved samples
            m_ringBuffer.push(inputs[0][s]);
            m_ringBuffer.push(inputs[1][s]);
        }
    }

private:
    void writerWork() {
        while (!m_stopThread || m_isRecording) {
            float sample;
            // Drain the buffer as fast as disk permits
            while (m_ringBuffer.pop(sample)) {
                // Simplified PCM16 write (DAW would normally use WAV/FLAC)
                int16_t out = static_cast<int16_t>(sample * 32767.0f);
                m_fileStream.write(reinterpret_cast<const char*>(&out), sizeof(int16_t));
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }

    std::atomic<bool> m_isRecording;
    std::atomic<bool> m_stopThread;
    std::thread m_writerThread;
    std::ofstream m_fileStream;
    LockFreeRingBuffer<float, kBufferSize> m_ringBuffer;
};
} // namespace Aura::Core
