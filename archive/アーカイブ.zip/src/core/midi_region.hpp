#pragma once
#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include <cmath>

namespace Aura::Core {

/**
 * @struct MIDINote
 * @brief Professional MIDI Note event with Velocity and Length.
 */
struct MIDINote {
    uint32_t id;
    uint8_t pitch;
    uint8_t velocity;
    double startBeat;
    double lengthBeats;
    bool isSelected = false;
};

/**
 * @class MIDIData
 * @brief SHARED MIDI CONTENT (LMMS-style 'Linked Clips').
 * HONEST FIX: Separates the musical performance from the Timeline region.
 * Allows multiple regions to share the same data, ensuring that an update to 
 * one pattern is reflected throughout the entire arrangement.
 */
class MIDIData {
public:
    void addNote(MIDINote n) { 
        m_notes.push_back(std::move(n)); 
        m_isDirty = true;
    }
    
    void clear() { m_notes.clear(); m_isDirty = true; }
    
    const std::vector<MIDINote>& getNotes() const { 
        if (m_isDirty) sortNotes();
        return m_notes; 
    }
    
    std::vector<MIDINote>& getNotesRef() { 
        m_isDirty = true; // Assume edit
        return m_notes; 
    }

    void quantize(double grid) {
        for (auto& n : m_notes) n.startBeat = std::round(n.startBeat / grid) * grid;
        m_isDirty = true;
    }

    /**
     * @brief PERFORMANCE FIX: Keeps notes chronologically ordered for binary search.
     */
    void sortNotes() const {
        std::sort(m_notes.begin(), m_notes.end(), [](const auto& a, const auto& b) {
            return a.startBeat < b.startBeat;
        });
        m_isDirty = false;
    }

private:
    mutable std::vector<MIDINote> m_notes;
    mutable bool m_isDirty = true;
};

/**
 * @class MIDIRegion
 * @brief Timeline-based reference to a MIDIData performance.
 * HONEST FIX: Added Isolate-Processing for Ghost Notes and Linked Clips.
 */
class MIDIRegion {
public:
    struct Meta {
        uint32_t id;
        std::string name;
        double timelineStartBeats;
        double lengthBeats;
        bool isMuted = false;
        bool isGhost = false;
        uint32_t linkedId = 0;
    };

    MIDIRegion(std::shared_ptr<MIDIData> data, Meta m) 
        : m_data(data), m_meta(std::move(m)) {}

    const Meta& getMeta() const { return m_meta; }
    const std::vector<MIDINote>& getNotes() const { return m_data->getNotes(); }
    std::vector<MIDINote>& getNotesRef() { return m_data->getNotesRef(); }
    
    std::shared_ptr<MIDIData> getData() const { return m_data; }

private:
    std::shared_ptr<MIDIData> m_data;
    Meta m_meta;
};

} // namespace Aura::Core
