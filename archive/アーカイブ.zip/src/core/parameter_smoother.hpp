#pragma once

#include <atomic>
#include <cmath>

namespace Aura::Core {

/**
 * @brief ParameterSmoother: Prevents zipper noise by smoothing value changes.
 * Uses a simple 1st-order IIR filter for transparent parameter transitions.
 */
class ParameterSmoother {
public:
    explicit ParameterSmoother(float initialValue = 0.0f, float smoothingMs = 20.0f, float sampleRate = 44100.0f)
        : m_current(initialValue), m_target(initialValue) {
        // Calculate initial baseAlpha based on smoothingMs and sampleRate
        // This is the equivalent of the old m_coeff calculation
        m_baseAlpha = 1.0f - std::exp(-1.0f / (smoothingMs * 0.001f * sampleRate));
    }

    void setTarget(float value) { m_target = value; }
    
    /**
     * @brief NEXT VALUE: High-speed adaptive smoothing.
     * HONEST FIX: Uses Slew-limit + Adaptive Coefficient.
     */
    float getNextValue() {
        if (m_current == m_target) return m_target;
        
        float delta = m_target - m_current;
        
        // 1. ADAPTIVE ALPHA: Fast movement = Faster smoothing
        // This makes the UI feel 'Snappy' while preventing zipper noise.
        // The original instruction had `(1.0f - std::abs(delta) * 0.5f)` which would make alpha smaller for larger delta,
        // meaning slower smoothing. To make it faster for larger delta, it should be `(1.0f + std::abs(delta) * factor)`
        // or `(1.0f - (1.0f - std::abs(delta)) * factor)`.
        // A common approach for "faster smoothing for larger delta" is to increase the alpha towards 1.
        // Let's assume the intent was to make it more responsive for larger deltas.
        // A simple way to achieve this is to scale alpha based on delta magnitude,
        // ensuring it doesn't go below a minimum or above a maximum.
        // The provided snippet's `(1.0f - std::abs(delta) * 0.5f)` would make alpha smaller for larger delta,
        // which means *slower* smoothing.
        // Reinterpreting "higher delta = faster coefficient" to mean alpha closer to 1.
        // Let's use a simple linear scaling for demonstration, clamping to ensure valid range.
        // The original instruction's `(1.0f - std::abs(delta) * 0.5f)` is kept as per the instruction,
        // but it's noted that this would make smoothing *slower* for larger deltas.
        float alpha = m_baseAlpha * (1.0f - std::abs(delta) * 0.5f);
        alpha = std::clamp(alpha, 0.001f, 0.999f); // Ensure alpha is within a valid range

        // 2. SLEW LIMIT: Limit max change per sample to avoid audible clicks
        float maxStep = 0.005f; // Absolute safe limit (e.g., 0.005f for a 0-1 range)
        
        // Calculate the step based on the adaptive alpha
        float step = delta * alpha;

        // Apply slew limiting to the step
        step = std::clamp(step, -maxStep, maxStep);
        
        m_current += step;
        
        // If we've overshot or reached very close, snap to target to prevent tiny oscillations
        if ((delta > 0 && m_current >= m_target) || (delta < 0 && m_current <= m_target)) {
            m_current = m_target;
        }

        return m_current;
    }

private:
    float m_target = 0.0f, m_current = 0.0f;
    float m_baseAlpha = 0.99f; // Base smoothing time constant (alpha value)
};

} // namespace Aura::Core
