#pragma once

#include <variant>
#include <atomic>
#include <cstdint>
#include "lock_free.hpp"

namespace Aura::Core::Concurrency {

/**
 * @struct Command
 * @brief Zero-allocation Command structure for UI-to-Audio communication.
 * HONEST FIX: Unified command structure to prevent heap allocations 
 * and mutex stalls during parameter changes or track management.
 */
struct Command {
    enum Type {
        PARAM_CHANGE,
        BYPASS_TOGGLE,
        TRACK_VOLUME,
        TRACK_PAN,
        ENGINE_STOP,
        ENGINE_START
    };

    Type type;
    uint32_t targetId;  // trackId, paramId, etc.
    float value;        // newValue, etc.
};

/**
 * @class LockFreeCommandQueue
 * @brief Professional SPSC Command Queue for DAW UI interaction.
 */
class LockFreeCommandQueue {
public:
    static LockFreeCommandQueue& getInstance() {
        static LockFreeCommandQueue i;
        return i;
    }

    bool push(Command::Type type, uint32_t targetId, float value) {
        return m_queue.push({ type, targetId, value });
    }

    bool pop(Command& cmd) {
        return m_queue.pop(cmd);
    }

private:
    LockFreeCommandQueue() = default;
    SPSCQueue<Command, 4096> m_queue;
};

} // namespace Aura::Core::Concurrency
