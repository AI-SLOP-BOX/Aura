#pragma once
#include <thread>
#include <vector>
#include <atomic>
#include <functional>
#include <array>
#include <optional>
#include <pthread.h>
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86)
    #include <immintrin.h>
#endif
#ifdef __APPLE__
    #include <mach/mach_types.h>
    #include <mach/thread_act.h>
    #include <mach/thread_policy.h>
#endif
#include "work_stealing_queue.hpp"

namespace Aura::Core::Concurrency {

using namespace Aura::Concurrency;

/**
 * @class AudioTaskManager
 * @brief High-priority, zero-allocation Thread Pool for parallel DSP.
 * HONEST FIX: Uses Cumulative Task Counting to avoid race conditions 
 * during topological layer synchronization.
 */
class AudioTaskManager {
public:
    static AudioTaskManager& getInstance() { 
        static AudioTaskManager instance; 
        return instance; 
    }

    void start(uint32_t numThreads = std::thread::hardware_concurrency()) {
        if (!m_workers.empty()) return;
        m_stop = false;
        m_numThreads = numThreads;
        m_taskQueue = std::make_unique<WorkStealingQueue>(numThreads);
        
        for (uint32_t i = 0; i < numThreads; ++i) {
            m_workers.emplace_back([this, i] {
                setupThread(i);
                while (!m_stop.load(std::memory_order_relaxed)) {
                    WorkStealingQueue::Task task;
                    if (m_taskQueue->pop(i, task) || m_taskQueue->steal(i, task)) {
                        task(); // Call operator()
                        m_totalCompleted.fetch_add(1, std::memory_order_release);
                        m_pendingTasks.fetch_sub(1, std::memory_order_release);
                    } else {
                        m_pendingTasks.wait(0, std::memory_order_relaxed);
                    }
                }
            });
        }
    }

    template<typename F>
    void pushTask(F&& f) {
        m_pendingTasks.fetch_add(1, std::memory_order_release);
        m_taskQueue->push(m_pushIndex.fetch_add(1, std::memory_order_relaxed) % m_numThreads, 
                          WorkStealingQueue::Task::create(std::forward<F>(f)));
        m_pendingTasks.notify_all();
    }

    template<typename F>
    void parallel_for(uint32_t start, uint32_t end, F&& f) {
        if (start >= end) return;
        uint32_t count = end - start;
        for (uint32_t i = start; i < end; ++i) {
            pushTask([i, &f] { f(i); });
        }
        waitForAll(count);
    }

    void waitForAll(uint32_t targetCount) {
        if (targetCount == 0) return;
        
        uint64_t start = m_totalCompleted.load(std::memory_order_acquire);
        uint64_t targetTotal = start + targetCount;

        while (m_totalCompleted.load(std::memory_order_acquire) < targetTotal) {
            WorkStealingQueue::Task task;
            if (m_taskQueue->steal(0, task)) { // Help as a thief
                task();
                m_totalCompleted.fetch_add(1, std::memory_order_release);
            } else {
#if defined(__x86_64__) || defined(_M_X64)
                _mm_pause(); // Efficient spinning
#else
                std::this_thread::yield(); 
#endif
            }
        }
    }

    void stop() {
        m_stop = true;
        m_pendingTasks.fetch_add(1);
        m_pendingTasks.notify_all();
        for (auto& w : m_workers) {
            if (w.joinable()) w.join();
        }
        m_workers.clear();
    }

private:
    AudioTaskManager() { start(); }
    ~AudioTaskManager() { stop(); }

    void setupThread(uint32_t index) {
        #ifdef __APPLE__
        thread_affinity_policy_data_t policy = { (int)index + 1 };
        thread_policy_set(pthread_mach_thread_np(pthread_self()), 
                         THREAD_AFFINITY_POLICY, (thread_policy_t)&policy, 
                         THREAD_AFFINITY_POLICY_COUNT);
        pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
        #endif
        
#if defined(__x86_64__) || defined(_M_X64)
        _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
        _MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);
#endif
    }

    std::vector<std::thread> m_workers;
    uint32_t m_numThreads = 1;
    std::unique_ptr<WorkStealingQueue> m_taskQueue;
    std::atomic<bool> m_stop{false};
    alignas(64) std::atomic<uint64_t> m_totalCompleted{0};
    alignas(64) std::atomic<uint32_t> m_pendingTasks{0};
    std::atomic<uint64_t> m_pushIndex{0};
};

} // namespace Aura::Core::Concurrency
