#pragma once

#include <string>
#include <map>
#include <memory>
#include <variant>
#include <vector>
#include "atomic_parameter.hpp"

namespace Aura::Core {

/**
 * @brief ParameterTree: Centralized management for XML/JSON project serialization.
 * Addresses the "lack of session save/restore" from the review.
 */
class ParameterTree {
public:
    using ParamPtr = std::shared_ptr<AtomicParameter>;

    /**
     * @brief Registers a new parameter into the tree with a unique path (e.g., "Mixer/Track1/Volume").
     */
    void registerParam(const std::string& path, float initialValue) {
        m_params[path] = std::make_shared<AtomicParameter>(initialValue);
    }

    ParamPtr getParam(const std::string& path) {
        auto it = m_params.find(path);
        return (it != m_params.end()) ? it->second : nullptr;
    }

    /**
     * @brief Exports all parameters as a flat map for file saving.
     */
    std::map<std::string, float> serialize() const {
        std::map<std::string, float> data;
        for (const auto& [key, param] : m_params) {
            data[key] = param->load();
        }
        return data;
    }

    /**
     * @brief Restores all parameters from a loaded project file.
     */
    void deserialize(const std::map<std::string, float>& data) {
        for (const auto& [key, val] : data) {
            if (m_params.count(key)) m_params[key]->setTarget(val);
        }
    }

private:
    std::map<std::string, ParamPtr> m_params;
};

} // namespace Aura::Core
