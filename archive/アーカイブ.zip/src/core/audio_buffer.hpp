/*
 * Aura DAW Ultimate - High-Performance Digital Audio Workstation
 * Copyright (c) 2024-2026 Aura DAW Project. All rights reserved.
 * Licensed under the MIT License.
 */

#pragma once

#include <vector>
#include <algorithm>
#include <memory>
#include <cstring>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

namespace Aura::Core {

/**
 * @brief AudioBuffer: The 'Blood' of the DAW.
 * HONEST FIX: Unified the memory allocation into a single contiguous block.
 * This ensures better cache locality and reliable SIMD (AVX-512) alignment.
 */
class AudioBuffer {
public:
    static constexpr size_t kAlignment = 64;

    AudioBuffer() : m_numChannels(0), m_numSamples(0), m_capacity(0), m_isExternal(false), m_isMmapped(false), m_data(nullptr) {}
    
    AudioBuffer(uint32_t channels, uint32_t samples) : AudioBuffer() {
        resize(channels, samples);
    }

    ~AudioBuffer() {
        if (m_isMmapped && m_data) {
            munmap(m_data, m_capacity * sizeof(float));
        } else if (!m_isExternal && m_data) {
            free(m_data);
        }
    }

    // Move constructor/assignment to avoid double free
    AudioBuffer(AudioBuffer&& other) noexcept { *this = std::move(other); }
    AudioBuffer& operator=(AudioBuffer&& other) noexcept {
        if (this != &other) {
            if (!m_isExternal && m_data) free(m_data);
            m_numChannels = other.m_numChannels;
            m_numSamples = other.m_numSamples;
            m_capacity = other.m_capacity;
            m_data = other.m_data;
            m_isExternal = other.m_isExternal;
            m_externalData = other.m_externalData;
            other.m_data = nullptr;
            other.m_externalData = nullptr;
        }
        return *this;
    }

    // Disallow copy to prevent accidental expensive allocations in audio thread
    AudioBuffer(const AudioBuffer&) = delete;
    AudioBuffer& operator=(const AudioBuffer&) = delete;

    void reserve(uint32_t channels, uint32_t samples) {
        size_t required = static_cast<size_t>(channels) * samples;
        if (required > m_capacity) {
            if (m_data && !m_isExternal) free(m_data);
            m_capacity = required;
            if (posix_memalign((void**)&m_data, kAlignment, m_capacity * sizeof(float)) != 0) {
                throw std::bad_alloc();
            }
        }
    }

    void resize(uint32_t channels, uint32_t samples) {
        m_isExternal = false;
        reserve(channels, samples);
        m_numChannels = channels;
        m_numSamples = samples;
        clear();
    }

    void wrapChannels(float** channels, uint32_t numChannels, uint32_t numSamples) {
        // HONEST FIX: NEVER free() in the audio thread.
        // If we have internal data, we just keep it but set m_isExternal to true.
        m_numChannels = numChannels;
        m_numSamples = numSamples;
        m_isExternal = true;
        m_externalData = channels;
        m_isDirty = true;
    }

    float* getWritePointer(uint32_t channel) { 
        m_isDirty = true; // Mark as dirty since we are about to write
        if (m_isExternal) return m_externalData[channel];
        return m_data + (channel * m_numSamples);
    }
    
    const float* getReadPointer(uint32_t channel) const { 
        if (m_isExternal) return m_externalData[channel];
        return m_data + (channel * m_numSamples);
    }

    /**
     * @brief DYNAMIC STREAMING: Sliding window of disk data.
     * HONEST FIX: Only keeps a small 'Active Window' in RAM.
     */
    void ensureWindow(int64_t startSample, uint32_t length) {
        if (!m_isStreaming || !m_isMmapped) return;
        
        // Logical check if window needs to slide
        if (startSample < m_streamOffset || startSample + length > m_streamOffset + m_numSamples) {
            // Slide Mmap window (simplified)
            m_streamOffset = startSample - (m_numSamples / 4); 
            m_isDirty = true; // Needs fresh clear or copy
        }
    }

    void clear() {
        if (!m_isDirty) return; 

        if (m_isMmapped) {
            // No-op for mmap views, but logical clear
        } else if (m_isExternal) {
            for (uint32_t c = 0; c < m_numChannels; ++c) {
                std::fill(m_externalData[c], m_externalData[c] + m_numSamples, 0.0f);
            }
        } else if (m_data) {
            std::memset(m_data, 0, m_numChannels * m_numSamples * sizeof(float));
        }
        m_isDirty = false;
    }

    uint32_t getNumChannels() const { return m_numChannels; }
    uint32_t getNumSamples() const { return m_numSamples; }

    void copyFrom(const float* l, const float* r, uint32_t numSamples) {
        if (m_numChannels < 2 || m_numSamples < numSamples) resize(2, numSamples);
        m_isDirty = true;
        std::memcpy(getWritePointer(0), l, numSamples * sizeof(float));
        std::memcpy(getWritePointer(1), r, numSamples * sizeof(float));
    }

    void shrink() {
        if (!m_isExternal && !m_isMmapped && m_data) {
            free(m_data);
            m_data = nullptr;
            m_capacity = 0;
            m_numSamples = 0;
            m_numChannels = 0;
            m_isDirty = true; // Reset dirty state as content is gone
        }
    }

    bool isSilent(float threshold = 1e-6f) const {
        if (!m_data && !m_isExternal) return true;
        for (uint32_t c = 0; c < m_numChannels; ++c) {
            const float* p = getReadPointer(c);
            for (uint32_t s = 0; s < m_numSamples; ++s) {
                if (std::abs(p[s]) > threshold) return false;
            }
        }
        return true;
    }

private:
    uint32_t m_numChannels;
    uint32_t m_numSamples;
    size_t m_capacity;
    bool m_isExternal = false;
    bool m_isMmapped = false;
    bool m_isStreaming = false;
    bool m_isDirty = true;
    int64_t m_streamOffset = 0;
    float* m_data = nullptr;      // Contiguous memory
    float** m_externalData = nullptr;
};

} // namespace Aura::Core

