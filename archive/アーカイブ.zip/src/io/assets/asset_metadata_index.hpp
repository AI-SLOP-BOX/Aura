#pragma once

#include <string>
#include <vector>
#include <map>
#include <algorithm>

namespace Aura::IO::Assets {

/**
 * @brief AssetMetadata: Fast metadata for DAW assets (samples, presets).
 * Essential for LMMS-style sample browsers.
 */
struct AssetMetadata {
    std::string name;
    std::string tags;
    double bpm;
    std::string key;
};

/**
 * @brief AssetMetadataIndex: High-performance indexing and search for production assets.
 */
class AssetMetadataIndex {
public:
    static AssetMetadataIndex& getInstance() {
        static AssetMetadataIndex instance;
        return instance;
    }

    /**
     * @brief Adds a new sample or preset metadata to the library.
     */
    void registerAsset(const std::string& path, const std::string& tags, double bpm = 0.0) {
        m_index[path] = {path, tags, bpm, ""};
    }

    /**
     * @brief Searches for assets based on partial tag matches.
     */
    std::vector<std::string> search(const std::string& query) {
        std::vector<std::string> results;
        for (const auto& [path, meta] : m_index) {
            if (meta.tags.find(query) != std::string::npos || path.find(query) != std::string::npos) {
                results.push_back(path);
            }
        }
        return results;
    }

private:
    AssetMetadataIndex() = default;

    // Path -> Metadata
    std::map<std::string, AssetMetadata> m_index;
};

} // namespace Aura::IO::Assets
