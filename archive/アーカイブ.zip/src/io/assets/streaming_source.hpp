#pragma once

#include <vector>
#include <atomic>
#include <fstream>
#include <mutex>

namespace Aura::Core::Assets {

/**
 * @brief StreamingSource: A sample-accurate bridge between Disk and the Audio Thread.
 * Uses a double-buffering (ping-pong) mechanism to ensure zero-wait reads.
 */
class StreamingSource {
public:
    static constexpr size_t kBufferSize = 65536; // 64k buffer

    StreamingSource(const std::string& filePath) : m_filePath(filePath) {
        m_file.open(filePath, std::ios::binary);
        m_buffers[0].resize(kBufferSize);
        m_buffers[1].resize(kBufferSize);
        
        // Initial load
        refill();
    }

    /**
     * @brief Checks if the background buffer needs refilling from disk.
     */
    bool needsRefill() const {
        return m_needsRefill.load(std::memory_order_acquire);
    }

    /**
     * @brief Performed by the IO Worker thread. Reads the next block into the inactive buffer.
     */
    void refill() {
        if (!m_file.is_open()) return;

        size_t inactiveIdx = 1 - m_activeIdx.load();
        m_file.read(reinterpret_cast<char*>(m_buffers[inactiveIdx].data()), kBufferSize * sizeof(float));
        
        m_needsRefill.store(false, std::memory_order_release);
    }

    /**
     * @brief Consumed by the Audio Thread.
     */
    float getNextSample() {
        size_t activeIdx = m_activeIdx.load(std::memory_order_acquire);
        float sample = m_buffers[activeIdx][m_readPos];

        m_readPos++;
        if (m_readPos >= kBufferSize) {
            // Swap buffers
            m_activeIdx.store(1 - activeIdx, std::memory_order_release);
            m_readPos = 0;
            m_needsRefill.store(true, std::memory_order_release);
        }

        return sample;
    }

private:
    std::string m_filePath;
    std::ifstream m_file;
    
    std::vector<float> m_buffers[2];
    std::atomic<size_t> m_activeIdx{0};
    uint64_t m_readPos = 0;
    
    std::atomic<bool> m_needsRefill{false};
};

} // namespace Aura::Core::Assets
