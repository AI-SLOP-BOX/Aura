#pragma once

#include <string>
#include <vector>
#include <filesystem>
#include <map>
#include <mutex>
#include "../../core/utils/string_hash.hpp"

namespace Aura::IO::Assets {

using namespace Utils;

/**
 * @brief AssetResolver: Heuristic file locator for missing project assets.
 * Resolves "link broken" issues by scanning project folders and fallback directories.
 */
class AssetResolver {
public:
    static AssetResolver& getInstance() {
        static AssetResolver instance;
        return instance;
    }

    void addSearchPath(const std::string& path) {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_searchPaths.push_back(path);
    }

    /**
     * @brief Attempts to find a missing file by its Original Path or Name.
     */
    std::string resolve(const std::string& originalPath) {
        if (std::filesystem::exists(originalPath)) return originalPath;

        std::lock_guard<std::mutex> lock(m_mutex);
        std::string fileName = std::filesystem::path(originalPath).filename().string();
        
        // 1. SEARCH REGISTERED PATHS: Heuristic approach
        for (const auto& searchPath : m_searchPaths) {
            std::filesystem::path potentialPath = std::filesystem::path(searchPath) / fileName;
            if (std::filesystem::exists(potentialPath)) {
                return potentialPath.string();
            }
        }
        
        return ""; // Not found
    }

private:
    AssetResolver() = default;
    
    std::vector<std::string> m_searchPaths;
    std::mutex m_mutex;
};

} // namespace Aura::IO::Assets
