#pragma once

#include <string>
#include <vector>
#include <fstream>
#include <iostream>

namespace Aura::IO::Persistence {

/**
 * @brief ProjectSerializer: Handles saving and loading the entire project state.
 * Uses a human-readable format (JSON-like) for Logic Pro compatibility and power-user edits.
 */
class ProjectSerializer {
public:
    ProjectSerializer() = default;

    /**
     * @brief Saves the project to the specified path.
     */
    bool saveProject(const std::string& path, const std::string& jsonData) {
        std::ofstream file(path);
        if (!file.is_open()) return false;

        file << jsonData;
        std::cout << "[Serializer] Project saved: " << path << std::endl;
        return true;
    }

    /**
     * @brief Loads project data from a file.
     */
    std::string loadProject(const std::string& path) {
        std::ifstream file(path);
        if (!file.is_open()) return "";

        std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        return content;
    }
};

} // namespace Aura::IO::Persistence
