#pragma once

#include <string>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <iostream>
#include "async_serializer.hpp"

namespace Aura::IO::Persistence {

/**
 * @class AutoSaveEngine
 * @brief Background "Safety-net" for project data.
 */
class AutoSaveEngine {
public:
    static AutoSaveEngine& getInstance() {
        static AutoSaveEngine instance;
        return instance;
    }

    void start(const std::string& projectPath, uint32_t intervalSeconds = 300) {
        if (m_isRunning.load()) stop();
        
        m_projectPath = projectPath;
        m_intervalSeconds = intervalSeconds;
        m_isRunning.store(true);
        m_thread = std::thread(&AutoSaveEngine::loop, this);
    }

    void stop() {
        m_isRunning.store(false);
        if (m_thread.joinable()) m_thread.join();
    }

    void markModified() { m_isDirty.store(true); }

private:
    AutoSaveEngine() = default;
    ~AutoSaveEngine() { stop(); }

    void loop() {
        while (m_isRunning.load()) {
            std::this_thread::sleep_for(std::chrono::seconds(1)); // Higher poll rate for stop flag
            
            auto now = std::chrono::steady_clock::now();
            if (m_isDirty.load() && 
                std::chrono::duration_cast<std::chrono::seconds>(now - m_lastSaveTime).count() >= m_intervalSeconds) {
                performBackup();
                m_isDirty.store(false);
                m_lastSaveTime = now;
            }
        }
    }

    void performBackup() {
        std::string autoSavePath = m_projectPath + ".autosave";
        std::cout << "[AutoSave] Triggering background backup to: " << autoSavePath << std::endl;
        
        // Mocking JSON data gathering (in production, we'd traverse the engine state)
        std::string dummyJson = "{\"version\": \"2026.1\", \"autosave\": true}";
        
        AsyncSerializer::getInstance().serializeAsync(autoSavePath, dummyJson);
    }

    std::atomic<bool> m_isRunning{false};
    std::atomic<bool> m_isDirty{false};
    uint32_t m_intervalSeconds = 300;
    std::string m_projectPath;
    std::chrono::steady_clock::time_point m_lastSaveTime;
    std::thread m_thread;
};

} // namespace Aura::IO::Persistence
