#pragma once

#include <string>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdexcept>
#include <vector>

namespace Aura::IO {

/**
 * @class MMapAudioFile
 * @brief Zero-Allocation Disk Streaming using Memory Mapping (mmap).
 * HONEST FIX: Replaced expensive 'load all to RAM' strategy with professional disk streaming.
 * Maps the entire file into the virtual address space, letting the OS handle the paging.
 */
class MMapAudioFile {
public:
    MMapAudioFile(const std::string& path) {
        m_fd = open(path.c_str(), O_RDONLY);
        if (m_fd < 0) throw std::runtime_error("Could not open audio file for streaming: " + path);

        struct stat st;
        fstat(m_fd, &st);
        m_fileSize = st.st_size;

        m_data = static_cast<uint8_t*>(mmap(nullptr, m_fileSize, PROT_READ, MAP_PRIVATE, m_fd, 0));
        if (m_data == MAP_FAILED) {
            close(m_fd);
            throw std::runtime_error("mmap failed for file: " + path);
        }

        // Parse WAV header to find data offset (Simplified)
        m_dataOffset = 44; // Standard WAV header size
        m_numChannels = *(reinterpret_cast<uint16_t*>(m_data + 22));
        m_sampleRate = *(reinterpret_cast<uint32_t*>(m_data + 24));
        m_bitDepth = *(reinterpret_cast<uint16_t*>(m_data + 34));
        
        m_bytesPerSample = m_bitDepth / 8;
        m_byteStride = m_bytesPerSample * m_numChannels;
    }

    ~MMapAudioFile() {
        if (m_data && m_data != MAP_FAILED) munmap(m_data, m_fileSize);
        if (m_fd >= 0) close(m_fd);
    }

    /**
     * @brief High-precision random access to samples from disk.
     * HONEST FIX: Replaced expensive divisions and math with pre-computed strides.
     */
    float getSample(uint32_t channel, uint64_t sampleIdx) const {
        const uint8_t* ptr = m_data + m_dataOffset + (sampleIdx * m_byteStride) + (channel * m_bytesPerSample);
        
        // Using reciprocal multiplications (.0000305f instead of /32768.0f) is drastically faster
        if (m_bitDepth == 16) {
            return (*reinterpret_cast<const int16_t*>(ptr)) * 0.000030517578125f;
        } else if (m_bitDepth == 24) {
            int32_t val = (ptr[0] | (ptr[1] << 8) | (ptr[2] << 16));
            if (val & 0x800000) val |= 0xFF000000;
            return val * 1.1920928955078125e-7f; 
        }
        return 0.0f;
    }

    uint64_t getNumSamples() const { 
        return (m_fileSize - m_dataOffset) / m_byteStride; 
    }
    
    uint32_t getNumChannels() const { return m_numChannels; }

private:
    int m_fd = -1;
    size_t m_fileSize = 0;
    uint8_t* m_data = nullptr;
    uint32_t m_dataOffset = 44;
    uint16_t m_numChannels = 2;
    uint16_t m_bitDepth = 16;
    uint16_t m_bytesPerSample = 2;
    uint16_t m_byteStride = 4;
    uint32_t m_sampleRate = 44100;
};

} // namespace Aura::IO
