/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                aura: {
                    amber: '#f59e0b',
                    nuclear: '#84cc16',
                    deepsea: '#0ea5e9',
                    innocent: '#f8fafc',
                    ebony: '#050505',
                    carbon: '#121212',
                    graphite: '#1a1a1a',
                }
            },
            fontFamily: {
                mono: ['JetBrains Mono', 'Menlo', 'monospace'],
                sans: ['Inter', 'system-ui', 'sans-serif'],
            },
            animation: {
                'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
            }
        },
    },
    plugins: [],
}
