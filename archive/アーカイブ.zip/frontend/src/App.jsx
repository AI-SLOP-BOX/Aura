import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Layers, Share2, ChevronRight, Music, Mic2, Speaker,
    Activity, Sliders, Eye, Lock, Settings2, MoreHorizontal,
    ChevronDown, Play, Volume2, Piano, Waves, Zap,
    Search, FolderOpen, Box, Cpu, HardDrive, Filter,
    Maximize2, Minimize2, Plus, Power, Radio, Disc,
    Circle, Square, Triangle, Repeat, SkipBack, SkipForward,
    FastForward, MousePointer2, Hand, Scissors, Type,
    Clock, Menu, Bell, User, LayoutGrid, Terminal,
    Hash, Activity as SpectrumIcon, HelpCircle,
    GripVertical, Edit3, X, MousePointer, Move
} from 'lucide-react';

// --- DESIGN TOKENS ---
const THEMES = {
    amber: { name: 'Aura Amber', primary: '#f59e0b', secondary: '#78350f', glow: 'rgba(245, 158, 11, 0.4)' },
    nuclear: { name: 'Nuclear Lime', primary: '#84cc16', secondary: '#365314', glow: 'rgba(132, 204, 22, 0.4)' },
    deepsea: { name: 'Deep Sea Blue', primary: '#0ea5e9', secondary: '#0c4a6e', glow: 'rgba(14, 165, 233, 0.4)' },
    innocent: { name: 'Innocent White', primary: '#f8fafc', secondary: '#334155', glow: 'rgba(248, 250, 252, 0.4)' }
};

// --- CORE AUDIO LOGIC ---
class AudioEngine {
    constructor() {
        this.ctx = null;
        this.nodes = new Map();
    }

    init() {
        if (!this.ctx) {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        }
    }

    play(trackData) {
        this.init();
        this.stop();
        if (this.ctx.state === 'suspended') this.ctx.resume();

        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        const synthNode = trackData.nodes.find(n => n.type === 'source');
        const filterNode = trackData.nodes.find(n => n.type === 'process');

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(synthNode ? (synthNode.params.Freq * 2 + 40) : 440, this.ctx.currentTime);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(filterNode ? (filterNode.params.Cutoff * 50) : 1000, this.ctx.currentTime);

        gain.gain.setValueAtTime(0.1, this.ctx.currentTime);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start();
        this.nodes.set('active', { osc, filter, gain });
    }

    stop() {
        const active = this.nodes.get('active');
        if (active) {
            active.osc.stop();
            this.nodes.delete('active');
        }
    }
}

const audioEngine = new AudioEngine();

// --- COMPONENTS ---

const GlassPanel = ({ children, className = "", style = {} }) => (
    <div
        className={`glass-panel rounded-lg overflow-hidden ${className}`}
        style={style}
    >
        {children}
    </div>
);

const Visualizer = ({ isPlaying, color, type = 'wave' }) => {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();

        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);

        let animationId;
        let offset = 0;

        const render = () => {
            ctx.clearRect(0, 0, rect.width, rect.height);
            ctx.beginPath();
            ctx.strokeStyle = color;
            ctx.lineWidth = 1.5;
            ctx.lineJoin = 'round';

            const amplitude = isPlaying ? 15 : 1;
            const frequency = isPlaying ? 0.08 : 0.02;

            ctx.moveTo(0, rect.height / 2);
            for (let x = 0; x < rect.width; x++) {
                let y;
                if (type === 'wave') {
                    y = rect.height / 2 + Math.sin(x * frequency + offset) * amplitude;
                } else {
                    y = rect.height - (Math.random() * amplitude * 1.5 + 2);
                    if (x % 3 === 0) ctx.moveTo(x, rect.height);
                }
                ctx.lineTo(x, y);
            }
            ctx.stroke();
            offset += 0.15;
            animationId = requestAnimationFrame(render);
        };

        render();
        return () => cancelAnimationFrame(animationId);
    }, [isPlaying, color, type]);

    return <canvas ref={canvasRef} className="w-full h-full opacity-80" />;
};

const Knob = ({ label, value, color, onChange }) => {
    const [isDragging, setIsDragging] = useState(false);
    const startY = useRef(0);
    const startVal = useRef(0);

    const handleMouseDown = (e) => {
        e.stopPropagation();
        setIsDragging(true);
        startY.current = e.clientY;
        startVal.current = value;
        document.body.style.cursor = 'ns-resize';
    };

    useEffect(() => {
        const handleMouseMove = (e) => {
            if (!isDragging) return;
            const deltaY = startY.current - e.clientY;
            const newVal = Math.min(100, Math.max(0, startVal.current + deltaY * 0.5));
            onChange(newVal);
        };
        const handleMouseUp = () => {
            setIsDragging(false);
            document.body.style.cursor = 'default';
        };

        if (isDragging) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, onChange]);

    const rotation = -135 + (value / 100) * 270;

    return (
        <div className="flex flex-col items-center gap-2 group cursor-ns-resize" onMouseDown={handleMouseDown}>
            <div className="relative w-14 h-14">
                {/* Background Ring */}
                <svg className="w-full h-full -rotate-90">
                    <circle cx="28" cy="28" r="22" fill="transparent" stroke="#111" strokeWidth="4" />
                    <circle
                        cx="28" cy="28" r="22"
                        fill="transparent"
                        stroke={color}
                        strokeWidth="4"
                        strokeDasharray="138"
                        strokeDashoffset={138 - (value / 100) * 110}
                        className="transition-all duration-100 ease-out"
                        style={{ filter: `drop-shadow(0 0 8px ${color})`, opacity: 0.6 }}
                    />
                </svg>
                {/* Dial Cap */}
                <div
                    className="absolute inset-2 bg-gradient-to-br from-[#333] to-[#111] rounded-full border border-white/10 shadow-xl flex items-center justify-center knob-rotation"
                    style={{ transform: `rotate(${rotation}deg)` }}
                >
                    <div className="w-1 h-4 bg-white/80 rounded-full mb-4 shadow-[0_0_10px_white]"></div>
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.1),transparent_60%)]"></div>
                </div>
            </div>
            <div className="flex flex-col items-center">
                <span className="text-[9px] font-mono font-black text-white/40 uppercase tracking-widest group-hover:text-aura-amber transition-colors">{label}</span>
                <span className="text-[8px] font-mono text-white/20">{Math.round(value)}</span>
            </div>
        </div>
    );
};

const App = () => {
    // --- STATE ---
    const [view, setView] = useState('nodes');
    const [themeKey, setThemeKey] = useState('amber');
    const [selectedTrackId, setSelectedTrackId] = useState('synth');
    const [selectedNodeId, setSelectedNodeId] = useState('s1');
    const [isPlaying, setIsPlaying] = useState(false);
    const [isMixerOpen, setIsMixerOpen] = useState(true);
    const [currentTime, setCurrentTime] = useState(0);
    const [draggingNode, setDraggingNode] = useState(null);
    const [patchingFrom, setPatchingFrom] = useState(null); // {nodeId, x, y}
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

    const [tracks, setTracks] = useState([
        {
            id: 'synth', name: 'HYPER SAW LEAD', kind: 'MIDI', icon: <Piano size={14} />,
            nodes: [
                { id: 's1', label: 'Wavetable OSC', x: 80, y: 120, type: 'source', params: { Freq: 65, Gain: 80, Detune: 5 } },
                { id: 's2', label: 'Ladder Filter', x: 300, y: 120, type: 'process', params: { Cutoff: 45, Res: 30, Drive: 10 } },
                { id: 's3', label: 'Mod LFO', x: 300, y: 320, type: 'mod', params: { Rate: 40, Depth: 85, Shape: 0 } },
                { id: 's4', label: 'Ethereal Delay', x: 520, y: 120, type: 'effect', params: { FB: 40, Time: 25, Mix: 30 } },
                { id: 's5', label: 'Master Output', x: 740, y: 120, type: 'output', params: { Out: 100, Pan: 0 } },
            ],
            edges: [{ from: 's1', to: 's2' }, { from: 's3', to: 's2' }, { from: 's2', to: 's4' }, { from: 's4', to: 's5' }]
        },
        { id: 'bass', name: 'SUB ATTACK', kind: 'MIDI', icon: <Waves size={14} />, nodes: [], edges: [] }
    ]);

    const currentTheme = THEMES[themeKey];
    const selectedTrack = tracks.find(t => t.id === selectedTrackId);
    const selectedNode = selectedTrack?.nodes.find(n => n.id === selectedNodeId);

    // --- LOGIC ---
    const updateNodeParam = (nodeId, key, newVal) => {
        setTracks(prev => prev.map(t => t.id === selectedTrackId ? {
            ...t,
            nodes: t.nodes.map(n => n.id === nodeId ? { ...n, params: { ...n.params, [key]: newVal } } : n)
        } : t));
    };

    const handleMouseMove = useCallback((e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        setMousePos({ x, y });

        if (draggingNode) {
            setTracks(prev => prev.map(t => t.id === selectedTrackId ? {
                ...t,
                nodes: t.nodes.map(n => n.id === draggingNode ? {
                    ...n,
                    x: Math.max(0, Math.min(rect.width - 200, x - 100)),
                    y: Math.max(0, Math.min(rect.height - 100, y - 50))
                } : n)
            } : t));
        }
    }, [draggingNode, selectedTrackId]);

    const handleNodeMouseUp = (nodeId) => {
        if (patchingFrom && patchingFrom.nodeId !== nodeId) {
            setTracks(prev => prev.map(t => t.id === selectedTrackId ? {
                ...t,
                edges: [...t.edges.filter(e => !(e.from === patchingFrom.nodeId && e.to === nodeId)), { from: patchingFrom.nodeId, to: nodeId }]
            } : t));
        }
        setPatchingFrom(null);
    };

    const deleteEdge = (from, to) => {
        setTracks(prev => prev.map(t => t.id === selectedTrackId ? {
            ...t,
            edges: t.edges.filter(e => !(e.from === from && e.to === to))
        } : t));
    };

    useEffect(() => {
        if (isPlaying) {
            audioEngine.play(selectedTrack);
        } else {
            audioEngine.stop();
        }
    }, [isPlaying, selectedTrackId, selectedTrack]);

    return (
        <div className="flex flex-col h-screen bg-aura-ebony text-gray-400 font-sans overflow-hidden antialiased">

            {/* --- TOP BAR (GLASS) --- */}
            <header className="h-12 bg-aura-carbon border-b border-white/5 flex items-center px-4 justify-between z-[100] shadow-2xl relative">
                <div className="flex items-center gap-8">
                    <motion.div
                        whileHover={{ scale: 1.05 }}
                        className="flex items-center gap-3 cursor-pointer"
                        onClick={() => {
                            const keys = Object.keys(THEMES);
                            const nextIndex = (keys.indexOf(themeKey) + 1) % keys.length;
                            setThemeKey(keys[nextIndex]);
                        }}
                    >
                        <div className="p-1.5 rounded-lg bg-black shadow-inner border border-white/5">
                            <Zap size={16} fill={currentTheme.primary} style={{ color: currentTheme.primary }} className={isPlaying ? 'animate-neon' : 'opacity-40'} />
                        </div>
                        <div className="flex flex-col leading-none">
                            <span className="text-[12px] font-black tracking-tighter text-white uppercase italic">AURA DAW</span>
                            <span className="text-[8px] font-mono tracking-widest text-white/20 uppercase">Ultimate Master</span>
                        </div>
                    </motion.div>

                    <nav className="flex gap-6 text-[10px] font-black uppercase tracking-widest text-white/20">
                        {['File', 'Edit', 'Patch', 'Project', 'Engine'].map(m => (
                            <span key={m} className="hover:text-white cursor-pointer transition-all hover:translate-y-[-1px]">{m}</span>
                        ))}
                    </nav>
                </div>

                {/* TRANSPORT (FLOATING GLASS) */}
                <div className="absolute left-1/2 -translate-x-1/2 flex items-center bg-black/60 backdrop-blur-md border border-white/10 rounded-full px-2 py-1 gap-1 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
                    <button className="p-2 hover:text-white transition-colors"><SkipBack size={14} /></button>
                    <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => setIsPlaying(!isPlaying)}
                        className={`w-10 h-8 flex items-center justify-center rounded-full transition-all ${isPlaying ? 'bg-white text-black shadow-[0_0_20px_white]' : 'bg-[#222] hover:bg-[#333]'}`}
                        style={{ backgroundColor: isPlaying ? currentTheme.primary : '', color: isPlaying ? '#000' : '' }}
                    >
                        {isPlaying ? <Square size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
                    </motion.button>
                    <button className={`p-2 transition-colors ${isPlaying ? 'text-rose-500 animate-pulse' : 'text-gray-700'}`}><Circle size={10} fill="currentColor" /></button>

                    <div className="h-6 w-px bg-white/5 mx-2"></div>

                    <div className="flex flex-col items-center px-4">
                        <span className="text-[13px] font-mono font-black text-white tracking-widest" style={{ color: isPlaying ? currentTheme.primary : '' }}>
                            001 : 0{Math.floor(currentTime / 4) + 1} : 0{Math.floor(currentTime % 4) + 1}
                        </span>
                    </div>
                </div>

                <div className="flex items-center gap-6">
                    <div className="flex items-center gap-4 bg-black/40 px-4 py-1.5 rounded-full border border-white/5 shadow-inner">
                        <SpectrumIcon size={14} className={isPlaying ? 'animate-pulse text-aura-amber' : 'opacity-20'} style={{ color: isPlaying ? currentTheme.primary : '' }} />
                        <div className="h-1.5 w-16 bg-white/5 rounded-full overflow-hidden">
                            <motion.div
                                animate={{ width: isPlaying ? '60%' : '5%' }}
                                transition={{ type: 'spring', stiffness: 100 }}
                                className="h-full"
                                style={{ backgroundColor: currentTheme.primary }}
                            />
                        </div>
                    </div>
                    <Settings2 size={16} className="text-white/20 hover:text-white cursor-pointer rotate-0 hover:rotate-90 transition-all duration-500" />
                </div>
            </header>

            {/* --- VIEW SELECTOR --- */}
            <div className="h-10 bg-aura-graphite border-b border-black flex items-center px-4 gap-2">
                <div className="bg-black/40 p-1 rounded-lg border border-white/5 flex gap-1">
                    {['layers', 'nodes', 'piano-roll'].map(v => (
                        <button
                            key={v}
                            onClick={() => setView(v)}
                            className={`px-5 py-1 text-[9px] font-black tracking-[0.2em] transition-all uppercase rounded-md ${view === v ? 'bg-white/10 text-white shadow-lg' : 'text-gray-600 hover:text-gray-300'}`}
                            style={{ backgroundColor: view === v ? `${currentTheme.primary}22` : '', color: view === v ? currentTheme.primary : '' }}
                        >
                            {v.replace('-', ' ')}
                        </button>
                    ))}
                </div>
            </div>

            <main className="flex-1 flex overflow-hidden relative">

                {/* --- SIDE BROWSER (DARK) --- */}
                <aside className="w-60 bg-aura-ebony border-r border-black flex flex-col z-50">
                    <div className="p-4">
                        <div className="relative group">
                            <Search size={12} className="absolute left-3 top-2.5 text-white/20 group-focus-within:text-aura-amber" />
                            <input
                                type="text"
                                placeholder="SEARCH LIBRARY"
                                className="w-full bg-black/60 border border-white/5 rounded-lg px-9 py-2 text-[10px] font-bold outline-none ring-0 focus:ring-1 focus:ring-white/10 text-white transition-all uppercase tracking-widest"
                            />
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto px-2 space-y-6">
                        <section>
                            <span className="px-3 text-[9px] font-black text-white/10 uppercase tracking-[0.4em] mb-3 block">CORE ENGINE</span>
                            <div className="space-y-1">
                                {[
                                    { icon: <Box size={14} />, name: 'Generators', count: 24 },
                                    { icon: <Cpu size={14} />, name: 'FX Chains', count: 18 },
                                    { icon: <SpectrumIcon size={14} />, name: 'Analyzers', count: 6 },
                                    { icon: <Waves size={14} />, name: 'Warp Modules', count: 12 },
                                ].map((item, i) => (
                                    <motion.div
                                        whileHover={{ x: 4, backgroundColor: 'rgba(255,255,255,0.03)' }}
                                        key={i}
                                        className="flex items-center justify-between px-3 py-2.5 rounded-lg cursor-pointer group"
                                    >
                                        <div className="flex items-center gap-4 text-[11px] font-bold text-white/40 group-hover:text-white transition-colors">
                                            <span style={{ color: currentTheme.primary }} className="opacity-60 group-hover:opacity-100">{item.icon}</span>
                                            {item.name}
                                        </div>
                                        <span className="text-[8px] font-mono text-white/10">{item.count}</span>
                                    </motion.div>
                                ))}
                            </div>
                        </section>
                    </div>
                </aside>

                {/* --- MAIN NODES AREA --- */}
                <div className="flex-1 relative overflow-hidden bg-[#080808]" onMouseMove={handleMouseMove} onMouseUp={() => { setDraggingNode(null); setPatchingFrom(null); }}>
                    {/* GRID BACKGROUND */}
                    <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

                    {view === 'nodes' && (
                        <div className="w-full h-full relative" onMouseDown={() => setSelectedNodeId(null)}>
                            {/* SVG CONNECTOR LINES */}
                            <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
                                <AnimatePresence>
                                    {selectedTrack?.edges.map((edge, idx) => {
                                        const from = selectedTrack.nodes.find(n => n.id === edge.from);
                                        const to = selectedTrack.nodes.find(n => n.id === edge.to);
                                        if (!from || !to) return null;

                                        const x1 = from.x + 190; const y1 = from.y + 45;
                                        const x2 = to.x; const y2 = to.y + 45;
                                        const cp1x = x1 + Math.abs(x2 - x1) / 2.5;
                                        const cp2x = x2 - Math.abs(x2 - x1) / 2.5;

                                        return (
                                            <g key={`${edge.from}-${edge.to}`}>
                                                <motion.path
                                                    initial={{ pathLength: 0, opacity: 0 }}
                                                    animate={{ pathLength: 1, opacity: 1 }}
                                                    d={`M ${x1} ${y1} C ${cp1x} ${y1}, ${cp2x} ${y2}, ${x2} ${y2}`}
                                                    fill="none"
                                                    stroke={isPlaying ? currentTheme.primary : '#222'}
                                                    strokeWidth={isPlaying ? 1.5 : 1}
                                                    className="transition-all duration-300 cursor-pointer pointer-events-auto hover:stroke-white"
                                                    onClick={(e) => { e.stopPropagation(); deleteEdge(edge.from, edge.to); }}
                                                />
                                                {isPlaying && (
                                                    <circle r="2" fill="white" style={{ filter: `drop-shadow(0 0 5px ${currentTheme.primary})` }}>
                                                        <animateMotion dur="2s" repeatCount="indefinite" path={`M ${x1} ${y1} C ${cp1x} ${y1}, ${cp2x} ${y2}, ${x2} ${y2}`} />
                                                    </circle>
                                                )}
                                            </g>
                                        );
                                    })}
                                </AnimatePresence>

                                {/* DYNAMIC PATCHING LINE */}
                                {patchingFrom && (
                                    <path
                                        d={`M ${patchingFrom.x} ${patchingFrom.y} C ${patchingFrom.x + 100} ${patchingFrom.y}, ${mousePos.x - 100} ${mousePos.y}, ${mousePos.x} ${mousePos.y}`}
                                        fill="none"
                                        stroke={currentTheme.primary}
                                        strokeWidth="2"
                                        strokeDasharray="4 4"
                                    />
                                )}
                            </svg>

                            {/* DEVICE CARDS */}
                            {selectedTrack?.nodes.map((node) => (
                                <motion.div
                                    layoutId={node.id}
                                    key={node.id}
                                    onMouseDown={(e) => { e.stopPropagation(); setSelectedNodeId(node.id); setDraggingNode(node.id); }}
                                    onMouseUp={() => handleNodeMouseUp(node.id)}
                                    className={`absolute w-48 bg-[#181818]/60 backdrop-blur-xl rounded-xl border-2 shadow-[0_20px_50px_rgba(0,0,0,0.6)] cursor-grab active:cursor-grabbing overflow-hidden transition-all duration-300
                                        ${selectedNodeId === node.id ? 'z-50 border-white/20' : 'z-10 border-white/5 opacity-80'}
                                    `}
                                    style={{
                                        left: node.x,
                                        top: node.y,
                                        borderColor: selectedNodeId === node.id ? currentTheme.primary : '',
                                        boxShadow: selectedNodeId === node.id ? `0 0 40px ${currentTheme.primary}22` : ''
                                    }}
                                >
                                    {/* Header */}
                                    <div className="h-6 bg-black/40 flex items-center justify-between px-3 border-b border-white/5">
                                        <div className="flex gap-1.5">
                                            <div className="w-2 h-2 rounded-full bg-rose-500/20" />
                                            <div className="w-2 h-2 rounded-full bg-amber-500/20" />
                                        </div>
                                        <span className="text-[8px] font-black uppercase text-white/30 tracking-widest">{node.type}</span>
                                    </div>

                                    {/* Content */}
                                    <div className="p-4 space-y-3">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded bg-black/80" style={{ color: currentTheme.primary }}>
                                                {node.type === 'source' ? <Piano size={16} /> : node.type === 'process' ? <Filter size={16} /> : <Box size={16} />}
                                            </div>
                                            <div className="flex flex-col leading-none">
                                                <span className="text-[11px] font-black text-white uppercase tracking-tight">{node.label}</span>
                                                <span className="text-[7px] text-white/20 uppercase font-bold mt-1">Status: Active</span>
                                            </div>
                                        </div>

                                        <div className="h-14 bg-black/60 rounded-lg border border-white/5 overflow-hidden relative">
                                            <Visualizer isPlaying={isPlaying} color={currentTheme.primary} type={node.type === 'source' ? 'wave' : 'spectrum'} />
                                        </div>

                                        <div className="flex items-center gap-3">
                                            <div className="flex-1 h-1 bg-black rounded-full overflow-hidden">
                                                <motion.div
                                                    animate={{ width: isPlaying ? '70%' : '5%' }}
                                                    className="h-full"
                                                    style={{ backgroundColor: currentTheme.primary }}
                                                />
                                            </div>
                                            <Power size={12} className={isPlaying ? 'text-white' : 'text-white/10'} />
                                        </div>
                                    </div>

                                    {/* Output Port */}
                                    <div
                                        className="absolute top-1/2 -right-2 -translate-y-1/2 w-5 h-5 bg-[#222] border-2 border-white/10 rounded-full flex items-center justify-center cursor-crosshair hover:border-white transition-all z-50 group"
                                        onMouseDown={(e) => {
                                            e.stopPropagation();
                                            setPatchingFrom({ nodeId: node.id, x: node.x + 192, y: node.y + 45 });
                                        }}
                                    >
                                        <div className="w-1.5 h-1.5 bg-white/20 rounded-full shadow-[0_0_10px_white]"></div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}

                    {/* --- BOTTOM MIXER (GLASS PANEL) --- */}
                    <AnimatePresence>
                        {isMixerOpen && (
                            <motion.div
                                initial={{ y: 200 }} animate={{ y: 0 }} exit={{ y: 200 }}
                                className="absolute bottom-0 left-0 right-0 h-48 bg-aura-carbon/90 backdrop-blur-3xl border-t border-white/5 p-2 flex gap-2 z-[60]"
                            >
                                <div className="w-12 flex flex-col items-center py-4 gap-4 border-r border-white/5">
                                    <Maximize2 size={16} className="cursor-pointer hover:text-white" onClick={() => setIsMixerOpen(false)} />
                                    <Sliders size={16} className="text-aura-amber" />
                                </div>

                                <div className="flex-1 flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                                    {tracks.map(t => (
                                        <GlassPanel
                                            key={t.id}
                                            className={`w-32 flex flex-col transition-all duration-300 cursor-pointer ${selectedTrackId === t.id ? 'bg-white/5 border-white/20' : 'bg-transparent opacity-40'}`}
                                            onClick={() => setSelectedTrackId(t.id)}
                                        >
                                            <div className="h-6 bg-black/40 flex items-center px-3 justify-between border-b border-black">
                                                <span className="text-[9px] font-black text-white/40 uppercase truncate">{t.name}</span>
                                                <div className={`w-2 h-2 rounded-full ${isPlaying && selectedTrackId === t.id ? 'shadow-[0_0_10px_currentColor]' : ''}`} style={{ backgroundColor: currentTheme.primary, color: currentTheme.primary }} />
                                            </div>

                                            <div className="flex-1 flex px-3 py-4 gap-3 relative">
                                                {/* VU Meter */}
                                                <div className="w-5 bg-black/60 rounded-sm border border-white/5 p-0.5 flex flex-col-reverse gap-0.5">
                                                    {[...Array(14)].map((_, i) => (
                                                        <div key={i} className={`h-2 rounded-[1px] transition-all duration-75 ${i > 11 ? 'bg-rose-500' : i > 8 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ opacity: isPlaying && selectedTrackId === t.id && (Math.random() * 14) > i ? 1 : 0.1 }}></div>
                                                    ))}
                                                </div>

                                                {/* Fader */}
                                                <div className="flex-1 relative flex flex-col justify-center items-center">
                                                    <div className="w-1 h-full bg-black rounded-full border border-white/5 shadow-inner" />
                                                    <div className="absolute top-1/2 -translate-y-1/2 w-6 h-10 bg-[#333] border border-white/20 rounded shadow-2xl flex flex-col items-center justify-center gap-1 group">
                                                        <div className="w-4 h-[1px] bg-white/20" />
                                                        <div className="w-4 h-[1px] bg-white/20" />
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="flex border-t border-black text-[9px] font-black uppercase">
                                                <button className="flex-1 py-1 hover:bg-white/10 border-r border-black">S</button>
                                                <button className="flex-1 py-1 hover:bg-rose-500/20 text-rose-500/40 hover:text-rose-500">M</button>
                                            </div>
                                        </GlassPanel>
                                    ))}
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* --- RIGHT INSPECTOR (GLASS) --- */}
                <aside className="w-80 bg-aura-ebony border-l border-black flex flex-col z-50">
                    <div className="h-1/2 flex flex-col border-b border-white/5">
                        <div className="p-4 bg-white/[0.02] border-b border-white/5 flex justify-between items-center px-5">
                            <span className="text-[11px] font-black uppercase tracking-[0.3em] text-white flex items-center gap-3">
                                <Sliders size={14} style={{ color: currentTheme.primary }} /> DEVICE PARAMETERS
                            </span>
                        </div>

                        <div className="flex-1 p-6 overflow-y-auto bg-gradient-to-b from-transparent to-black/40">
                            {selectedNode ? (
                                <AnimatePresence mode="wait">
                                    <motion.div
                                        key={selectedNode.id}
                                        initial={{ opacity: 0, x: 20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        className="space-y-10"
                                    >
                                        <div className="p-4 rounded-xl bg-black border border-white/5 flex items-center gap-4 shadow-2xl">
                                            <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center shadow-inner" style={{ color: currentTheme.primary }}>
                                                <Cpu size={28} className={isPlaying ? 'animate-neon' : ''} />
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-[12px] font-black text-white uppercase">{selectedNode.label}</span>
                                                <span className="text-[8px] font-bold text-white/20 tracking-widest uppercase">{selectedNode.type} UNIT - Rev 2.0</span>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-8">
                                            {Object.entries(selectedNode.params).map(([key, val]) => (
                                                <Knob
                                                    key={key}
                                                    label={key}
                                                    value={val}
                                                    color={currentTheme.primary}
                                                    onChange={(newVal) => updateNodeParam(selectedNode.id, key, newVal)}
                                                />
                                            ))}
                                        </div>
                                    </motion.div>
                                </AnimatePresence>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center opacity-10 space-y-6">
                                    <Terminal size={64} className="animate-pulse" />
                                    <span className="text-[10px] font-black tracking-[0.5em] text-center uppercase leading-loose">NO MODULE<br />SELECTED</span>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="h-1/2 flex flex-col">
                        <div className="p-4 bg-white/[0.02] border-b border-white/5 px-5 flex justify-between items-center">
                            <span className="text-[9px] font-black text-white/20 uppercase tracking-[0.2em]">TRACK STACK BROWSER</span>
                            <Plus size={14} className="text-white/20 hover:text-white cursor-pointer" />
                        </div>
                        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1">
                            {tracks.map(t => (
                                <motion.div
                                    whileHover={{ x: 2 }}
                                    key={t.id}
                                    onClick={() => setSelectedTrackId(t.id)}
                                    className={`flex items-center gap-4 p-3 h-16 rounded-xl border transition-all cursor-pointer ${selectedTrackId === t.id ? 'bg-white/5 border-white/10 shadow-2xl' : 'bg-transparent border-transparent hover:bg-white/[0.02]'}`}
                                >
                                    <div className="w-1 h-8 rounded-full shadow-[0_0_10px_currentColor]" style={{ backgroundColor: selectedTrackId === t.id ? currentTheme.primary : 'rgba(255,255,255,0.05)', color: currentTheme.primary }} />
                                    <div className={`p-2.5 rounded-lg bg-black border border-white/5 ${selectedTrackId === t.id ? 'text-white' : 'text-white/10'}`} style={{ color: selectedTrackId === t.id ? currentTheme.primary : '' }}>
                                        {t.icon}
                                    </div>
                                    <div className="flex-1">
                                        <div className={`text-[11px] font-black tracking-tight ${selectedTrackId === t.id ? 'text-white' : 'text-white/20'}`}>{t.name}</div>
                                        <div className="text-[8px] font-mono text-white/10 mt-1 uppercase">Track 0{tracks.indexOf(t) + 1} // {t.kind}</div>
                                    </div>
                                    {selectedTrackId === t.id && <div className="w-1.5 h-1.5 rounded-full bg-white/40 animate-pulse" />}
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </aside>
            </main>

            {/* --- STATUS FOOTER --- */}
            <footer className="h-8 bg-black border-t border-white/5 px-5 flex items-center justify-between z-[100]">
                <div className="flex items-center gap-10">
                    <div className="flex items-center gap-3">
                        <div className={`w-2.5 h-2.5 rounded-full ${isPlaying ? 'bg-emerald-500 shadow-[0_0_15px_#10b981]' : 'bg-white/10'}`} />
                        <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] font-mono italic">
                            ENGINE: {isPlaying ? "OPTIMIZED_RT" : "IDLE"}
                        </span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Cpu size={12} className="text-white/10" />
                        <span className="text-[10px] font-mono text-white/10">3.4ms / 12% CPU</span>
                    </div>
                </div>
                <div className="flex items-center gap-6">
                    <span className="text-[9px] font-black text-white/10 uppercase tracking-[0.4em]">METAL HAL LOADED</span>
                    <Radio size={12} className={isPlaying ? 'text-aura-amber animate-pulse' : 'text-white/5'} />
                </div>
            </footer>

            {/* BACKGROUND GLOWS */}
            <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden">
                <motion.div
                    animate={{ scale: isPlaying ? 1.2 : 1, opacity: isPlaying ? 0.3 : 0 }}
                    transition={{ duration: 2 }}
                    className="absolute top-[-20%] right-[-10%] w-[70%] h-[70%] rounded-full blur-[150px]"
                    style={{ backgroundColor: currentTheme.primary }}
                />
                <motion.div
                    animate={{ scale: isPlaying ? 1.2 : 1, opacity: isPlaying ? 0.3 : 0 }}
                    transition={{ duration: 2, delay: 0.5 }}
                    className="absolute bottom-[-20%] left-[-10%] w-[70%] h-[70%] rounded-full blur-[150px]"
                    style={{ backgroundColor: currentTheme.primary }}
                />
            </div>

            <style>{`
                .glass-panel {
                    @apply bg-aura-carbon/80 backdrop-blur-3xl border border-white/5 shadow-2xl;
                }
                .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
                .custom-scrollbar::-webkit-scrollbar-thumb { @apply bg-white/5 rounded-full; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { @apply bg-white/20; }
                .animate-neon {
                    animation: neon-pulse 1.5s ease-in-out infinite;
                }
                @keyframes neon-pulse {
                    0%, 100% { filter: brightness(1) drop-shadow(0 0 5px currentColor); }
                    50% { filter: brightness(1.5) drop-shadow(0 0 15px currentColor); }
                }
            `}</style>
        </div>
    );
};

export default App;