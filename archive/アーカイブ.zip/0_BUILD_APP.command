#!/bin/zsh

# Aura DAW Ultimate - Professional Packaging System
# This script creates a native macOS .app bundle.

PROJECT_DIR=$(cd "$(dirname "$0")" && pwd)
BUILD_DIR="$PROJECT_DIR/build"
APP_DIR="$PROJECT_DIR/Aura DAW.app"

echo "--------------------------------------------------------"
echo "  Aura DAW Ultimate Packaging Engine [v1.0]"
echo "--------------------------------------------------------"

# 1. CLEAN & BUILD
mkdir -p "$BUILD_DIR"
cmake -S "$PROJECT_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD_DIR" --config Release -j "$(sysctl -n hw.ncpu)"

if [ $? -ne 0 ]; then
    echo "[ERROR] Build failed."
    exit 1
fi

# 2. CREATE APP STRUCTURE
echo "[INFO] Creating macOS Application Bundle..."
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/Contents/MacOS"
mkdir -p "$APP_DIR/Contents/Resources"

# 3. COPY EXECUTABLE
EXE_SRC="$BUILD_DIR/bin/AuraUltimate"
if [ -f "$EXE_SRC" ]; then
    cp "$EXE_SRC" "$APP_DIR/Contents/MacOS/Aura DAW"
    chmod +x "$APP_DIR/Contents/MacOS/Aura DAW"
else
    echo "[ERROR] Binary not found at $EXE_SRC"
    exit 1
fi

# 4. COPY ICON
if [ -f "$PROJECT_DIR/AuraIcon.icns" ]; then
    cp "$PROJECT_DIR/AuraIcon.icns" "$APP_DIR/Contents/Resources/AuraIcon.icns"
fi

# 5. GENERATE INFO.PLIST
cat <<EOF > "$APP_DIR/Contents/Info.plist"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>Aura DAW</string>
    <key>CFBundleIdentifier</key>
    <string>com.aura.daw.ultimate</string>
    <key>CFBundleName</key>
    <string>Aura DAW</string>
    <key>CFBundleIconFile</key>
    <string>AuraIcon</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
EOF

echo "--------------------------------------------------------"
echo "[SUCCESS] Packaging Complete: $APP_DIR"
echo "--------------------------------------------------------"
open "$PROJECT_DIR"
